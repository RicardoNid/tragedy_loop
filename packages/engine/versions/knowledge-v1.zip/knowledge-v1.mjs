// Frozen pre-refactor solver, replay engine and official content. Do not regenerate from v2.
var __defProp = Object.defineProperty;
var __export = (target, all2) => {
  for (var name in all2)
    __defProp(target, name, { get: all2[name], enumerable: true });
};

// packages/engine/src/runtime/model.ts
var BOARDS = ["hospital", "shrine", "city", "school"];
var COUNTERS = ["goodwill", "paranoia", "intrigue", "guard", "hope", "despair"];
var zeroCounters = () => ({
  goodwill: 0,
  paranoia: 0,
  intrigue: 0,
  guard: 0,
  hope: 0,
  despair: 0
});
var clone = (value2) => structuredClone(value2);
function canonical(value2) {
  if (Array.isArray(value2)) return `[${value2.map(canonical).join(",")}]`;
  if (value2 !== null && typeof value2 === "object")
    return `{${Object.entries(value2).filter(([, v]) => v !== void 0).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([k, v]) => `${JSON.stringify(k)}:${canonical(v)}`).join(",")}}`;
  return JSON.stringify(value2) ?? "null";
}

// packages/engine/src/runtime/expressions.ts
function ref(value2, env) {
  return value2.startsWith("$") ? env[value2.slice(1)] ?? "" : value2;
}
function bind(state, env) {
  const result = { ...env };
  for (const [key, id] of Object.entries(env)) {
    const c = state.characters[id];
    if (c) {
      result[`${key}.area`] = c.area;
      result[`${key}.initialArea`] = c.initialArea;
    } else if (id.startsWith("victim:")) result[`${key}.area`] = id.split(":")[1];
  }
  if (env.effectiveArea) result["self.area"] = env.effectiveArea;
  return result;
}
function effective(state, target, counter) {
  if (BOARDS.includes(target)) {
    const modifier = state.setup.y === "封印的终末" ? Object.values(state.characters).filter((c2) => c2.status === "alive" && c2.area === target).reduce((n, c2) => n + c2.counters.despair - c2.counters.hope, 0) : 0;
    return counter === "intrigue" ? Math.max(0, state.boards[target] + modifier) : 0;
  }
  const c = state.characters[target]?.counters;
  if (!c) return 0;
  if (counter === "goodwill") return c.goodwill + c.hope;
  if (counter === "paranoia") return c.paranoia + c.despair;
  if (counter === "intrigue") return Math.max(0, c.intrigue + c.despair - c.hope);
  return c[counter];
}
function identities(state, id) {
  const c = state.characters[id];
  if (!c) return [];
  const result = [c.identity];
  if (c.identity === "不安定因子") {
    if (effective(state, "school", "intrigue") >= 2) result.push("传谣人");
    if (effective(state, "city", "intrigue") >= 2) result.push("关键人物");
  }
  if (c.identity === "无面者") result.push(state.ex <= 1 ? "传谣人" : "深潜者");
  if (c.identity === "偏执狂" && state.setup.x.includes("深渊之都的私语")) result.push("关键人物");
  if (c.identity === "怪杰" && state.day % 3 === 0) result.push("传谣人", "主谋", "杀人狂");
  return result;
}
function refusal(pack, state, id) {
  const c = state.characters[id];
  if (!c || c.counters.hope > 0) return "none";
  if (c.counters.despair > 0) return state.setup.x.includes("傀儡之线") ? "optional" : "mandatory";
  if (c.identity === "纸老虎" && effective(state, id, "paranoia") >= 2) return "mandatory";
  if (c.identity === "密钥" && state.setup.x.includes("捏造的秘密")) return "optional";
  const mode = pack.identities[c.identity]?.ignore ?? "none";
  return state.setup.x.includes("傀儡之线") && mode !== "none" ? "optional" : mode;
}
function immortal(pack, state, id) {
  const c = state.characters[id];
  if (!c) return false;
  if (c.identity === "纸老虎" && effective(state, id, "paranoia") >= 2) return false;
  return Boolean(pack.identities[c.identity]?.immortal);
}
function value(pack, state, expression, env) {
  if (expression === null || typeof expression !== "object") return expression;
  if ("ref" in expression) return ref(expression.ref, env);
  if ("gameFlag" in expression) return state.flags[expression.gameFlag] ?? "";
  if ("game" in expression) {
    if (expression.game === "world") return state.ex % 2;
    if (expression.game === "days" || expression.game === "loops")
      return state.setup[expression.game];
    return state[expression.game];
  }
  if ("count" in expression) return select(pack, state, expression.count, env).length;
  if ("sum" in expression)
    return select(pack, state, expression.sum, env).reduce(
      (total, id) => total + Number(value(pack, state, expression.value, bind(state, { ...env, it: id }))),
      0
    );
  if ("op" in expression) {
    const args = expression.args.map((a) => Number(value(pack, state, a, env)));
    if (expression.op === "add") return args.reduce((a, b) => a + b, 0);
    if (expression.op === "subtract") return (args[0] ?? 0) - (args[1] ?? 0);
    return expression.op === "min" ? Math.min(...args) : Math.max(...args);
  }
  const target = ref(expression.target, env);
  if ("counter" in expression)
    return expression.raw ? state.characters[target]?.counters[expression.counter] ?? (expression.counter === "intrigue" ? state.boards[target] ?? 0 : 0) : effective(state, target, expression.counter);
  const c = state.characters[target];
  if (!c && target.startsWith("victim:")) {
    if (expression.field === "area" || expression.field === "initialArea")
      return target.split(":")[1];
    if (expression.field === "identity") return state.setup.y === "古墓活尸" ? "丧尸" : "平民";
    if (expression.field === "status") return "dead";
    return 0;
  }
  if (!c) return expression.field === "area" || expression.field === "initialArea" ? target : null;
  if (expression.field === "area" && target === env.self && env.effectiveArea)
    return env.effectiveArea;
  if (expression.field === "rawTotal") return COUNTERS.reduce((sum, k) => sum + c.counters[k], 0);
  if (expression.field === "kinds") return COUNTERS.filter((k) => c.counters[k] > 0).length;
  if (expression.field === "paranoiaLimit") return c.character === "仙人" ? 0 : c.paranoiaLimit;
  return c[expression.field];
}
function test(pack, state, condition, env) {
  if (condition === void 0) return true;
  if (typeof condition === "boolean") return condition;
  if ("all" in condition) return condition.all.every((c) => test(pack, state, c, env));
  if ("any" in condition) return condition.any.some((c) => test(pack, state, c, env));
  if ("not" in condition) return !test(pack, state, condition.not, env);
  if ("attribute" in condition)
    return state.characters[ref(condition.target, env)]?.attributes.includes(condition.attribute) ?? false;
  if ("hasAbility" in condition)
    return identities(state, ref(condition.target, env)).includes(condition.hasAbility);
  if ("flag" in condition)
    return Boolean(
      condition.target ? state.characters[ref(condition.target, env)]?.flags[condition.flag] : state.flags[condition.flag]
    );
  if ("incidentOccurred" in condition)
    return state.incidents.some(
      (i) => i.loop === state.loop && i.name === condition.incidentOccurred
    );
  const a = value(pack, state, condition.left, env);
  const b = value(pack, state, condition.right, env);
  if (condition.cmp === "eq") return a === b;
  if (condition.cmp === "ne") return a !== b;
  if (condition.cmp === "ge") return Number(a) >= Number(b);
  if (condition.cmp === "gt") return Number(a) > Number(b);
  if (condition.cmp === "le") return Number(a) <= Number(b);
  return Number(a) < Number(b);
}
function select(pack, state, selector, env) {
  let ids = Object.values(state.characters).filter(
    (c) => selector.kind === "cards" || (selector.kind === "dead" ? c.status === "dead" : c.status === "alive")
  ).map((c) => c.id);
  if (selector.kind === "boards") ids = [...BOARDS];
  if (selector.kind === "alive-or-boards") ids.push(...BOARDS);
  if (pack.module === "HSA" && selector.kind === "dead")
    for (const board2 of BOARDS)
      for (let n = 0; n < state.boards[board2]; n++) ids.push(`victim:${board2}:${n}`);
  return ids.filter((id) => test(pack, state, selector.where, { ...env, it: id }));
}
function recompute(state) {
  for (const c of Object.values(state.characters)) {
    if (state.setup.module === "AHR") {
      const config = state.setup.characters.find((t) => t.id === c.id);
      c.identity = state.ex % 2 === 1 && config?.reverseIdentity ? config.reverseIdentity : c.initialIdentity;
      if (c.character === "临时工") c.identity = "平民";
      if (state.setup.x.includes("空想扩大病毒") && state.ex % 2 === 1 && ["平民", "因果残片"].includes(c.identity) && c.status === "alive" && COUNTERS.filter((k) => c.counters[k] > 0).length >= 2)
        c.identity = "杀人狂";
    }
    if (state.setup.x.includes("妄想扩大病毒") && c.initialIdentity === "平民") {
      c.identity = c.status === "alive" && effective(state, c.id, "paranoia") >= 3 ? "杀人狂" : c.initialIdentity;
    }
    if (state.setup.y === "因果之绊" && c.flags["causal-ex"]) c.identity = "关键人物";
    if (state.setup.y === "古墓活尸" && c.status === "dead" && ["平民", "胆小鬼", "纸老虎"].includes(c.identity))
      c.identity = "丧尸";
  }
  checkSpecialVictory(state);
}
function traitors(state) {
  if (!state.ll || state.ll.finalTraitorsDisabled) return [];
  if (state.setup.y === "最终计划" && Object.values(state.characters).some((c) => c.identity === "关键人物" && c.counters.hope >= 1))
    return [];
  const active = [
    state.setup.x.includes("真正的怪物") ? "A" : "",
    state.setup.x.includes("神话收集者") ? "B" : "",
    state.setup.x.includes("我才是名侦探") ? "C" : ""
  ];
  return ["p0", "p1", "p2"].filter((p) => active.includes(state.ll.roles[p]));
}
function checkSpecialVictory(state) {
  if (!state.ll || state.latchedWinner || state.winner) return;
  for (const actor of traitors(state)) {
    const role2 = state.ll.roles[actor];
    if (role2 === "A" && state.phase === "day-end" && state.ll.died.length >= 5 || role2 === "B" && state.phase === "protagonist-abilities" && state.ll.communicated.length >= 6)
      state.latchedWinner = actor;
  }
}
function destination(area, directions) {
  const moves = [...new Set(directions)];
  if (area === "far" || moves.length === 0) return area;
  const bits = moves.reduce((n, d) => n ^ ({ horizontal: 1, vertical: 2, diagonal: 3 }[d] ?? 0), 0);
  return BOARDS[BOARDS.indexOf(area) ^ bits] ?? area;
}

// packages/engine/src/runtime/settlement.ts
function announce(state, type, data, audience = "public") {
  for (const recipient of audience === "public" ? ["public", "protagonists", "mastermind"] : [audience]) {
    const events = state.observations[recipient];
    events.push({
      sequence: events.length + 1,
      loop: state.loop,
      day: state.day,
      phase: state.phase,
      type,
      data: clone(data)
    });
  }
}
function publishChanges(before, after) {
  for (const board2 of BOARDS)
    if (before.boards[board2] !== after.boards[board2])
      announce(after, "board", { board: board2, intrigue: after.boards[board2] });
  for (const c of Object.values(after.characters)) {
    const old = before.characters[c.id];
    if (!old || JSON.stringify([old.area, old.status, old.counters]) !== JSON.stringify([c.area, c.status, c.counters]))
      announce(after, "character", {
        character: c.id,
        area: c.area,
        status: c.status,
        counters: c.counters
      });
  }
  if (before.ex !== after.ex) announce(after, "board", { ex: after.ex });
  if (!before.protagonistDead && after.protagonistDead)
    announce(after, "failure", { result: "protagonist-death" });
  else if (!before.failed && after.failed)
    announce(after, "failure", { result: "protagonist-failure" });
}
function grantCard(state, owner, kind) {
  const key = `grant:${state.loop}:${owner}:${kind}`;
  if (state.flags[key]) return;
  state.flags[key] = "yes";
  const existing = state.cards.find((c) => c.owner === owner && c.kind === kind);
  if (existing) existing.status = "hand";
  else state.cards.push({ id: `${owner}-${kind}`, owner, kind, once: true, status: "hand" });
  announce(state, "card-grant", { owner, kind });
}
function flatten(pack, snapshot, intents) {
  const result = [];
  for (const intent of intents) {
    const { effect } = intent, env = bind(snapshot, intent.env);
    if (effect.op === "when") {
      if (test(pack, snapshot, effect.condition, env))
        result.push(
          ...flatten(
            pack,
            snapshot,
            effect.effects.map((effect2) => ({ effect: effect2, env }))
          )
        );
    } else if (effect.op === "each") {
      for (const id of select(pack, snapshot, effect.selector, env))
        result.push(
          ...flatten(
            pack,
            snapshot,
            effect.effects.map((effect2) => ({ effect: effect2, env: { ...env, it: id } }))
          )
        );
    } else result.push({ effect, env });
  }
  return result;
}
function canMove(c) {
  return c.status === "alive" && !c.flags.immobile;
}
function protects(pack, guardian, target) {
  const rule = pack.characters[guardian.character]?.protects;
  return !!rule && guardian.id !== target.id && guardian.status === "alive" && (rule.characters.includes(target.character) || guardian.flags[rule.selectedTargetFlag] === target.id);
}
function permitsMove(state, id, area) {
  const c = state.characters[id];
  const locked = state.flags["lockdown-area"];
  const sealed = locked && state.day < Number(state.flags["lockdown-day"]) + 3 && (area === locked || c?.area === locked);
  return !!c && canMove(c) && [...BOARDS, "far"].includes(area) && (!!c.flags["free-movement"] || !c.forbidden.includes(area)) && !sealed;
}
function settle(pack, state, input, choices = {}) {
  const before = clone(state);
  const intents = flatten(pack, before, input);
  const moves = {};
  const moveOrigins = {};
  for (const { effect, env } of intents)
    if (effect.op === "move") {
      const id = ref(effect.target, env), c = before.characters[id], area = ref(effect.area, env);
      if (c && permitsMove(before, id, area)) {
        moves[id] = area;
        moveOrigins[id] = id === env.self && env.effectiveArea ? env.effectiveArea : c.area;
      }
    }
  const followChoices = [];
  for (const c of Object.values(before.characters).filter(
    (c2) => pack.characters[c2.character]?.protects && canMove(c2)
  )) {
    const leaders = Object.values(before.characters).filter(
      (t) => protects(pack, c, t) && t.status === "alive" && (moveOrigins[t.id] ?? t.area) === c.area && moves[t.id] && moves[t.id] !== (moveOrigins[t.id] ?? t.area)
    );
    if (leaders.length > 0) {
      const key = `follow:${c.id}`;
      const selected = leaders.length === 1 ? leaders[0]?.id : choices[key];
      if (!selected || !leaders.some((l) => l.id === selected))
        followChoices.push({ key, options: leaders.map((l) => l.id) });
      else moves[c.id] = moves[selected];
    }
  }
  if (followChoices.length) return { died: [], invoked: [], followChoices };
  for (const { effect, env } of intents)
    if (effect.op === "reveal-identity") {
      const id = ref(effect.target, env), c = before.characters[id];
      if (c?.identity === "忍者" && c.status === "alive" && !choices[`reveal:${id}`])
        followChoices.push({
          key: `reveal:${id}`,
          options: [
            ...new Set(state.setup.characters.map((c2) => c2.identity).filter((i) => i !== "平民"))
          ]
        });
    }
  if (followChoices.length) return { died: [], invoked: [], followChoices };
  const deltas = {};
  const add2 = (id, counter, amount) => {
    if (!Number.isSafeInteger(amount)) throw new Error("non-integral counter change");
    (deltas[id] ??= {})[counter] = (deltas[id]?.[counter] ?? 0) + amount;
  };
  const deaths = [];
  const revivals = /* @__PURE__ */ new Set();
  const removals = /* @__PURE__ */ new Set();
  const invoked = [];
  const goodwill = [];
  for (const { effect, env } of intents) {
    const target = "target" in effect && effect.target ? ref(effect.target, env) : "";
    switch (effect.op) {
      case "counter": {
        const counter = effect.counter === "$counter" ? env.counter : effect.counter;
        if (!COUNTERS.includes(counter)) throw new Error("unknown counter");
        add2(target, counter, Number(value(pack, before, effect.amount, env)));
        break;
      }
      case "clear":
        for (const k of effect.counter ? [effect.counter] : COUNTERS)
          add2(
            target,
            k,
            -(before.characters[target]?.counters[k] ?? (k === "intrigue" ? before.boards[target] ?? 0 : 0))
          );
        break;
      case "transfer": {
        const from = ref(effect.from, env), to = ref(effect.to, env), counter = ref(effect.counter, env);
        if (!COUNTERS.includes(counter)) throw new Error("unknown counter");
        if ((before.characters[from]?.counters[counter] ?? 0) > 0 && before.characters[to]) {
          add2(from, counter, -1);
          add2(to, counter, 1);
        } else if (env.forensicTransfer && (before.characters[to]?.counters[counter] ?? 0) > 0 && before.characters[from]) {
          add2(to, counter, -1);
          add2(from, counter, 1);
        }
        break;
      }
      case "replace":
        if ((before.characters[target]?.counters[effect.from] ?? 0) > 0) {
          add2(target, effect.from, -1);
          add2(target, effect.to, 1);
        }
        break;
      case "kill":
        if (before.characters[target]?.status === "alive")
          deaths.push({ target, origin: env.self ?? "", replacement: false });
        break;
      case "revive":
        if (before.characters[target]?.status === "dead") revivals.add(target);
        else if (target.startsWith("victim:")) add2(target.split(":")[1], "intrigue", -1);
        break;
      case "remove":
        if (before.characters[target]?.status === "alive") removals.add(target);
        break;
      case "move":
        break;
      case "move-corpse": {
        const area = ref(effect.area, env);
        if (!BOARDS.includes(area)) break;
        if (target.startsWith("victim:")) {
          add2(target.split(":")[1], "intrigue", -1);
          add2(area, "intrigue", 1);
        } else if (before.characters[target]?.status === "dead") moves[target] = area;
        break;
      }
      case "curse": {
        const curses = state.curses ??= [];
        const existing = effect.id && curses.find((c) => c.id === effect.id);
        if (existing) existing.target = target;
        else curses.push({ id: `curse-${++state.serial}`, target });
        announce(state, "board", { curses });
        break;
      }
      case "place": {
        const c = state.characters[target], area = ref(effect.area, env);
        if (c && BOARDS.includes(area)) c.area = c.initialArea = area;
        break;
      }
      case "same-identity": {
        const c = before.characters[target];
        if (c)
          announce(state, "identity", {
            sameIdentityAs: target,
            characters: Object.values(before.characters).filter((t) => t.id !== target && t.status === "alive" && t.identity === c.identity).map((t) => t.id)
          });
        break;
      }
      case "invoke-goodwill":
        goodwill.push({
          target,
          ability: ref(effect.ability, env),
          actor: env.actor ?? state.captain,
          parent: env.sourceId ?? ""
        });
        break;
      case "flag":
        if (effect.key === "no-protagonist-cards") state.flags["ex-cards-restricted"] = "yes";
        if (effect.key === "cultist" && state.characters[target])
          state.characters[target].flags["cultist-area"] = env.effectiveArea ?? state.characters[target].area;
        if (target && state.characters[target])
          state.characters[target].flags[effect.key] = ref(effect.value ?? "yes", env);
        else if (!target) state.flags[effect.key] = ref(effect.value ?? "yes", env);
        if (["streamer-target", "no-protagonist-cards", "causal-ex", "lockdown-area"].includes(
          effect.key
        ))
          announce(state, "board", {
            attachment: effect.key,
            target: target || ref(effect.value ?? "", env)
          });
        break;
      case "protect-protagonists":
        state.protected = true;
        break;
      case "world-move":
        state.flags["world-moved"] = "yes";
        break;
      case "grant":
        for (const actor of effect.side === "mastermind" ? ["mastermind"] : ["p0", "p1", "p2"])
          grantCard(state, actor, effect.card);
        break;
      case "schedule": {
        if (effect.onlyIfMoved && (!moves[ref(effect.onlyIfMoved, env)] || moves[ref(effect.onlyIfMoved, env)] === before.characters[ref(effect.onlyIfMoved, env)]?.area))
          break;
        (state.delayed ??= []).push({
          loop: effect.loop === void 0 ? state.loop : Number(value(pack, before, effect.loop, env)),
          day: Number(value(pack, before, effect.day, env)),
          timing: effect.timing,
          effects: clone(effect.effects),
          env: clone(env)
        });
        break;
      }
      case "protagonist-death":
        if (!before.protected) {
          state.protagonistDead = true;
          state.failed = true;
          state.endRequested = true;
        }
        break;
      case "fail":
        state.failed = true;
        state.endRequested = true;
        break;
      case "end-loop":
        state.endRequested = true;
        break;
      case "ex":
        state.ex += Number(value(pack, before, effect.amount, env));
        break;
      case "reveal-identity": {
        const c = before.characters[target];
        if (c) {
          const identity = choices[`reveal:${target}`] ?? c.identity;
          state.characters[target].revealed = true;
          state.revealedIdentities.push({ character: target, identity, loop: state.loop });
          announce(state, "identity", { character: target, identity });
          if (c.identity === "密钥" && state.loop <= 2) {
            state.flags[`mastermind-cards:${state.day + 1}`] = "1";
            (state.delayed ??= []).push({
              loop: state.loop,
              day: Math.min(state.day + 1, state.setup.days),
              timing: "day-end",
              effects: [{ op: "protagonist-death" }],
              env: {}
            });
          }
        } else if (target.startsWith("victim:"))
          announce(state, "identity", {
            character: target,
            identity: state.setup.y === "古墓活尸" ? "丧尸" : "平民"
          });
        break;
      }
      case "reveal-rule":
        announce(state, "rule", { rule: ref(effect.rule, env) });
        break;
      case "reveal-culprit": {
        const day = Number(ref(effect.day, env));
        const incident = state.setup.incidents.find((i) => i.day === day);
        if (incident) announce(state, "culprit", { day, culprit: incident.culprit });
        break;
      }
      case "recover-card": {
        const card = state.cards.find((c) => c.id === ref(effect.card, env));
        if (card?.status === "used" && card.once && card.owner === (env.actor === "mastermind" ? "mastermind" : state.captain))
          card.status = "hand";
        break;
      }
      case "invoke-incident":
        invoked.push({
          name: ref(effect.name, env),
          culprit: ref(effect.culprit, env),
          actor: env.actor ?? "mastermind",
          parent: env.sourceId ?? "",
          nested: env.sourceKind === "incident"
        });
        break;
      case "when":
      case "each":
        throw new Error("unexpanded batch");
    }
  }
  const guards = Object.fromEntries(
    Object.values(before.characters).map((c) => [c.id, c.counters.guard])
  );
  const dying = /* @__PURE__ */ new Set();
  for (const request of deaths) {
    let target = request.target;
    if (immortal(pack, before, target)) continue;
    if ((guards[target] ?? 0) > 0) {
      guards[target]--;
      continue;
    }
    const original = before.characters[target];
    const substitute = Object.values(before.characters).find(
      (c) => c.area === original.area && protects(pack, c, original)
    );
    if (substitute) {
      target = substitute.id;
      state.audit.push({ kind: "replacement-request", data: { from: request.target, to: target } });
      if (immortal(pack, before, target)) continue;
      if ((guards[target] ?? 0) > 0) {
        guards[target]--;
        continue;
      }
    }
    dying.add(target);
  }
  state.audit.push({ kind: "death-requests", data: clone(deaths) });
  for (const [id, n] of Object.entries(guards))
    add2(id, "guard", n - before.characters[id].counters.guard);
  for (const [id, changes] of Object.entries(deltas))
    for (const counter of COUNTERS) {
      const delta = changes[counter] ?? 0;
      if (BOARDS.includes(id)) {
        if (counter === "intrigue")
          state.boards[id] = Math.min(3, Math.max(0, before.boards[id] + delta));
      } else if (state.characters[id])
        state.characters[id].counters[counter] = Math.max(
          0,
          before.characters[id].counters[counter] + delta
        );
    }
  for (const [id, area] of Object.entries(moves)) state.characters[id].area = area;
  for (const id of revivals) state.characters[id].status = "alive";
  for (const id of dying) {
    if (state.ll && !state.ll.died.includes(id)) {
      state.ll.died.push(id);
      announce(state, "board", { diedMarker: id });
    }
    state.characters[id].status = "dead";
  }
  for (const id of removals) state.characters[id].status = "removed";
  if (removals.size) state.curses = state.curses?.filter((c) => !removals.has(c.target));
  state.ex = Math.max(0, state.ex);
  recompute(state);
  publishChanges(before, state);
  if (state.ex > before.ex) state.flags["ex-increased"] = "yes";
  for (const key of Object.keys(state.flags).filter(
    (k) => k.startsWith("follow:") || k.startsWith("reveal:")
  ))
    delete state.flags[key];
  return { died: [...dying], invoked, goodwill };
}

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value2) => {
    if (typeof value2 === "bigint") {
      return value2.toString();
    }
    return value2;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json = JSON.stringify(obj, null, 2);
  return json.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value2) {
    if (!(value2 instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value2}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path, errorMaps, issueData } = params;
  const fullPath = [...path, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value2 = await pair.value;
      syncPairs.push({
        key,
        value: value2
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value: value2 } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value2.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status.dirty();
      if (value2.status === "dirty")
        status.dirty();
      if (key.value !== "__proto__" && (typeof value2.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value2.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value2) => ({ status: "dirty", value: value2 });
var OK = (value2) => ({ status: "valid", value: value2 });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value2, path, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value2;
    this._path = path;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options2) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options2) });
  }
  ip(options2) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options2) });
  }
  cidr(options2) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options2) });
  }
  datetime(options2) {
    if (typeof options2 === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options2
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options2?.precision === "undefined" ? null : options2?.precision,
      offset: options2?.offset ?? false,
      local: options2?.local ?? false,
      ...errorUtil.errToObj(options2?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options2) {
    if (typeof options2 === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options2
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options2?.precision === "undefined" ? null : options2?.precision,
      ...errorUtil.errToObj(options2?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value2, options2) {
    return this._addCheck({
      kind: "includes",
      value: value2,
      position: options2?.position,
      ...errorUtil.errToObj(options2?.message)
    });
  }
  startsWith(value2, message) {
    return this._addCheck({
      kind: "startsWith",
      value: value2,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value2, message) {
    return this._addCheck({
      kind: "endsWith",
      value: value2,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value2, message) {
    return this.setLimit("min", value2, true, errorUtil.toString(message));
  }
  gt(value2, message) {
    return this.setLimit("min", value2, false, errorUtil.toString(message));
  }
  lte(value2, message) {
    return this.setLimit("max", value2, true, errorUtil.toString(message));
  }
  lt(value2, message) {
    return this.setLimit("max", value2, false, errorUtil.toString(message));
  }
  setLimit(kind, value2, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value: value2,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value2, message) {
    return this._addCheck({
      kind: "multipleOf",
      value: value2,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value2, message) {
    return this.setLimit("min", value2, true, errorUtil.toString(message));
  }
  gt(value2, message) {
    return this.setLimit("min", value2, false, errorUtil.toString(message));
  }
  lte(value2, message) {
    return this.setLimit("max", value2, true, errorUtil.toString(message));
  }
  lt(value2, message) {
    return this.setLimit("max", value2, false, errorUtil.toString(message));
  }
  setLimit(kind, value2, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value: value2,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value2, message) {
    return this._addCheck({
      kind: "multipleOf",
      value: value2,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value2 = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value2, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value2 = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value2, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value2 = await pair.value;
          syncPairs.push({
            key,
            value: value2,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema;
      } else {
        newShape[key] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema = this.shape[key];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options2 = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options2.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options2) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options2, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options2) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value2 of discriminatorValues) {
        if (optionsMap.has(value2)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value2)}`);
        }
        optionsMap.set(value2, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options: options2,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value2], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value2, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value2 = await pair.value;
          if (key.status === "aborted" || value2.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value2.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value2.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value2 = pair.value;
        if (key.status === "aborted" || value2.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value2.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key.value, value2.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value2, params) => {
  return new ZodLiteral({
    value: value2,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg) => {
        addIssueToContext(ctx, arg);
        if (arg.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base))
          return INVALID;
        const result = effect.transform(base.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
          if (!isValid(base))
            return INVALID;
          return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze2 = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze2(data)) : freeze2(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: (arg) => ZodString.create({ ...arg, coerce: true }),
  number: (arg) => ZodNumber.create({ ...arg, coerce: true }),
  boolean: (arg) => ZodBoolean.create({
    ...arg,
    coerce: true
  }),
  bigint: (arg) => ZodBigInt.create({ ...arg, coerce: true }),
  date: (arg) => ZodDate.create({ ...arg, coerce: true })
};
var NEVER = INVALID;

// packages/contracts/src/validation.ts
var text = external_exports.string().min(1);
var integer = external_exports.number().int().safe().nonnegative();
var positive = integer.positive();
var board = external_exports.enum(["hospital", "shrine", "city", "school"]);
var seat = external_exports.enum(["p0", "p1", "p2"]);
var role = external_exports.enum(["A", "B", "C"]);
var setupSchema = external_exports.object({
  module: external_exports.enum(["FS", "BTX", "MZ", "MC", "HSA", "WM", "AHR", "LL"]),
  anniversary: external_exports.boolean(),
  loops: positive,
  days: positive,
  y: text,
  x: external_exports.array(text),
  captain: seat,
  discussion: external_exports.enum(["allowed", "between-loops"]),
  publicSpecialRules: external_exports.array(text).optional(),
  characters: external_exports.array(
    external_exports.object({
      id: text,
      character: text,
      identity: text,
      initialArea: external_exports.enum(["hospital", "shrine", "city", "school", "far"]).optional(),
      enterDay: positive.optional(),
      enterLoop: positive.optional(),
      x: integer.optional(),
      territory: board.optional(),
      copiedFrom: text.optional(),
      reverseIdentity: text.optional()
    }).strict()
  ).min(1),
  incidents: external_exports.array(
    external_exports.object({ day: positive, name: text, publicName: text.optional(), culprit: text }).strict()
  ),
  alternateY: text.optional(),
  anniversaryFragment: text.optional(),
  privateRoles: external_exports.object({ p0: role, p1: role, p2: role }).strict().optional(),
  secretAddition: external_exports.enum(["杀手", "主谋", "因果残片"]).optional()
}).strict();
var commandSchema = external_exports.object({
  id: text,
  expectedRevision: integer,
  decisionId: text,
  choice: external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("start") }).strict(),
    external_exports.object({ kind: external_exports.literal("continue") }).strict(),
    external_exports.object({ kind: external_exports.literal("pass") }).strict(),
    external_exports.object({ kind: external_exports.literal("request-final-guess") }).strict(),
    external_exports.object({ kind: external_exports.literal("vote-final-guess"), agree: external_exports.boolean() }).strict(),
    external_exports.object({
      kind: external_exports.literal("cards"),
      placements: external_exports.array(external_exports.object({ card: text, target: text }).strict())
    }).strict(),
    external_exports.object({
      kind: external_exports.literal("ability"),
      ability: text,
      owner: text.optional(),
      choices: external_exports.record(external_exports.string()).optional()
    }).strict(),
    external_exports.object({ kind: external_exports.literal("select"), value: external_exports.string() }).strict(),
    external_exports.object({ kind: external_exports.literal("refuse"), refuse: external_exports.boolean() }).strict(),
    external_exports.object({
      kind: external_exports.literal("guess"),
      character: text,
      identity: text,
      reverseIdentity: text.optional()
    }).strict(),
    external_exports.object({ kind: external_exports.literal("guess-culprits"), answers: external_exports.record(text) }).strict()
  ])
}).strict();

// packages/engine/src/runtime/setup.ts
function hasUnsupportedDiagnostic(diagnostics) {
  return diagnostics.some((d) => d.code.startsWith("unsupported"));
}
function validateSetup(pack, setup) {
  const parsed = setupSchema.safeParse(setup);
  if (!parsed.success)
    return parsed.error.issues.map((issue) => ({
      code: "invalid-setup",
      path: issue.path.join("."),
      message: issue.message
    }));
  const errors = [];
  const fail2 = (code, path, message) => errors.push({ code, path, message });
  if (setup.module !== pack.module || setup.anniversary !== pack.anniversary)
    fail2("profile-mismatch", "module", "Setup and compiled rule profile differ.");
  if (!["FS", "BTX", "MZ", "MC", "WM", "HSA", "AHR", "LL"].includes(pack.module))
    fail2(
      "unsupported-module-semantics",
      "module",
      "This module is inventoried but not yet executable."
    );
  if (pack.anniversary && ["AHR", "LL"].includes(pack.module))
    fail2(
      "invalid-overlay",
      "anniversary",
      "The anniversary overlay applies only to pre-anniversary modules."
    );
  if (!Number.isSafeInteger(setup.days) || setup.days < 1 || !Number.isSafeInteger(setup.loops) || setup.loops < 1)
    fail2("invalid-duration", "days", "Days and loops must be positive integers.");
  if (!["p0", "p1", "p2"].includes(setup.captain))
    fail2("invalid-captain", "captain", "Exactly three protagonist seats are supported.");
  if (!["allowed", "between-loops"].includes(setup.discussion))
    fail2("invalid-policy", "discussion", "Unknown discussion policy.");
  const xCount = pack.module === "FS" ? 1 : 2;
  if (setup.x.length !== xCount || new Set(setup.x).size !== setup.x.length)
    fail2("invalid-x-slots", "x", `Exactly ${xCount} distinct X rules are required.`);
  const pool = {};
  const pairs = [], assignedPairs = [];
  for (const [name, type] of [[setup.y, "Y"], ...setup.x.map((x) => [x, "X"])]) {
    const plot = name ? pack.plots[name] : void 0;
    if (!plot || plot.type !== type) {
      fail2("invalid-rule", "rules", `Unknown ${type} rule: ${name}`);
      continue;
    }
    if (!plot.supported) fail2("unsupported-rule", "rules", `Pending translation: ${name}`);
    for (const [identity, n] of Object.entries(plot.identities))
      pool[identity] = (pool[identity] ?? 0) + n;
    if (plot.pair) pairs.push(plot.pair.join("/"));
  }
  for (const id of Object.keys(pool))
    pool[id] = Math.min(pool[id], pack.identities[id]?.max ?? Infinity);
  const inherentPool = { ...pool };
  if (setup.x.includes("捏造的秘密") && !setup.characters.some((c) => c.identity === "密钥")) {
    if (!setup.secretAddition || pool[setup.secretAddition])
      fail2(
        "invalid-secret-addition",
        "secretAddition",
        "Choose an absent killer, brain or causal fragment identity."
      );
    else pool[setup.secretAddition] = 1;
  }
  if (pack.module === "LL" && (!setup.privateRoles || Object.values(setup.privateRoles).sort().join("") !== "ABC" || !["p0", "p1", "p2"].every((p) => p in setup.privateRoles)))
    fail2(
      "missing-private-shuffle",
      "privateRoles",
      "The trusted host must supply a recorded permutation of A, B and C."
    );
  const ids = /* @__PURE__ */ new Set(), names = /* @__PURE__ */ new Set(), actual = {};
  for (const c of setup.characters) {
    const path = `characters.${c.id}`;
    if (!/^[a-zA-Z0-9_-]+$/.test(c.id) || BOARDS.includes(c.id) || ids.has(c.id) || ["__proto__", "constructor", "prototype"].includes(c.id))
      fail2(
        "invalid-id",
        path,
        "Character IDs must be unique safe identifiers distinct from boards."
      );
    ids.add(c.id);
    if (names.has(c.character))
      fail2("duplicate-character", path, "Each character card occurs once.");
    names.add(c.character);
    const def = pack.characters[c.character], identity = pack.identities[c.identity];
    if (!def?.supported)
      fail2("unsupported-character", path, `Untranslated or unknown character: ${c.character}`);
    if (!identity?.supported)
      fail2("unsupported-identity", path, `Untranslated or unknown identity: ${c.identity}`);
    if (c.reverseIdentity && !pack.identities[c.reverseIdentity]?.supported)
      fail2(
        "unsupported-identity",
        path,
        `Untranslated or unknown reverse identity: ${c.reverseIdentity}`
      );
    if (c.character === "临时工？")
      fail2("invalid-setup-card", path, "Replacement card cannot be assigned at setup.");
    if (c.character === "手下" && c.initialArea && !BOARDS.includes(c.initialArea))
      fail2("invalid-initial-area", path, "Henchman can only start on a board.");
    if (def && c.character !== "手下" && (def.initial.length > 1 ? !c.initialArea : c.initialArea && !def.initial.includes(c.initialArea)))
      fail2("invalid-initial-area", path, "Initial area must match the character definition.");
    if (c.initialArea && c.character !== "手下" && !def?.initial.includes(c.initialArea))
      fail2("invalid-initial-area", path, "Invalid initial area.");
    if (c.character === "转校生" && (!Number.isInteger(c.enterDay) || c.enterDay < 1 || c.enterDay > setup.days))
      fail2("missing-enter-day", path, "Transfer student requires an arrival day.");
    if (c.character === "神灵" && (!Number.isInteger(c.enterLoop) || c.enterLoop < 1 || c.enterLoop > setup.loops))
      fail2("missing-enter-loop", path, "Divinity requires an arrival loop.");
    if (c.character === "仙人" && (!Number.isSafeInteger(c.x) || c.x < 0))
      fail2("missing-x", path, "Immortal requires a nonnegative X.");
    if (def?.abilityArea && !BOARDS.includes(c[def.abilityArea.publicMarker]))
      fail2("missing-territory", path, "Boss requires a territory.");
    if (c.character === "AI" && c.identity === "平民" && !c.reverseIdentity)
      fail2("ai-civilian", path, "AI cannot be a civilian.");
    if (c.character === "妹妹" && identity?.ignore && !c.reverseIdentity)
      fail2(
        "sister-ignore",
        path,
        "Little sister cannot have a goodwill-refusing initial identity."
      );
    if (c.character === "局外人") {
      if (inherentPool[c.identity] || c.identity === "平民" || c.identity === "因果残片" || c.reverseIdentity || pairs.some((p) => p.split("/").includes(c.identity)))
        fail2(
          "outsider-pool",
          path,
          "Outsider must use a fixed module identity absent from both sides of selected rules."
        );
    } else if (c.character === "模仿犯") {
      const copied = setup.characters.find((t) => t.id === c.copiedFrom && t.id !== c.id);
      if (!copied || copied.identity !== c.identity || copied.reverseIdentity !== c.reverseIdentity)
        fail2(
          "copycat-identity",
          path,
          "Copycat must copy another complete configured identity pair."
        );
    } else if (c.reverseIdentity) assignedPairs.push(`${c.identity}/${c.reverseIdentity}`);
    else actual[c.identity] = (actual[c.identity] ?? 0) + 1;
    if (!c.reverseIdentity && ["强迫症", "愚者", "双胞胎", "祭品", "怪杰"].includes(c.identity) && !setup.incidents.some((i) => i.culprit === c.id))
      fail2("required-culprit", path, "Identity must be a scheduled culprit.");
    if (!c.reverseIdentity && c.identity === "侦探" && setup.incidents.some((i) => i.culprit === c.id))
      fail2("forbidden-culprit", path, "Detective cannot be a culprit.");
    if (setup.y === "和我签订契约吧！" && c.identity === "关键人物" && !def?.attributes.includes("少女") && c.character !== "局外人")
      fail2("required-attribute", path, "Key person must have the girl attribute.");
  }
  if (JSON.stringify(pairs.sort()) !== JSON.stringify(assignedPairs.sort()))
    fail2(
      "identity-pairs",
      "characters",
      "Paired identities must be allocated whole, with exact front/reverse pairing."
    );
  for (const identity of /* @__PURE__ */ new Set([...Object.keys(pool), ...Object.keys(actual)])) {
    if (identity === "平民") continue;
    const n = actual[identity] ?? 0, required = pool[identity] ?? 0;
    if (identity === "暴徒" && n <= required) continue;
    if (n !== required)
      fail2("identity-pool", "characters", `Expected ${required} ${identity}, got ${n}.`);
  }
  const days = /* @__PURE__ */ new Set();
  const culpritIncidents = /* @__PURE__ */ new Map();
  for (const i of setup.incidents) {
    if (!Number.isInteger(i.day) || i.day < 1 || i.day > setup.days || days.has(i.day))
      fail2("invalid-incident-day", "incidents", "At most one incident per valid day.");
    days.add(i.day);
    if (ids.has(i.culprit))
      culpritIncidents.set(i.culprit, [...culpritIncidents.get(i.culprit) ?? [], i.name]);
    if (pack.incidents[i.name]?.crowdThreshold !== void 0 ? !BOARDS.includes(i.culprit) : !ids.has(i.culprit))
      fail2(
        "invalid-culprit",
        "incidents",
        "Culprit must match the incident type (character or crowd board)."
      );
    if (!pack.incidents[i.name]?.supported)
      fail2("unsupported-incident", "incidents", `Pending incident: ${i.name}`);
    if (i.publicName && i.publicName !== i.name && i.name !== "伪造事件")
      fail2(
        "invalid-public-name",
        "incidents",
        "Only a forged incident can use a different public name."
      );
  }
  for (const [culprit, names2] of culpritIncidents)
    if (names2.length > 1 && names2.some((name) => name !== "连续杀人"))
      fail2(
        "repeated-culprit",
        `incidents.${culprit}`,
        "Only actual serial murders can share a character culprit."
      );
  for (const c of setup.characters)
    if (c.character === "临时工" && ids.has(`${c.id}_replacement`))
      fail2("reserved-id", `characters.${c.id}`, "Replacement character ID is reserved.");
  if (setup.x.includes("灭亡讴歌") && !setup.incidents.some((i) => i.name === "自杀"))
    fail2("required-incident", "incidents", "This rule requires suicide.");
  if (setup.x.includes("疯狂的真相") && (!setup.characters.some((c) => c.character === "情报商") || !setup.alternateY || pack.plots[setup.alternateY]?.type !== "Y" || setup.alternateY === setup.y))
    fail2(
      "missing-alternate-y",
      "alternateY",
      "Mad truth requires an informant and another configured Y loss condition."
    );
  if (setup.y === "男子汉的战争") {
    for (const c of setup.characters.filter(
      (c2) => c2.identity === "忍者" && c2.character !== "局外人"
    ))
      if (!pack.characters[c.character]?.attributes.includes("男性"))
        fail2(
          "required-attribute",
          `characters.${c.id}`,
          "Ninja must have the male attribute; boy is not a substitute."
        );
  }
  if (setup.x.includes("少女大危机")) {
    for (const c of setup.characters.filter(
      (c2) => c2.identity === "关键人物" && c2.character !== "局外人"
    ))
      if (!pack.characters[c.character]?.attributes.includes("少女"))
        fail2(
          "required-attribute",
          `characters.${c.id}`,
          "Key person must have the girl attribute."
        );
  }
  if (setup.x.includes("爱丽丝梦游仙境")) {
    for (const c of setup.characters.filter(
      (c2) => c2.identity === "爱丽丝" && c2.character !== "局外人"
    ))
      if (!pack.characters[c.character]?.attributes.includes("少女"))
        fail2("required-attribute", `characters.${c.id}`, "Alice must have the girl attribute.");
  }
  if (setup.y === "叛逆的世界") {
    for (const c of setup.characters.filter(
      (c2) => ["关键人物", "因果残片"].includes(c2.identity) && c2.character !== "局外人"
    ))
      if (!pack.characters[c.character]?.attributes.includes("少女"))
        fail2(
          "required-attribute",
          `characters.${c.id}`,
          "Both specified identities require the girl attribute."
        );
  }
  if (setup.y === "高贵的血族") {
    const keys = setup.characters.filter(
      (c) => c.identity === "关键人物" && c.character !== "局外人"
    );
    const vampires = setup.characters.filter(
      (c) => c.identity === "吸血鬼" && c.character !== "局外人"
    );
    const male = ["男性", "少年"], female = ["女性", "少女"];
    for (const a of keys)
      for (const b of vampires) {
        const aa = pack.characters[a.character]?.attributes ?? [], bb = pack.characters[b.character]?.attributes ?? [];
        if (!(male.some((t) => aa.includes(t)) && female.some((t) => bb.includes(t))) && !(female.some((t) => aa.includes(t)) && male.some((t) => bb.includes(t))))
          fail2(
            "opposite-sex-required",
            "characters",
            "Vampire and key person must have opposite sex attributes."
          );
      }
  }
  if (pack.anniversary) {
    const fragment2 = setup.characters.find((c) => c.id === setup.anniversaryFragment);
    if (!fragment2 || fragment2.identity !== "平民")
      fail2(
        "missing-anniversary-fragment",
        "anniversaryFragment",
        "Anniversary overlay requires one civilian after ordinary allocation."
      );
  } else if (setup.anniversaryFragment)
    fail2("unexpected-fragment", "anniversaryFragment", "No anniversary overlay is active.");
  return errors;
}
function createCards() {
  const cards = [];
  const protagonist = [
    "horizontal",
    "vertical",
    "block-movement",
    "goodwill+1",
    "goodwill+2",
    "paranoia+1",
    "paranoia-1",
    "block-intrigue"
  ];
  const mastermind = [
    "horizontal",
    "vertical",
    "diagonal",
    "block-goodwill",
    "paranoia+1",
    "paranoia+1",
    "paranoia-1",
    "block-paranoia",
    "intrigue+1",
    "intrigue+2"
  ];
  for (const owner of ["mastermind", "p0", "p1", "p2"])
    (owner === "mastermind" ? mastermind : protagonist).forEach(
      (kind, i) => cards.push({
        id: `${owner}-${i}`,
        owner,
        kind,
        once: ["goodwill+2", "diagonal", "intrigue+2", "paranoia+2"].includes(kind),
        status: "hand"
      })
    );
  return cards;
}
function initialState(pack, setup) {
  const characters = {};
  for (const c of setup.characters) {
    const def = pack.characters[c.character];
    const initialArea = c.initialArea ?? def.initial[0] ?? "hospital";
    const initialIdentity = setup.anniversaryFragment === c.id ? "因果残片" : c.identity;
    characters[c.id] = {
      id: c.id,
      character: c.character,
      initialIdentity,
      identity: c.character === "临时工" ? "平民" : initialIdentity,
      initialArea,
      area: initialArea,
      status: c.enterDay || (c.enterLoop ?? 1) > 1 ? "absent" : "alive",
      counters: zeroCounters(),
      flags: {},
      forbidden: [...def.forbidden],
      attributes: [...def.attributes],
      paranoiaLimit: c.x ?? def.paranoia,
      revealed: false
    };
  }
  const parttimer = setup.characters.find((c) => c.character === "临时工");
  if (parttimer) {
    const id = `${parttimer.id}_replacement`;
    if (characters[id]) throw new Error("Reserved replacement character identifier.");
    const def = pack.characters["临时工？"];
    characters[id] = {
      id,
      character: "临时工？",
      initialIdentity: parttimer.identity,
      identity: parttimer.identity,
      initialArea: "city",
      area: "city",
      status: "absent",
      counters: zeroCounters(),
      flags: {},
      forbidden: [],
      attributes: [...def.attributes],
      paranoiaLimit: 3,
      revealed: false
    };
  }
  return {
    schema: 1,
    ruleDigest: pack.digest,
    publicTerritory: setup.characters.find(
      (c) => pack.characters[c.character]?.abilityArea?.publicMarker === "territory"
    )?.territory,
    setup: clone(setup),
    revision: 0,
    loop: 1,
    day: 1,
    phase: "discussion",
    phaseEntered: false,
    captain: setup.captain,
    characters,
    boards: { hospital: 0, shrine: 0, city: 0, school: 0 },
    ex: 0,
    cards: createCards(),
    placements: [],
    failed: false,
    protagonistDead: false,
    endRequested: false,
    protected: false,
    flags: {},
    uses: {},
    previousLoop: null,
    incidents: [],
    revealedIdentities: [],
    appeared: [],
    frames: [],
    batch: null,
    pending: null,
    refusal: null,
    observations: { public: [], protagonists: [], mastermind: [] },
    audit: [],
    choices: [],
    receipts: {},
    serial: 0,
    ll: pack.module === "LL" ? {
      roles: clone(setup.privateRoles),
      communicated: [],
      died: [],
      finalTraitorsDisabled: false
    } : void 0
  };
}

// packages/engine/src/runtime/engine.ts
var seats = ["p0", "p1", "p2"];
var nextPhase = {
  "loop-start": "day-start",
  "day-start": "mastermind-cards",
  "mastermind-cards": "protagonist-cards",
  "protagonist-cards": "card-resolution",
  "card-resolution": "mastermind-abilities",
  "mastermind-abilities": "protagonist-abilities",
  "protagonist-abilities": "incident",
  incident: "captain-change",
  "captain-change": "day-end"
};
function initializeDiscussion(pack, setup, budget = 1e4) {
  return initializePhase(pack, setup, budget, "discussion");
}
function initializePhase(pack, setup, budget, phase) {
  const diagnostics = validateSetup(pack, setup);
  if (diagnostics.length) return { diagnostics };
  const state = initialState(pack, setup);
  state.phase = phase;
  if (phase === "discussion") beginDiscussion(state);
  drive(pack, state, budget);
  return { state, diagnostics };
}
function beginDiscussion(state) {
  enter(state, "discussion");
}
function environment(state, frame) {
  const configuration = state.setup.characters.find((c) => c.id === frame.owner);
  const env = {
    ...frame.bound,
    ...frame.choices,
    self: frame.owner,
    actor: frame.actor,
    sourceId: frame.id,
    sourceKind: frame.kind,
    territory: configuration?.territory ?? "",
    x: String(configuration?.x ?? 0),
    day: String(state.day),
    loop: String(state.loop)
  };
  if (frame.ability?.id === "forensic-transfer") env.forensicTransfer = "yes";
  for (const [key, id] of Object.entries(env)) {
    const c = state.characters[id];
    if (c) {
      env[`${key}.area`] = c.area;
      env[`${key}.initialArea`] = c.initialArea;
    }
  }
  const owner = state.characters[frame.owner];
  const incidentArea = frame.incidentAreas?.[env.areaMode ?? ""];
  if (incidentArea) env.effectiveArea = incidentArea;
  if (env.areaMode === "territory")
    env.effectiveArea = configuration?.territory ?? owner?.area ?? "";
  if (env.areaMode === "streamer")
    env.effectiveArea = state.characters[state.flags["streamer-target"] ?? ""]?.area ?? owner?.area ?? "";
  if (env.effectiveArea) env["self.area"] = env.effectiveArea;
  return env;
}
function options(pack, state, frame, spec) {
  const env = environment(state, frame);
  if (spec.key === "areaMode" && Array.isArray(spec.options) && frame.ability?.condition && !(frame.ability.mandatory && pack.characters[state.characters[frame.owner]?.character ?? ""]?.abilityArea))
    return spec.options.filter(
      (areaMode) => test(
        pack,
        state,
        frame.ability.condition,
        environment(state, { ...frame, choices: { ...frame.choices, areaMode } })
      )
    );
  if (frame.incident === "亵渎杀人" && spec.key === "branch" && !Object.values(state.characters).some(
    (c) => c.status === "alive" && c.id !== frame.owner && c.area === env["self.area"]
  ))
    return ["intrigue"];
  if (frame.ability?.id === "forensic-transfer" && spec.key === "counter") {
    const from = state.characters[env.from ?? ""], to = state.characters[env.to ?? ""];
    const present = COUNTERS.filter(
      (k) => (from?.counters[k] ?? 0) > 0 || (to?.counters[k] ?? 0) > 0
    );
    return present.length ? present : ["goodwill"];
  }
  if (!Array.isArray(spec.options)) return select(pack, state, spec.options, env);
  return [
    ...new Set(
      spec.options.flatMap((o) => {
        if (o === "$incident-days") return state.setup.incidents.map((i) => String(i.day));
        if (o === "$occurred-days")
          return state.incidents.filter((i) => i.loop === state.loop).map((i) => String(i.day));
        if (o === "$public-incidents")
          return state.setup.incidents.map((i) => i.publicName ?? i.name);
        if (o === "$all-x")
          return Object.values(pack.plots).filter((p) => p.type === "X").map((p) => p.name);
        if (o === "$other-selected-x") return state.setup.x.filter((x) => x !== env.excluded);
        if (o === "$ignore-goodwill-areas")
          return [
            ...new Set(
              Object.values(state.characters).filter((c) => c.status === "alive" && refusal(pack, state, c.id) !== "none").map((c) => c.area)
            )
          ].filter((a) => a !== "far");
        if (o === "$zombie-corpses")
          return select(
            pack,
            state,
            {
              kind: "dead",
              where: { cmp: "eq", left: { field: "identity", target: "$it" }, right: "丧尸" }
            },
            env
          );
        if (o === "$target-goodwill") {
          const target = env.target ?? "", c = state.characters[target];
          return c ? (pack.characters[c.character]?.abilities ?? []).filter(
            (a) => a.threshold !== void 0 && available(
              pack,
              state,
              target,
              { ...a, threshold: 0, cannotRefuse: true },
              frame.actor
            )
          ).map((a) => a.id) : [];
        }
        if (o === "$used-captain-cards")
          return state.cards.filter(
            (c) => c.owner === (frame.actor === "mastermind" ? "mastermind" : state.captain) && c.status === "used" && c.once
          ).map((c) => c.id);
        if (o === "$corpses-after-self-move") {
          if (!env.area) return [];
          const area = permitsMove(state, frame.owner, env.area) ? env.area : state.characters[frame.owner]?.area;
          return select(
            pack,
            state,
            {
              kind: "dead",
              where: {
                cmp: "eq",
                left: { field: "area", target: "$it" },
                right: area ?? ""
              }
            },
            env
          );
        }
        if (["$adjacent-self", "$adjacent-target", "$adjacent-any-self", "$adjacent-corpse"].includes(
          o
        )) {
          const self = o.endsWith("self");
          const c = state.characters[self ? frame.owner : env.target ?? ""];
          if (!c && env.target?.startsWith("victim:")) {
            const area2 = env.target.split(":")[1];
            return [destination(area2, ["horizontal"]), destination(area2, ["vertical"])];
          }
          const origin = self ? env.effectiveArea : void 0;
          const area = origin ?? c?.area;
          return c && area && area !== "far" ? [destination(area, ["horizontal"]), destination(area, ["vertical"])].filter(
            (a) => o === "$adjacent-any-self" || o === "$adjacent-corpse" || c.flags["free-movement"] || !c.forbidden.includes(a)
          ) : [];
        }
        return [ref(o, env)];
      })
    )
  ];
}
function useKeys(state, owner, ability, actor) {
  const base = ability.sharedKey ?? `${owner}:${ability.id}`;
  return [
    `phase:${state.loop}:${state.day}:${state.phase}:${actor}:${base}`,
    `loop:${state.loop}:${base}`
  ];
}
function available(pack, state, owner, ability, actor, allowEmpty = false) {
  const [phaseKey, loopKey] = useKeys(state, owner, ability, actor);
  if (!ability.mandatory && (state.uses[phaseKey] ?? 0) >= 1 || ability.loopLimit !== void 0 && (state.uses[loopKey] ?? 0) >= ability.loopLimit)
    return false;
  const frame = makeFrame(state, owner, ability, actor, false, false);
  const areaChoice = frame.steps[0]?.choices?.find((c) => c.key === "areaMode");
  if (areaChoice ? !options(pack, state, frame, areaChoice).some(
    (areaMode) => test(
      pack,
      state,
      ability.condition,
      environment(state, { ...frame, choices: { areaMode } })
    )
  ) : !test(pack, state, ability.condition, environment(state, frame)))
    return false;
  const counter = pack.module === "AHR" && state.ex % 2 === 1 && !(actor === "mastermind" && ["doctor-counter", "higher-being"].includes(ability.id)) ? "paranoia" : "goodwill";
  if (ability.threshold !== void 0 && effective(state, owner, counter) < ability.threshold)
    return false;
  return allowEmpty || canBind(pack, state, frame, 0);
}
function canBind(pack, state, frame, index) {
  const spec = frame.steps[0]?.choices?.[index];
  if (!spec) return true;
  for (const option of options(pack, state, frame, spec)) {
    const candidate = clone(frame);
    candidate.choices[spec.key] = option;
    if (canBind(pack, state, candidate, index + 1)) return true;
  }
  return Boolean(spec.optional || spec.allowEmpty);
}
function makeFrame(state, owner, ability, actor, cleanup = false, allocate = true) {
  const steps = clone(ability.steps);
  if (ability.id === "scholar-clear" && !["MC", "WM", "AHR"].includes(state.setup.module))
    steps.splice(1);
  return {
    id: allocate ? `source-${++state.serial}` : "preview",
    source: ability.source,
    owner,
    actor,
    kind: ability.mandatory ? "mandatory" : "ability",
    steps,
    step: 0,
    choices: {},
    bound: ability.declarationArea ? { areaMode: ability.declarationArea } : {},
    ability,
    cleanup
  };
}
function abilities(pack, state, timing, mandatory2, actor, only) {
  const result = [];
  for (const c of Object.values(state.characters)) {
    if (only && c.id !== only) continue;
    const cardScope = ["death", "incident-completed", "loop-end"].includes(timing);
    if (!cardScope && c.status !== "alive" && !(c.identity === "鬼魂" && c.status === "dead" && timing === "mastermind-abilities"))
      continue;
    const idAbilities = identities(state, c.id).flatMap(
      (id) => pack.identities[id]?.abilities ?? []
    );
    const characterAbilities = pack.characters[c.character]?.abilities ?? [];
    for (const ability of [...idAbilities, ...characterAbilities]) {
      const mastermindGoodwill = timing === "mastermind-abilities" && ability.timing === "protagonist-abilities" && refusal(pack, state, c.id) !== "none" && (c.character === "医生" && ability.id === "doctor-counter" && effective(state, c.id, "goodwill") >= 2 || c.character === "上位存在" && effective(state, c.id, "goodwill") >= 1 || pack.identities[c.identity]?.puppet || pack.module === "AHR" && state.setup.x.includes("傀儡之线"));
      if ((ability.timing === timing || mastermindGoodwill) && Boolean(ability.mandatory) === mandatory2) {
        let adjusted = mastermindGoodwill && c.character === "上位存在" ? { ...ability, threshold: 1 } : ability;
        const rule = pack.characters[c.character]?.abilityArea;
        const usesMarker = rule && actor === rule.actor && (c.status === "alive" || timing === "death");
        const virtualArea = usesMarker ? state.setup.characters.find((t) => t.id === c.id)?.[rule.publicMarker] : c.character === "UP主" ? state.characters[state.flags["streamer-target"] ?? ""]?.area : void 0;
        if (usesMarker && virtualArea && !mandatory2 && rule.selection === "before-declaration") {
          const chosen = state.flags["ability-area:" + c.id];
          const modes = chosen ? [chosen] : rule.modes;
          for (const mode of modes) {
            const variant = { ...adjusted, declarationArea: mode };
            if (available(pack, state, c.id, variant, actor))
              result.push({ owner: c.id, ability: variant });
          }
          continue;
        }
        if (virtualArea && adjusted.steps[0])
          adjusted = {
            ...adjusted,
            steps: [
              {
                ...adjusted.steps[0],
                choices: [
                  {
                    key: "areaMode",
                    options: usesMarker ? rule.modes : ["actual", "streamer"]
                  },
                  ...adjusted.steps[0].choices ?? []
                ]
              },
              ...adjusted.steps.slice(1)
            ]
          };
        if (available(pack, state, c.id, adjusted, actor, mandatory2))
          result.push({ owner: c.id, ability: adjusted });
      }
    }
  }
  if (!only)
    for (const name of [state.setup.y, ...state.setup.x])
      for (const a of pack.plots[name]?.abilities ?? []) {
        if (name === state.setup.y && state.flags["alternate-y"] && a.id === "loss") continue;
        if (a.timing === timing && Boolean(a.mandatory) === mandatory2 && available(pack, state, `plot:${name}`, a, actor))
          result.push({ owner: `plot:${name}`, ability: a });
      }
  if (!only && timing === "loop-end" && mandatory2 && state.flags["alternate-y"]) {
    for (const a of pack.plots[state.flags["alternate-y"]]?.abilities ?? [])
      if (a.id === "loss") result.push({ owner: `plot:${state.flags["alternate-y"]}`, ability: a });
  }
  if (!only) {
    for (const { owner, ability } of pack.moduleAbilities)
      if (ability.timing === timing && Boolean(ability.mandatory) === mandatory2 && available(pack, state, owner, ability, actor))
        result.push({ owner, ability });
  }
  return result;
}
function enqueueMandatory(pack, state, timing, owner, cleanup = false) {
  const frames = abilities(pack, state, timing, true, "mastermind", owner).map(
    (a) => makeFrame(state, a.owner, a.ability, "mastermind", cleanup)
  );
  if (frames.length)
    state.frames.unshift(
      ...frames.map((f) => ({
        ...f,
        bound: { ...f.bound, batchGroup: `mandatory:${state.serial}` }
      }))
    );
}
function decision(state, actor, kind, choices, binding) {
  state.pending = { id: `decision-${++state.serial}`, actor, kind, options: choices };
  if (binding) state.flags["pending-binding"] = binding;
  else delete state.flags["pending-binding"];
}
function clearAbilityAreas(state) {
  for (const key of Object.keys(state.flags))
    if (key.startsWith("ability-area:")) delete state.flags[key];
}
function requestAbilityArea(pack, state, list) {
  const pending = list.find(
    (a) => a.ability.declarationArea && !state.flags["ability-area:" + a.owner]
  );
  if (!pending) return false;
  const rule = pack.characters[state.characters[pending.owner].character].abilityArea;
  decision(
    state,
    rule.actor,
    "choice",
    rule.modes.map((value2) => ({ kind: "select", value: value2 })),
    "flag:ability-area:" + pending.owner
  );
  return true;
}
function enter(state, phase) {
  clearAbilityAreas(state);
  state.phase = phase;
  state.phaseEntered = false;
  announce(state, "boundary", { phase, captain: state.captain });
}
function visibleBoard(state) {
  return canonical({
    characters: Object.values(state.characters).map((c) => [c.id, c.area, c.status, c.counters]),
    boards: state.boards,
    ex: state.ex
  });
}
function incidentAreaFrom(origin, mode) {
  if (origin === "far" || mode === "actual") return origin;
  if (mode === "diagonal") return destination(origin, ["diagonal"]);
  return { hospital: "shrine", shrine: "school", school: "city", city: "hospital" }[origin];
}
function enqueueIncident(pack, state, name, culprit, actor, occurrence = false, nested = false) {
  const definition = pack.incidents[name];
  if (!definition) return null;
  if (name === "封锁" && !occurrence) return null;
  if (!definition.supported) {
    state.diagnostic = `Unsupported incident: ${name}`;
    return null;
  }
  if (definition.crowdThreshold !== void 0 && state.characters[culprit]?.character === "AI")
    culprit = "city";
  const c = state.characters[culprit];
  const steps = c?.character === "黑猫" ? [] : clone(definition.steps);
  if (c?.character === "教主" && !nested) steps.push(...clone(steps));
  const id = `source-${++state.serial}`;
  const bound2 = {
    beforeVisible: visibleBoard(state),
    firstOccurrence: occurrence && state.incidents.filter((i) => i.name === name && i.day === state.day).length === 1 ? "yes" : ""
  };
  if (definition.afterIncidentSteps) steps.push(...clone(definition.afterIncidentSteps));
  let incidentAreas;
  if (c && c.area !== "far" && steps[0]) {
    const baseMode = pack.identities[c.identity]?.baseIncidentArea ?? "actual";
    const offset = pack.characters[c.character]?.incidentAreaFromBase;
    const base = incidentAreaFrom(c.area, baseMode);
    const alternative = offset && incidentAreaFrom(base, offset);
    if (offset && alternative && alternative !== base) {
      const baseKey = baseMode === offset ? "base" : baseMode;
      incidentAreas = { [baseKey]: base, [offset]: alternative };
      steps[0].choices = [
        { key: "areaMode", options: Object.keys(incidentAreas), actor: "mastermind" },
        ...steps[0].choices ?? []
      ];
    } else if (base !== c.area) {
      incidentAreas = { [baseMode]: base };
      bound2.areaMode = baseMode;
    }
  }
  state.frames.unshift({
    id,
    source: definition.source,
    owner: culprit,
    actor,
    kind: "incident",
    steps,
    step: 0,
    choices: {},
    bound: bound2,
    incident: name,
    incidentAreas,
    occurrence,
    nestedIncident: nested,
    cleanup: false
  });
  return id;
}
function complete(pack, state, frame) {
  state.flags[`completed:${frame.id}`] = "yes";
  if (frame.ability)
    for (const key of useKeys(state, frame.owner, frame.ability, frame.actor))
      state.uses[key] = (state.uses[key] ?? 0) + 1;
  state.audit.push({
    kind: "source-completed",
    data: {
      id: frame.id,
      source: frame.source,
      ability: frame.ability?.id,
      incident: frame.incident
    }
  });
  if (frame.kind === "incident") {
    if (frame.occurrence && frame.bound.beforeVisible === visibleBoard(state))
      announce(state, "no-effect", { day: state.day });
    if (!frame.nestedIncident)
      enqueueMandatory(pack, state, "incident-completed", frame.owner, true);
  }
  if (frame.ability?.threshold !== void 0) {
    const previousFrames = new Set(state.frames);
    enqueueMandatory(pack, state, "goodwill-completed", frame.owner, true);
    const c = state.characters[frame.owner];
    if (c?.status === "alive" && c.identity === "童谣") {
      const ids = JSON.parse(frame.bound.targets ?? "[]");
      enqueueFlow(
        state,
        "fairytale-target-deaths",
        [{ effects: ids.map((target) => ({ op: "kill", target })) }],
        c.id
      );
      state.frames.at(-1).cleanup = true;
    }
    if (pack.module === "AHR" && frame.ability.loopLimit === 1) {
      enqueueFlow(state, "ahr-goodwill-world-move", [{ effects: [{ op: "world-move" }] }]);
      state.frames.at(-1).cleanup = true;
    }
    const group = `completion:${frame.id}`;
    for (const child of state.frames.filter(
      (f) => !previousFrames.has(f) && f.cleanup && !f.awaiting
    ))
      child.bound.batchGroup = group;
  }
}
function stageBatch(state) {
  const first = state.frames.shift();
  if (!first) return;
  const frames = [first];
  while (!first.awaiting && !state.frames[0]?.awaiting && first.bound.batchGroup && state.frames[0]?.bound.batchGroup === first.bound.batchGroup)
    frames.push(state.frames.shift());
  state.batch = {
    frames,
    snapshot: { characters: clone(state.characters), boards: clone(state.boards), ex: state.ex }
  };
}
function bindChoices(pack, state, frame, specs) {
  for (const spec of specs) {
    if (frame.choices[spec.key] !== void 0) continue;
    const choices = options(pack, state, frame, spec);
    if (spec.optional && choices.length) choices.push("~skip");
    if (!choices.length) {
      frame.choices[spec.key] = "";
      continue;
    }
    const actor = spec.actor === "captain" ? state.captain : spec.actor?.startsWith("$") ? ref(spec.actor, environment(state, frame)) : spec.actor ?? frame.actor;
    if (choices.length === 1) frame.choices[spec.key] = choices[0];
    else {
      decision(
        state,
        actor,
        "choice",
        choices.map((value2) => ({ kind: "select", value: value2 })),
        `frame:${frame.id}:${spec.key}`
      );
      if (spec.key === "areaMode") {
        state.pending.areas = Object.fromEntries(
          choices.map((mode) => [
            mode,
            environment(state, { ...frame, choices: { ...frame.choices, areaMode: mode } })["self.area"]
          ])
        );
      }
      return false;
    }
  }
  return true;
}
function processBatch(pack, state) {
  const batch = state.batch;
  if (batch.frames[0]?.awaiting) {
    const frame = batch.frames[0];
    state.batch = null;
    if (frame.awaiting.every((id) => state.flags[`completed:${id}`])) {
      delete frame.awaiting;
      if (frame.step >= frame.steps.length) complete(pack, state, frame);
      else if (!state.endRequested || frame.cleanup) state.frames.unshift(frame);
    } else if (state.frames.some((child) => frame.awaiting.includes(child.id)))
      state.frames.push(frame);
    return;
  }
  for (const frame of batch.frames) {
    const step = frame.steps[frame.step];
    if (!step) continue;
    if (!test(pack, state, step.condition, environment(state, frame))) {
      frame.bound.skipStep = "yes";
      continue;
    }
    const specs = step.choices ?? [];
    if (!bindChoices(
      pack,
      state,
      frame,
      specs.filter((s) => s.key === "areaMode")
    ))
      return;
    if (frame.step === 0 && frame.ability?.mandatory && frame.choices.areaMode && !test(pack, state, frame.ability.condition, environment(state, frame))) {
      frame.bound.inactive = "yes";
      frame.bound.skipStep = "yes";
      continue;
    }
    if (step.moveOthersFromEffectiveArea) {
      const origin = environment(state, frame)["self.area"];
      const targets = Object.values(state.characters).filter(
        (c) => c.status === "alive" && c.id !== frame.owner && c.area === origin
      );
      step.choices = [
        ...specs,
        ...targets.map((c) => ({
          key: "area_" + c.id,
          options: BOARDS.filter((b) => b !== origin)
        }))
      ];
      step.effects = targets.map((c) => ({ op: "move", target: c.id, area: "$area_" + c.id }));
      delete step.moveOthersFromEffectiveArea;
    }
    if (!bindChoices(
      pack,
      state,
      frame,
      (step.choices ?? []).filter((s) => s.key !== "areaMode")
    ))
      return;
    if (Object.values(frame.choices).includes("~skip")) frame.bound.skipStep = "yes";
    frame.bound.targets = JSON.stringify([
      .../* @__PURE__ */ new Set([
        ...JSON.parse(frame.bound.targets ?? "[]"),
        ...Object.values(frame.choices).filter((id) => state.characters[id]?.status === "alive")
      ])
    ]);
    if (frame.step === 0 && frame.ability?.threshold !== void 0 && frame.actor !== "mastermind" && !frame.bound.refusalChecked && !frame.bound.skipStep) {
      if (!frame.bound.declared) {
        announce(state, "declaration", {
          character: frame.owner,
          ability: frame.ability.id,
          choices: frame.choices
        });
        frame.bound.declared = "yes";
      }
      const mode = frame.ability.cannotRefuse ? "none" : refusal(pack, state, frame.owner);
      if (mode === "mandatory") {
        rejectAbility(pack, state, frame);
        frame.bound.refused = "yes";
      } else if (mode === "optional") {
        state.refusal = frame;
        decision(state, "mastermind", "refusal", [
          { kind: "refuse", refuse: false },
          { kind: "refuse", refuse: true }
        ]);
        return;
      }
      frame.bound.refusalChecked = "yes";
    }
    if (frame.step === 0 && frame.ability?.threshold !== void 0 && !frame.bound.refused && !frame.bound.skipStep && !frame.bound.communicated) {
      frame.bound.communicated = "yes";
      if (state.ll && !state.ll.communicated.includes(frame.owner)) {
        state.ll.communicated.push(frame.owner);
        announce(state, "board", { communicatedMarker: frame.owner });
        checkSpecialVictory(state);
      }
      if (state.latchedWinner) {
        frame.bound.refused = "game-interrupted";
      }
    }
  }
  const intents = batch.frames.flatMap(
    (f) => f.bound.skipStep || f.bound.refused ? [] : (f.steps[f.step]?.effects ?? []).map((effect) => ({ effect, env: environment(state, f) }))
  );
  const result = settle(pack, state, intents, state.flags);
  if (result.followChoices?.length) {
    const follow = result.followChoices[0];
    decision(
      state,
      follow.key.startsWith("reveal:") ? "mastermind" : state.captain,
      "choice",
      follow.options.map((value2) => ({ kind: "select", value: value2 })),
      `flag:${follow.key}`
    );
    return;
  }
  state.batch = null;
  const continuations = [];
  const children = /* @__PURE__ */ new Map();
  const addChild = (parent, child) => children.set(parent, [...children.get(parent) ?? [], child]);
  for (const invocation of result.invoked.reverse()) {
    const child = enqueueIncident(
      pack,
      state,
      invocation.name,
      invocation.culprit,
      invocation.actor,
      false,
      invocation.nested
    );
    if (child) addChild(invocation.parent, child);
  }
  for (const invocation of result.goodwill ?? []) {
    const c = state.characters[invocation.target];
    const ability = c && pack.characters[c.character]?.abilities.find((a) => a.id === invocation.ability);
    if (ability) {
      const frame = makeFrame(
        state,
        invocation.target,
        { ...ability, threshold: 0, cannotRefuse: true },
        invocation.actor
      );
      state.frames.unshift(frame);
      addChild(invocation.parent, frame.id);
    }
  }
  for (const f of batch.frames) {
    if (f.bound.refused || f.bound.inactive) continue;
    f.step++;
    delete f.bound.skipStep;
    for (const spec of f.steps[f.step]?.choices ?? []) delete f.choices[spec.key];
    if (children.has(f.id)) {
      f.awaiting = children.get(f.id);
      continuations.push(f);
    } else if (f.step < f.steps.length) continuations.push(f);
    else complete(pack, state, f);
  }
  state.frames.push(...continuations);
  const deathFrames = [];
  for (const id of result.died) {
    deathFrames.push(
      ...abilities(pack, state, "death", true, "mastermind", id).map(
        (a) => makeFrame(state, a.owner, a.ability, "mastermind", true)
      )
    );
    const dead = state.characters[id];
    const counterpart = dead.identity === "求爱者" ? "心上人" : dead.identity === "心上人" ? "求爱者" : "";
    if (counterpart)
      for (const c of Object.values(state.characters).filter(
        (c2) => c2.status === "alive" && c2.identity === counterpart
      ))
        deathFrames.push({
          id: `source-${++state.serial}`,
          source: pack.identities[counterpart].source,
          owner: c.id,
          actor: "mastermind",
          kind: "mandatory",
          steps: [{ effects: [{ op: "counter", target: c.id, counter: "paranoia", amount: 6 }] }],
          step: 0,
          choices: {},
          bound: {},
          cleanup: true
        });
  }
  if (deathFrames.length) {
    const group = `death:${++state.serial}`;
    state.frames.unshift(
      ...deathFrames.map((f) => ({ ...f, bound: { ...f.bound, batchGroup: group } }))
    );
  }
  const due = (state.delayed ?? []).filter(
    (t) => t.loop === state.loop && t.day === state.day && t.timing === state.phase
  );
  state.delayed = (state.delayed ?? []).filter((t) => !due.includes(t));
  for (const task of due) {
    const f = {
      id: `source-${++state.serial}`,
      source: "immediate-due",
      owner: "",
      actor: "mastermind",
      kind: "mandatory",
      steps: [{ effects: task.effects }],
      step: 0,
      choices: {},
      bound: task.env,
      cleanup: true
    };
    state.frames.unshift(f);
  }
}
function rejectAbility(pack, state, frame) {
  announce(state, "refused", { character: frame.owner, ability: frame.ability.id });
  frame.bound.refused = "yes";
  frame.bound.refusalChecked = "yes";
  if (pack.module === "WM") {
    state.ex++;
    state.flags["ex-increased"] = "yes";
    announce(state, "board", { ex: state.ex });
  }
}
function resetLoop(pack, state) {
  const before = clone(state);
  for (const config of state.setup.characters) {
    const c = state.characters[config.id], def = pack.characters[c.character];
    c.status = config.enterDay || (config.enterLoop ?? 1) > state.loop ? "absent" : "alive";
    c.area = c.initialArea = config.initialArea ?? def.initial[0] ?? "hospital";
    c.counters = zeroCounters();
    c.flags = {};
    c.forbidden = [...def.forbidden];
    c.identity = c.character === "临时工" ? "平民" : c.initialIdentity;
    if (state.setup.y === "虚幻世界" && c.initialIdentity === "强迫症" && !config.reverseIdentity && !["局外人", "模仿犯"].includes(c.character))
      c.flags["y-obsessive"] = "yes";
  }
  for (const c of Object.values(state.characters).filter((c2) => c2.character === "临时工？")) {
    c.status = "absent";
    c.area = "city";
    c.counters = zeroCounters();
    c.flags = {};
    c.identity = c.initialIdentity;
  }
  state.boards = { hospital: 0, shrine: 0, city: 0, school: 0 };
  state.cards = state.cards.map((c) => ({
    ...c,
    status: c.status === "removed" ? "removed" : "hand"
  }));
  state.day = 1;
  state.failed = false;
  state.protagonistDead = false;
  state.endRequested = false;
  state.protected = false;
  state.flags = {};
  state.uses = {};
  state.placements = [];
  state.curses = [];
  state.delayed = (state.delayed ?? []).filter((t) => t.loop >= state.loop);
  if (pack.module !== "WM") state.ex = 0;
  if (pack.module === "AHR") {
    for (const actor of seats)
      if (!state.cards.some((c) => c.owner === actor && c.kind === "paranoia+2"))
        state.cards.push({
          id: `${actor}-paranoia+2`,
          owner: actor,
          kind: "paranoia+2",
          once: true,
          status: "hand"
        });
    if (!state.cards.some((c) => c.owner === "mastermind" && c.kind === "goodwill+1"))
      state.cards.push({
        id: "mastermind-goodwill+1",
        owner: "mastermind",
        kind: "goodwill+1",
        once: false,
        status: "hand"
      });
    if (state.loop === 1) grantCard(state, "mastermind", "despair+1");
  }
  publishChanges(before, state);
}
function startLoop(state) {
  const effects = [];
  for (const c of Object.values(state.characters)) {
    if (c.status !== "alive") continue;
    if (!state.appeared.includes(c.id)) state.appeared.push(c.id);
    if (c.character === "黑猫")
      effects.push({
        effect: { op: "counter", target: "shrine", counter: "intrigue", amount: 1 },
        env: {}
      });
    if (c.identity === "亲友" && c.revealed)
      effects.push({
        effect: { op: "counter", target: c.id, counter: "goodwill", amount: 1 },
        env: {}
      });
    const previous = state.previousLoop?.characters[c.id];
    if (c.identity === "因果残片" && previous) {
      if (previous.status === "dead") grantCard(state, "mastermind", "despair+1");
      if (previous.status === "alive" && previous.counters.goodwill + previous.counters.hope >= 2)
        for (const actor of seats) grantCard(state, actor, "hope+1");
    }
    if (c.identity === "叙述者" && state.previousLoop && state.previousLoop.ex >= 3)
      for (const actor of seats) grantCard(state, actor, "hope+1");
    if (state.setup.x.includes("因果线") && previous && previous.counters.goodwill + previous.counters.hope > 0)
      effects.push({
        effect: { op: "counter", target: c.id, counter: "paranoia", amount: 2 },
        env: {}
      });
  }
  if (state.setup.x.includes("超越世界线")) {
    if (state.loop % 2 === 0) grantCard(state, "mastermind", "despair+1");
    if (state.loop === state.setup.loops)
      for (const actor of seats) grantCard(state, actor, "hope+1");
  }
  if (effects.length)
    enqueueFlow(state, "loop-start-base", [{ effects: effects.map((i) => i.effect) }]);
  for (const c of Object.values(state.characters).filter(
    (c2) => c2.status === "alive" && c2.character === "学者"
  ))
    enqueueFlow(
      state,
      "scholar-start",
      [
        {
          choices: [{ key: "counter", options: ["goodwill", "paranoia", "intrigue"] }],
          effects: [{ op: "counter", target: c.id, counter: "$counter", amount: 1 }]
        }
      ],
      c.id
    );
  if ((state.setup.y === "因果之绊" || state.setup.x.includes("诸神之骰")) && state.previousLoop) {
    const targets = Object.values(state.characters).filter(
      (c) => c.status === "alive" && state.previousLoop.characters[c.id]?.status === "dead"
    ).map((c) => c.id);
    if (targets.length)
      enqueueFlow(state, "previous-death-ex", [
        {
          choices: [{ key: "target", options: targets }],
          effects: [{ op: "flag", target: "$target", key: "causal-ex" }]
        }
      ]);
  }
  if (state.setup.x.includes("隔离病房惊魂记") && state.previousLoop && state.previousLoop.ex <= 2)
    enqueueFlow(state, "quarantine", [{ effects: [{ op: "ex", amount: 1 }] }]);
  if (state.setup.x.includes("疯狂的真相") && state.ex >= 2)
    state.flags["alternate-y"] = state.setup.alternateY ?? "";
}
function enqueueFlow(state, source, steps, owner = "", actor = "mastermind") {
  state.frames.push({
    id: `source-${++state.serial}`,
    source,
    owner,
    actor,
    kind: "mandatory",
    steps,
    step: 0,
    choices: {},
    bound: {},
    cleanup: false
  });
}
function legalCardTargets(state, actor) {
  const ownSide = (owner) => actor === "mastermind" ? owner === "mastermind" : owner !== "mastermind";
  const placed = state.placements.filter((p) => ownSide(state.cards.find((c) => c.id === p.card).owner)).map((p) => p.target);
  return [
    ...BOARDS,
    ...Object.values(state.characters).filter(
      (c) => c.status === "alive" && c.character !== "幻想" && (actor !== "mastermind" || !["预言家", "狼人"].includes(c.identity)) && (actor === "mastermind" || !c.flags["no-protagonist-cards"] && !(state.flags["ex-cards-restricted"] && (c.flags["causal-ex"] || state.flags["streamer-target"] === c.id)))
    ).map((c) => c.id)
  ].filter((t) => !placed.includes(t));
}
function cardCount(state, actor) {
  return actor === "mastermind" ? Number(state.flags[`mastermind-cards:${state.day}`] ?? 3) : 1;
}
function resolveCards(pack, state, part) {
  const intents = [];
  const placements = state.placements.map((p) => ({
    ...p,
    card: state.cards.find((c) => c.id === p.card)
  }));
  const globalBlocks = placements.filter((p) => p.card.kind === "block-intrigue").length;
  const hopes = placements.filter((p) => p.card.kind === "hope+1").length;
  for (const target of [
    ...BOARDS,
    ...Object.values(state.characters).filter((c) => c.status === "alive").map((c) => c.id)
  ]) {
    const c = state.characters[target];
    const group = placements.filter(
      (p) => p.target === target || c?.character === "幻想" && p.target === c.area
    );
    const kinds = group.map((p) => p.card.kind);
    if (part === 0 && c && !kinds.includes("block-movement") && !(state.setup.x.includes("心无灵犀") && kinds.includes("block-goodwill"))) {
      const area = destination(
        c.area,
        kinds.filter((k) => ["horizontal", "vertical", "diagonal"].includes(k))
      );
      if (area !== c.area) intents.push({ effect: { op: "move", target, area }, env: {} });
    }
    if (part > 0)
      for (const original of kinds) {
        const kind = original === "hope+1" && hopes >= 2 ? "goodwill+1" : original;
        const [counter, magnitude] = kind.split(/(?=[+-])/);
        if (!["goodwill", "paranoia", "intrigue", "hope", "despair"].includes(counter) || !magnitude)
          continue;
        const n = Number(magnitude);
        if (part === 1 && n < 0 || part === 2 && n > 0) continue;
        if (counter === "goodwill" && kinds.includes("block-goodwill") && (!identities(state, target).some((i) => ["时间旅者", "次元旅者"].includes(i)) || group.some((p) => p.card.kind === "block-goodwill" && p.target !== target)))
          continue;
        if (counter === "paranoia" && kinds.includes("block-paranoia")) continue;
        const cultist = Object.values(state.characters).some(
          (t) => t.status === "alive" && t.flags.cultist && (t.flags["cultist-area"] ?? t.area) === (c?.area ?? target)
        );
        if (counter === "intrigue" && kinds.includes("block-intrigue") && (globalBlocks < 2 || pack.module === "WM" && state.ex >= 3) && !cultist)
          continue;
        intents.push({
          effect: {
            op: "counter",
            target,
            counter,
            amount: n
          },
          env: {}
        });
      }
  }
  const result = settle(pack, state, intents, state.flags);
  if (result.followChoices?.length) {
    const follow = result.followChoices[0];
    decision(
      state,
      state.captain,
      "choice",
      follow.options.map((value2) => ({ kind: "select", value: value2 })),
      `flag:${follow.key}`
    );
    return;
  }
  state.flags["cards-part"] = String(part + 1);
}
function hasSameAreaTrigger(pack, state, owner) {
  const condition = pack.identities[owner.identity]?.sameAreaIncidentTrigger;
  return owner.status === "alive" && condition !== void 0 && test(pack, state, condition, { self: owner.id });
}
function triggerAreaKey(state, owner) {
  return `incident-trigger-area:${state.loop}:${state.day}:${owner.id}`;
}
function incidentCulprits(state, original) {
  return original.character === "临时工" ? [original, ...Object.values(state.characters).filter((c) => c.character === "临时工？")] : [original];
}
function occur(pack, state) {
  const i = state.setup.incidents.find((i2) => i2.day === state.day);
  if (!i) return;
  const original = state.characters[i.culprit];
  if (pack.incidents[i.name]?.crowdThreshold !== void 0) {
    const corpses = select(
      pack,
      state,
      {
        kind: "dead",
        where: { cmp: "eq", left: { field: "area", target: "$it" }, right: i.culprit }
      },
      {}
    ).length;
    const occurred = corpses >= pack.incidents[i.name].crowdThreshold;
    announce(state, "incident", { day: i.day, name: i.publicName ?? i.name, occurred });
    if (occurred) {
      state.incidents.push({
        loop: state.loop,
        day: i.day,
        name: i.name,
        publicName: i.publicName ?? i.name,
        culprit: i.culprit
      });
      enqueueIncident(pack, state, i.name, i.culprit, "mastermind", true);
    }
    return;
  }
  const culprits = incidentCulprits(state, original);
  const triggered = [];
  for (const c of culprits) {
    const definition2 = pack.incidents[i.name];
    let threshold = c.paranoiaLimit + (definition2.thresholdOffset ?? 0) * (c.character === "教主" ? 2 : 1);
    if (state.setup.x.includes("灭亡讴歌") && c.identity === "平民" && Object.values(state.characters).some((t) => t.identity === "预言家" && t.status === "alive"))
      threshold--;
    const prophet = Object.values(state.characters).some(
      (t) => t.id !== c.id && t.status === "alive" && t.identity === "预言家" && t.area === c.area
    );
    const sameAreaTrigger = Object.values(state.characters).some(
      (owner) => hasSameAreaTrigger(pack, state, owner) && (state.flags[triggerAreaKey(state, owner)] === "territory" ? state.setup.characters.find((s) => s.id === owner.id)?.territory : owner.area) === c.area
    );
    const watcher = c.counters.despair > 0 && Object.values(state.characters).some(
      (t) => t.status === "alive" && t.identity === "监视者" && t.area === c.area
    );
    let paranoia = effective(
      state,
      c.id,
      definition2.thresholdCounter ?? (pack.module === "AHR" && state.ex % 2 === 1 ? "goodwill" : "paranoia")
    );
    const ordinaryParanoia = !definition2.thresholdCounter && !(pack.module === "AHR" && state.ex % 2 === 1);
    if (ordinaryParanoia && c.character === "AI")
      paranoia = COUNTERS.reduce((n, k) => n + c.counters[k], 0);
    else if (ordinaryParanoia && (c.identity === "祭品" || state.setup.y === "士的宁毒液" && ["连续杀人", "自杀"].includes(i.name)))
      paranoia += c.counters.intrigue;
    const occurred = c.status === "alive" && !c.flags["no-incidents"] && !prophet && (c.identity === "强迫症" || i.name === "次元转换" || sameAreaTrigger || watcher || paranoia >= threshold);
    if (occurred) triggered.push(c.id);
  }
  announce(state, "incident", {
    day: i.day,
    name: i.publicName ?? i.name,
    occurred: triggered.length > 0
  });
  if (!triggered.length) return;
  const definition = pack.incidents[i.name];
  const first = !state.incidents.some((t) => t.name === i.name && t.day === i.day);
  state.flags["first-occurrence"] = first ? "yes" : "";
  state.incidents.push({
    loop: state.loop,
    day: i.day,
    name: i.name,
    publicName: i.publicName ?? i.name,
    culprit: i.culprit
  });
  if (state.flags.hound) state.flags["hound-due"] = "yes";
  if (pack.module === "MC") {
    state.ex += original.character === "黑猫" ? 1 : definition.exGain ?? 1;
    announce(state, "board", { ex: state.ex });
  }
  const group = `incident:${++state.serial}`;
  for (const culprit of triggered) {
    enqueueIncident(pack, state, i.name, culprit, "mastermind", true);
    if (state.frames[0]) state.frames[0].bound.batchGroup = group;
  }
}
function finalizeLoop(pack, state) {
  state.previousLoop = {
    characters: clone(state.characters),
    boards: clone(state.boards),
    ex: state.ex
  };
  if (!state.failed && !state.protagonistDead) {
    win(state, "protagonists");
    return;
  }
  if (state.loop < state.setup.loops && !(pack.module === "WM" && state.ex >= 4)) {
    state.loop++;
    enter(state, "discussion");
    return;
  }
  if (pack.module === "FS") {
    win(state, "mastermind");
    return;
  }
  prepareFinalGuess(state);
}
function prepareFinalGuess(state) {
  if (state.ll) {
    if (state.setup.y === "最终计划" && state.loop === state.setup.loops && Object.values(state.characters).some((c) => c.identity === "关键人物" && c.counters.hope > 0))
      state.ll.finalTraitorsDisabled = true;
    state.ll.finalEligible = seats.filter((p) => !traitors(state).includes(p));
  }
  for (const c of Object.values(state.characters)) {
    c.counters = zeroCounters();
    if (state.appeared.includes(c.id)) c.status = "alive";
    c.identity = c.initialIdentity;
    c.area = c.initialArea;
  }
  state.boards = { hospital: 0, shrine: 0, city: 0, school: 0 };
  state.ex = 0;
  state.flags["guessed"] = "[]";
  enter(state, "final-guess");
}
function win(state, winner) {
  state.winner = winner;
  state.winners = winner === "protagonists" ? state.ll?.finalEligible ?? seats.filter((p) => !traitors(state).includes(p)) : [winner];
  enter(state, "finished");
  announce(state, "victory", { winner, winners: state.winners });
}
function drive(pack, state, budget) {
  if (!Number.isSafeInteger(budget) || budget < 0)
    throw new Error("Budget must be a nonnegative integer.");
  if (pack.digest !== state.ruleDigest) throw new Error("Rule pack mismatch.");
  for (let n = 0; n < budget; n++) {
    if (state.diagnostic) return "paused";
    if (state.pending || state.winner) return "ok";
    if (state.phase === "briefing") {
      decision(state, state.captain, "continue", [{ kind: "start" }]);
      return "ok";
    }
    if (state.latchedWinner && !state.batch) {
      state.frames = state.frames.filter((f) => f.cleanup);
      if (!state.frames.length) {
        win(state, state.latchedWinner);
        continue;
      }
    }
    if (state.batch) {
      processBatch(pack, state);
      continue;
    }
    if (state.endRequested && state.phase !== "loop-end" && state.phase !== "final-guess")
      state.frames = state.frames.filter((f) => f.cleanup || f.awaiting);
    if (state.frames.length) {
      stageBatch(state);
      continue;
    }
    if (state.endRequested && state.phase !== "loop-end" && state.phase !== "final-guess" && state.phase !== "discussion") {
      enter(state, "loop-end");
      continue;
    }
    if (!state.phaseEntered) {
      if (state.phase === "day-end" && pack.module === "AHR" && state.flags["world-moved"]) {
        delete state.flags["world-moved"];
        settle(pack, state, [{ effect: { op: "ex", amount: 1 }, env: {} }]);
      }
      if (state.phase === "day-end" && pack.module === "HSA" && !state.flags[`curses:${state.day}`]) {
        state.flags[`curses:${state.day}`] = "yes";
        delete state.flags["curse-no-target"];
        const group = `curses:${++state.serial}`;
        for (const curse of state.curses ?? []) {
          if (BOARDS.includes(curse.target)) {
            const targets = Object.values(state.characters).filter((c) => c.status === "alive" && c.area === curse.target).map((c) => c.id);
            if (targets.length)
              enqueueFlow(state, "curse-attach", [
                {
                  choices: [{ key: "target", options: targets }],
                  effects: [{ op: "curse", id: curse.id, target: "$target" }]
                }
              ]);
            else state.flags["curse-no-target"] = "yes";
          } else {
            const c = state.characters[curse.target];
            if (!c || ["removed", "absent"].includes(c.status)) continue;
            enqueueFlow(
              state,
              "curse-death",
              [
                { effects: [{ op: "kill", target: c.id }] },
                { effects: [{ op: "curse", id: curse.id, target: c.area }] }
              ],
              c.id
            );
          }
        }
        for (const f of state.frames) f.bound.batchGroup = group;
        if (state.frames.length) continue;
      }
      if (state.phase === "loop-start" && !state.flags["placements-done"]) {
        state.flags["placements-done"] = "yes";
        for (const c of Object.values(state.characters).filter((c2) => c2.character === "手下"))
          enqueueFlow(
            state,
            "henchman-placement",
            [
              {
                choices: [{ key: "area", options: { kind: "boards" } }],
                effects: [{ op: "place", target: c.id, area: "$area" }]
              }
            ],
            c.id
          );
        if (state.frames.length) continue;
      }
      if (state.phase === "incident") {
        const scheduled = state.setup.incidents.find((i) => i.day === state.day);
        const culprit = scheduled && state.characters[scheduled.culprit];
        if (culprit) {
          const culprits = incidentCulprits(state, culprit);
          for (const owner of Object.values(state.characters)) {
            const rule = pack.characters[owner.character]?.abilityArea;
            if (!rule || !hasSameAreaTrigger(pack, state, owner)) continue;
            const key = triggerAreaKey(state, owner);
            const territory = state.setup.characters.find((c) => c.id === owner.id)?.[rule.publicMarker];
            if (!state.flags[key] && territory && territory !== owner.area && culprits.some(
              (c) => c.status === "alive" && (owner.area === c.area || territory === c.area)
            )) {
              decision(
                state,
                rule.actor,
                "choice",
                rule.modes.map((value2) => ({ kind: "select", value: value2 })),
                "flag:" + key
              );
              return "ok";
            }
          }
        }
      }
      state.phaseEntered = true;
      checkSpecialVictory(state);
      if (state.latchedWinner) continue;
      if (state.phase === "loop-start") startLoop(state);
      if (state.phase === "day-start") {
        const before = clone(state);
        for (const c of Object.values(state.characters)) delete c.flags.immobile;
        delete state.flags["mad-night-today"];
        for (const c of state.setup.characters)
          if (c.enterDay === state.day && (c.enterLoop ?? 1) <= state.loop && state.characters[c.id].status === "absent")
            state.characters[c.id].status = "alive";
        const parttimer = Object.values(state.characters).find((c) => c.character === "临时工");
        const replacement = Object.values(state.characters).find((c) => c.character === "临时工？");
        if (parttimer?.status === "dead" && replacement?.status === "absent") {
          replacement.status = "alive";
          replacement.area = "city";
        }
        for (const c of Object.values(state.characters))
          if (c.status === "alive" && !state.appeared.includes(c.id)) state.appeared.push(c.id);
        publishChanges(before, state);
        if (pack.module === "WM" && state.day === 1 && state.ex >= 1)
          enqueueFlow(
            state,
            "wm-invocation",
            [
              {
                choices: [{ key: "target", options: { kind: "alive" }, optional: true }],
                effects: [{ op: "counter", target: "$target", counter: "goodwill", amount: 2 }]
              }
            ],
            "",
            state.captain
          );
      }
      if (state.phase === "incident") occur(pack, state);
      if (state.phase === "captain-change")
        state.captain = seats[(seats.indexOf(state.captain) + 1) % 3];
      if (state.phase === "card-resolution") {
        announce(state, "cards", {
          placements: state.placements.map((p) => ({
            owner: state.cards.find((c) => c.id === p.card).owner,
            target: p.target,
            kind: state.cards.find((c) => c.id === p.card).kind
          }))
        });
        state.flags["cards-part"] = "0";
      }
      if (state.phase === "loop-end" && state.revealedIdentities.some(
        (r) => r.loop === state.loop && ["主谋", "不安定因子", "魔术师"].includes(r.identity)
      ))
        state.flags["classified-revealed"] = "yes";
      enqueueMandatory(pack, state, state.phase);
      const due = (state.delayed ?? []).filter(
        (t) => t.loop === state.loop && t.day === state.day && t.timing === state.phase
      );
      state.delayed = (state.delayed ?? []).filter((t) => !due.includes(t));
      for (const task of due) {
        enqueueFlow(state, "delayed", [{ effects: task.effects }], task.env.self ?? "");
        Object.assign(state.frames.at(-1).bound, task.env);
      }
      if (state.phase === "loop-end" && pack.module === "WM" && state.ex >= 2)
        enqueueFlow(state, "wm-ancestral-memory", [
          { effects: [{ op: "reveal-rule", rule: state.setup.x[0] }] }
        ]);
      if (state.phase === "day-end" && pack.module === "WM" && state.ex >= 4)
        enqueueFlow(state, "wm-madness", [{ effects: [{ op: "protagonist-death" }] }]);
      if (state.phase === "mastermind-abilities")
        for (const c of Object.values(state.characters).filter(
          (c2) => c2.status === "alive" && c2.character === "御神木" && refusal(pack, state, c2.id) !== "none"
        )) {
          const a = pack.characters[c.character].abilities[0];
          state.frames.push(makeFrame(state, c.id, { ...a, mandatory: true }, "mastermind"));
        }
      if (state.phase === "day-end") {
        if (pack.module === "HSA") {
          const boards = BOARDS.filter((board2) => {
            const zombies = select(
              pack,
              state,
              {
                kind: "dead",
                where: {
                  all: [
                    { cmp: "eq", left: { field: "area", target: "$it" }, right: board2 },
                    { cmp: "eq", left: { field: "identity", target: "$it" }, right: "丧尸" }
                  ]
                }
              },
              {}
            ).length;
            const alive2 = Object.values(state.characters).filter(
              (c) => c.status === "alive" && c.area === board2
            );
            return alive2.length > 0 && zombies + alive2.filter((c) => c.identity === "丧尸").length > alive2.filter((c) => c.identity !== "丧尸").length;
          });
          if (boards.length)
            enqueueFlow(state, "zombie-kill", [
              {
                choices: [
                  { key: "area", options: boards },
                  {
                    key: "target",
                    options: {
                      kind: "alive",
                      where: {
                        cmp: "eq",
                        left: { field: "area", target: "$it" },
                        right: { ref: "$area" }
                      }
                    }
                  }
                ],
                effects: [{ op: "kill", target: "$target" }]
              }
            ]);
        }
        const firstIncident = state.incidents.find((i) => i.loop === state.loop);
        const streamer = Object.values(state.characters).find(
          (c) => c.character === "UP主" && c.status === "alive"
        );
        if (streamer && firstIncident?.day === state.day)
          enqueueFlow(
            state,
            "streamer-first-incident",
            [
              {
                choices: [
                  {
                    key: "target",
                    options: {
                      kind: "alive",
                      where: {
                        any: [
                          { attribute: "少年", target: "$it" },
                          { attribute: "少女", target: "$it" }
                        ]
                      }
                    }
                  }
                ],
                effects: [{ op: "flag", key: "streamer-target", value: "$target" }]
              }
            ],
            streamer.id
          );
        const specials = Object.values(state.characters).filter(
          (c) => c.status === "alive" && c.character === "临时工" && COUNTERS.reduce((n2, k) => n2 + c.counters[k], 0) >= 3
        ).map((c) => ({ effect: { op: "kill", target: c.id }, env: {} }));
        if (specials.length)
          state.frames.push({
            id: `source-${++state.serial}`,
            source: "character.parttimer",
            owner: "",
            actor: "mastermind",
            kind: "mandatory",
            steps: [{ effects: specials.map((i) => i.effect) }],
            step: 0,
            bound: { batchGroup: state.frames[0]?.bound.batchGroup ?? `mandatory:${state.serial}` },
            choices: {},
            cleanup: false
          });
      }
      if (state.frames.length > 1 && ["loop-start", "mastermind-abilities", "day-end"].includes(state.phase)) {
        const group = `phase:${++state.serial}`;
        for (const f of state.frames) f.bound.batchGroup = group;
      }
      continue;
    }
    if (state.phase === "discussion") {
      if (state.flags["final-guess-votes"]) {
        const votes = JSON.parse(state.flags["final-guess-votes"]);
        const actor = seats.find((p) => !votes.includes(p));
        if (!actor) {
          delete state.flags["final-guess-votes"];
          prepareFinalGuess(state);
          continue;
        }
        decision(state, actor, "choice", [
          { kind: "vote-final-guess", agree: true },
          { kind: "vote-final-guess", agree: false }
        ]);
        return "ok";
      }
      decision(state, state.captain, "continue", [
        { kind: "continue" },
        ...pack.module === "FS" ? [] : [{ kind: "request-final-guess" }]
      ]);
      return "ok";
    }
    if (state.phase === "mastermind-cards" || state.phase === "protagonist-cards") {
      const protagonistCount = state.placements.filter(
        (p) => state.cards.find((c) => c.id === p.card).owner !== "mastermind"
      ).length;
      if (state.phase === "mastermind-cards" && state.placements.some(
        (p) => state.cards.find((c) => c.id === p.card).owner === "mastermind"
      ) || protagonistCount === 3) {
        enter(state, nextPhase[state.phase]);
        continue;
      }
      const actor = state.phase === "mastermind-cards" ? "mastermind" : seats[(seats.indexOf(state.captain) + protagonistCount) % 3];
      decision(state, actor, "cards", []);
      return "ok";
    }
    if (state.phase === "card-resolution") {
      const part = Number(state.flags["cards-part"]);
      if (part === 1 && !state.flags["cultist-done"]) {
        const availableCultists = abilities(pack, state, "card-resolution", false, "mastermind");
        if (requestAbilityArea(pack, state, availableCultists)) return "ok";
        if (availableCultists.length) {
          decision(state, "mastermind", "ability", [
            { kind: "pass" },
            ...availableCultists.map((a) => ({
              kind: "ability",
              owner: a.owner,
              ability: a.ability.id
            }))
          ]);
          return "ok";
        }
        state.flags["cultist-done"] = "yes";
      }
      if (part < 3) {
        resolveCards(pack, state, part);
        continue;
      }
      const hopeCount = state.cards.filter((c) => c.status === "set" && c.kind === "hope+1").length;
      for (const c of state.cards.filter((c2) => c2.status === "set"))
        c.status = c.kind === "hope+1" ? hopeCount >= 2 ? "hand" : "removed" : c.once ? "used" : "hand";
      if (hopeCount === 1)
        for (const c of state.cards.filter((c2) => c2.kind === "hope+1")) c.status = "removed";
      state.placements = [];
      delete state.flags["cultist-done"];
      for (const c of Object.values(state.characters)) {
        delete c.flags.cultist;
        delete c.flags["cultist-area"];
      }
      enter(state, "mastermind-abilities");
      continue;
    }
    if ([
      "mastermind-abilities",
      "protagonist-abilities",
      "day-end",
      "loop-start",
      "loop-end"
    ].includes(state.phase)) {
      const actor = state.phase === "protagonist-abilities" ? state.captain : "mastermind";
      const list = abilities(pack, state, state.phase, false, actor);
      if (!state.flags[`passed:${state.phase}`] && requestAbilityArea(pack, state, list))
        return "ok";
      if (list.length && !state.flags[`passed:${state.phase}`]) {
        decision(state, actor, "ability", [
          { kind: "pass" },
          ...list.map((a) => ({ kind: "ability", owner: a.owner, ability: a.ability.id }))
        ]);
        return "ok";
      }
    }
    if (state.phase === "loop-end") {
      finalizeLoop(pack, state);
      continue;
    }
    if (state.phase === "final-guess") {
      if (state.ll && !state.ll.cAnswered) {
        const c = traitors(state).find((p) => state.ll.roles[p] === "C");
        if (c) {
          decision(state, c, "guess", []);
          state.flags["c-guess"] = "yes";
          return "ok";
        }
        state.ll.cAnswered = true;
      }
      const actor = state.ll?.finalEligible?.includes(state.captain) ? state.captain : state.ll?.finalEligible?.[0] ?? state.captain;
      decision(state, actor, "guess", []);
      return "ok";
    }
    if (state.phase === "day-end") {
      if (state.day === state.setup.days) enter(state, "loop-end");
      else {
        state.day++;
        for (const k of Object.keys(state.flags).filter(
          (k2) => k2.startsWith("passed:") || k2.startsWith("follow:")
        ))
          delete state.flags[k];
        enter(state, "day-start");
      }
      continue;
    }
    if (state.phase === "incident" && state.flags["hound-due"]) {
      delete state.flags["hound-due"];
      enqueueFlow(state, "hound-death", [{ effects: [{ op: "protagonist-death" }] }]);
      continue;
    }
    if (state.phase === "incident" && state.flags["end-after-incident"]) {
      state.endRequested = true;
      continue;
    }
    const next = nextPhase[state.phase];
    if (!next) {
      state.diagnostic = `No transition from ${state.phase}`;
      return "paused";
    }
    enter(state, next);
  }
  return state.pending || state.winner ? "ok" : "paused";
}
function applyChoice(pack, state, choice2) {
  const pending = state.pending;
  if (pending.kind === "cards") {
    if (choice2.kind !== "cards" || choice2.placements.length !== cardCount(state, pending.actor))
      return false;
    const targets = legalCardTargets(state, pending.actor);
    if (new Set(choice2.placements.map((p) => p.target)).size !== choice2.placements.length || new Set(choice2.placements.map((p) => p.card)).size !== choice2.placements.length)
      return false;
    if (choice2.placements.some(
      (p) => !targets.includes(p.target) || !state.cards.some(
        (c) => c.id === p.card && c.owner === pending.actor && c.status === "hand"
      )
    ))
      return false;
    for (const p of choice2.placements) state.cards.find((c) => c.id === p.card).status = "set";
    const ordered = clone(choice2.placements).sort((a, b) => a.target.localeCompare(b.target));
    state.placements.push(...ordered);
    announce(state, "cards", {
      placements: ordered.map((p) => ({ owner: pending.actor, target: p.target }))
    });
    announce(
      state,
      "cards",
      {
        placements: choice2.placements.map((p) => ({
          ...p,
          kind: state.cards.find((c) => c.id === p.card).kind
        }))
      },
      pending.actor === "mastermind" ? "mastermind" : "protagonists"
    );
    return true;
  }
  if (pending.kind === "guess") {
    if (state.flags["c-guess"]) {
      if (choice2.kind !== "guess-culprits" || Object.keys(choice2.answers).length !== state.setup.incidents.length || state.setup.incidents.some((i) => !state.characters[choice2.answers[String(i.day)] ?? ""]))
        return false;
      const correct2 = state.setup.incidents.every(
        (i) => choice2.answers[String(i.day)] === i.culprit
      );
      announce(state, "culprit", { guesses: choice2.answers, correct: correct2 });
      delete state.flags["c-guess"];
      state.ll.cAnswered = true;
      if (correct2) win(state, pending.actor);
      return true;
    }
    if (choice2.kind !== "guess" || !pack.identities[choice2.identity] || !state.characters[choice2.character])
      return false;
    const guessed = JSON.parse(state.flags.guessed ?? "[]");
    if (guessed.includes(choice2.character) || state.characters[choice2.character].status === "absent")
      return false;
    const config = state.setup.characters.find((c) => c.id === choice2.character);
    const correct = (state.characters[choice2.character].initialIdentity === choice2.identity || pack.anniversary && state.characters[choice2.character].initialIdentity === "因果残片" && choice2.identity === "平民") && config?.reverseIdentity === choice2.reverseIdentity;
    announce(state, "identity", { character: choice2.character, guess: choice2.identity, correct });
    if (!correct) win(state, "mastermind");
    else {
      guessed.push(choice2.character);
      state.flags.guessed = JSON.stringify(guessed);
      if (Object.values(state.characters).filter((c) => c.status !== "absent").every((c) => guessed.includes(c.id)))
        win(state, "protagonists");
    }
    return true;
  }
  if (pending.kind === "ability") {
    if (choice2.kind === "pass") {
      if (state.phase === "card-resolution") state.flags["cultist-done"] = "yes";
      else state.flags[`passed:${state.phase}`] = "yes";
      return true;
    }
    if (choice2.kind !== "ability") return false;
    const candidate = abilities(pack, state, state.phase, false, pending.actor).find(
      (a) => a.owner === choice2.owner && a.ability.id === choice2.ability
    );
    if (!candidate || candidate.ability.declarationArea && candidate.ability.declarationArea !== state.flags["ability-area:" + candidate.owner])
      return false;
    const frame = makeFrame(state, candidate.owner, candidate.ability, pending.actor);
    const supplied = { ...choice2.choices };
    if (candidate.ability.declarationArea && supplied.areaMode === candidate.ability.declarationArea)
      delete supplied.areaMode;
    for (const spec of frame.steps[0]?.choices ?? []) {
      const chosen = supplied[spec.key];
      if (chosen === void 0) continue;
      if (!options(pack, state, frame, spec).includes(chosen)) return false;
      frame.choices[spec.key] = chosen;
      delete supplied[spec.key];
    }
    if (Object.keys(supplied).length) return false;
    clearAbilityAreas(state);
    state.frames.push(frame);
    return true;
  }
  if (!pending.options.some((o) => canonical(o) === canonical(choice2))) return false;
  if (choice2.kind === "start") {
    beginDiscussion(state);
    return true;
  }
  if (choice2.kind === "request-final-guess") {
    state.flags["final-guess-votes"] = "[]";
    return true;
  }
  if (choice2.kind === "vote-final-guess") {
    if (!choice2.agree) delete state.flags["final-guess-votes"];
    else
      state.flags["final-guess-votes"] = JSON.stringify([
        ...JSON.parse(state.flags["final-guess-votes"] ?? "[]"),
        pending.actor
      ]);
    return true;
  }
  if (choice2.kind === "continue") {
    resetLoop(pack, state);
    enter(state, "loop-start");
    if (state.loop === 1 && state.publicTerritory) announce(state, "board", { territory: state.publicTerritory });
    return true;
  }
  if (choice2.kind === "refuse" && state.refusal) {
    if (choice2.refuse) rejectAbility(pack, state, state.refusal);
    state.refusal.bound.refusalChecked = "yes";
    state.refusal = null;
    return true;
  }
  if (choice2.kind === "select") {
    const binding = state.flags["pending-binding"] ?? "";
    if (binding.startsWith("flag:")) state.flags[binding.slice(5)] = choice2.value;
    else {
      const [, id, key] = binding.split(":");
      const frame = state.batch?.frames.find((f) => f.id === id);
      if (!frame || !key) return false;
      frame.choices[key] = choice2.value;
    }
    return true;
  }
  return false;
}
function advance(pack, input, actor, command, budget = 1e4) {
  if (!commandSchema.safeParse(command).success)
    return { status: "rejected", state: input, reason: "invalid-command" };
  if (input.ruleDigest !== pack.digest)
    return { status: "rejected", state: input, reason: "invalid-command" };
  const encoded = canonical({ actor, command });
  const receipt = input.receipts[command.id];
  if (receipt)
    return receipt.command === encoded ? { status: "ok", state: input } : { status: "rejected", state: input, reason: "invalid-command" };
  if (command.expectedRevision !== input.revision)
    return { status: "rejected", state: input, reason: "stale-revision" };
  if (!input.pending || input.pending.actor !== actor)
    return { status: "rejected", state: input, reason: "not-your-decision" };
  if (command.decisionId !== input.pending.id || !command.id || ["__proto__", "constructor", "prototype"].includes(command.id))
    return { status: "rejected", state: input, reason: "invalid-command" };
  const state = clone(input);
  if (!applyChoice(pack, state, command.choice))
    return { status: "rejected", state: input, reason: "invalid-command" };
  if (actor !== "mastermind" && command.choice.kind !== "start")
    announce(state, "own-choice", { actor, choice: command.choice }, "protagonists");
  state.choices.push({ actor, decisionId: command.decisionId, choice: clone(command.choice) });
  state.pending = null;
  state.revision++;
  state.receipts[command.id] = { command: encoded, revision: state.revision };
  return { status: drive(pack, state, budget), state };
}

// packages/engine/src/runtime/replay.ts
function* enumerateChoices(state) {
  const pending = state.pending;
  if (!pending) return;
  if (pending.kind === "cards") {
    const cards = state.cards.filter((c) => c.owner === pending.actor && c.status === "hand");
    const targets = legalCardTargets(state, pending.actor);
    const count2 = cardCount(state, pending.actor);
    function* visit(start, placements) {
      if (placements.length === count2) {
        yield { kind: "cards", placements };
        return;
      }
      for (let i = start; i < cards.length; i++)
        for (const target of targets)
          if (!placements.some((p) => p.target === target))
            yield* visit(i + 1, [...placements, { card: cards[i].id, target }]);
    }
    yield* visit(0, []);
    return;
  }
  if (pending.kind === "guess") {
    return;
  }
  yield* pending.options;
}

// packages/engine/src/runtime/reference.ts
function normalizeHistory(history) {
  return history.map(({ sequence: _sequence, ...observation }) => canonical(observation));
}

// packages/engine/src/runtime/knowledge-constraints.ts
var ConstraintStore = class _ConstraintStore {
  constructor(domains, stats = { checks: 0, removed: 0, branches: 0 }) {
    this.stats = stats;
    this.domains = new Map([...domains].map(([key, values]) => [key, new Set(values)]));
  }
  domains;
  constraints = [];
  dependencies = /* @__PURE__ */ new Map();
  queue = /* @__PURE__ */ new Set();
  invalid = false;
  add(constraint) {
    const index = this.constraints.push(constraint) - 1;
    for (const key of constraint.reads) {
      const readers = this.dependencies.get(key) ?? /* @__PURE__ */ new Set();
      readers.add(index);
      this.dependencies.set(key, readers);
    }
    this.queue.add(index);
  }
  upsert(constraint) {
    const index = this.constraints.findIndex((c) => c.name === constraint.name);
    if (index < 0) {
      this.add(constraint);
      return;
    }
    for (const key of this.constraints[index].reads) this.dependencies.get(key)?.delete(index);
    this.constraints[index] = constraint;
    for (const key of constraint.reads) {
      const readers = this.dependencies.get(key) ?? /* @__PURE__ */ new Set();
      readers.add(index);
      this.dependencies.set(key, readers);
    }
    this.queue.add(index);
  }
  invalidate() {
    this.invalid = true;
  }
  values(key) {
    return this.domains.get(key);
  }
  narrow(key, allowed) {
    const keep = new Set(allowed), values = this.values(key);
    let changed = false;
    for (const value2 of values)
      if (!keep.has(value2)) {
        values.delete(value2);
        this.stats.removed++;
        changed = true;
      }
    if (changed) for (const reader of this.dependencies.get(key) ?? []) this.queue.add(reader);
    return changed;
  }
  get consistent() {
    return !this.invalid && [...this.domains.values()].every((values) => values.size > 0);
  }
  related(keys) {
    const result = new Set(keys), visited = /* @__PURE__ */ new Set();
    for (const key of result) {
      if (this.values(key).size <= 1) continue;
      for (const index of this.dependencies.get(key) ?? []) {
        const constraint = this.constraints[index];
        if (constraint.cause || visited.has(index)) continue;
        visited.add(index);
        for (const other2 of constraint.reads) if (this.values(other2).size > 1) result.add(other2);
      }
    }
    return result;
  }
  propagate(all2 = false, skipCauses = false) {
    if (all2) this.constraints.forEach((_, index) => this.queue.add(index));
    while (this.queue.size && this.consistent) {
      const index = this.queue.values().next().value;
      this.queue.delete(index);
      if (skipCauses && this.constraints[index].cause) continue;
      this.stats.checks++;
      this.constraints[index].revise(this);
    }
    return this.consistent;
  }
  // Test a local conjunction against quotas, event/culprit pairs and other
  // ordinary constraints without feeding a speculative cause back into itself.
  probe(selected) {
    if ([...selected.keys()].every((k) => this.values(k).size === 1)) return this;
    const copy = this.clone({ checks: 0, removed: 0, branches: 0 });
    copy.queue = new Set(this.queue);
    for (const [key, value2] of selected) copy.narrow(key, [value2]);
    return copy.propagate(false, true) ? copy : void 0;
  }
  clone(stats = this.stats) {
    const copy = new _ConstraintStore(this.domains, stats);
    copy.invalid = this.invalid;
    copy.constraints.push(...this.constraints);
    copy.dependencies = new Map(
      [...this.dependencies].map(([key, readers]) => [key, new Set(readers)])
    );
    return copy;
  }
};
function relation(name, a, b, allows) {
  return {
    name,
    reads: [a, b],
    revise(s) {
      s.narrow(
        a,
        [...s.values(a)].filter((x) => [...s.values(b)].some((y) => allows(x, y)))
      );
      s.narrow(
        b,
        [...s.values(b)].filter((y) => [...s.values(a)].some((x) => allows(x, y)))
      );
    }
  };
}
function allocation(keys, slots, identity = (value2) => value2, exact = true) {
  function feasible(s, forcedKey, forcedValue) {
    if (exact ? keys.length !== slots.length : keys.length > slots.length) return false;
    const owner = new Array(slots.length).fill(-1);
    function place(index, visited) {
      const key = keys[index];
      const allowed = key === forcedKey ? /* @__PURE__ */ new Set([identity(forcedValue)]) : new Set([...s.values(key)].map(identity));
      for (let slot = 0; slot < slots.length; slot++) {
        if (visited.has(slot) || !allowed.has(slots[slot])) continue;
        visited.add(slot);
        if (owner[slot] === -1 || place(owner[slot], visited)) {
          owner[slot] = index;
          return true;
        }
      }
      return false;
    }
    return keys.every((_, index) => place(index, /* @__PURE__ */ new Set()));
  }
  return {
    name: "identity-allocation",
    reads: keys,
    revise(s) {
      if (!keys.length) return;
      if (!feasible(s)) {
        s.narrow(keys[0], []);
        return;
      }
      for (const key of keys)
        s.narrow(
          key,
          [...s.values(key)].filter((value2) => feasible(s, key, value2))
        );
    }
  };
}
function exactlyOne(keys, value2) {
  return {
    name: "exactly-one",
    reads: keys,
    revise(s) {
      const possible = keys.filter((key) => s.values(key).has(value2));
      const fixed = possible.filter((key) => s.values(key).size === 1);
      if (!possible.length || fixed.length > 1) {
        if (keys[0]) s.narrow(keys[0], []);
        return;
      }
      if (possible.length === 1) s.narrow(possible[0], [value2]);
      if (fixed.length === 1) {
        for (const key of keys)
          if (key !== fixed[0])
            s.narrow(
              key,
              [...s.values(key)].filter((v) => v !== value2)
            );
      }
    }
  };
}
function* assignments(store, current) {
  if (current) {
    const latest = current();
    if (!latest) return;
    for (const [key2, values2] of latest) store.narrow(key2, values2);
  }
  if (!store.propagate()) return;
  const unsettled = [...store.domains].filter(([, values2]) => values2.size > 1).sort((a, b) => a[1].size - b[1].size);
  if (!unsettled.length) {
    yield store.domains;
    return;
  }
  const [key, values] = unsettled[0];
  for (const value2 of values) {
    store.stats.branches++;
    yield null;
    const next = store.clone();
    next.narrow(key, [value2]);
    yield* assignments(next, current);
  }
}

// packages/engine/src/runtime/knowledge-domain.ts
var fragment = "@anniversary-fragment";
var baseIdentity = (v) => v === fragment ? "平民" : v;
var shownIdentity = (v) => v === fragment ? "因果残片" : v;
function incompleteContent(pack, opening) {
  const reasons = [];
  const roster = new Set(
    [...opening.roster ?? [], ...opening.characters].map((c) => c.character)
  );
  if (roster.has("临时工")) roster.add("临时工？");
  for (const name of roster)
    if (!pack.characters[name]?.supported) reasons.push(`未支持的登场角色：${name}。`);
  const identities2 = /* @__PURE__ */ new Set([
    "平民",
    ...Object.keys(pack.identities),
    ...Object.values(pack.plots).flatMap((p) => Object.keys(p.identities))
  ]);
  if (opening.anniversary) identities2.add("因果残片");
  for (const name of identities2)
    if (!pack.identities[name]?.supported) reasons.push(`未支持的身份：${name}。`);
  if (Object.values(pack.incidents).some((event) => !event.supported)) {
    let collect = function(step, effects) {
      for (const effect of effects) {
        if ("effects" in effect) collect(step, effect.effects);
        if (effect.op !== "invoke-incident") continue;
        if (!effect.name.startsWith("$")) {
          reachable.add(effect.name);
          continue;
        }
        const options2 = step.choices?.find((c) => "$" + c.key === effect.name)?.options;
        if (Array.isArray(options2) && options2.every((o) => o === "$public-incidents" || !o.startsWith("$"))) {
          for (const name of options2) if (name !== "$public-incidents") reachable.add(name);
        } else {
          for (const name of Object.keys(pack.incidents)) reachable.add(name);
        }
      }
    };
    const scheduled = opening.incidents.map((event) => event.name);
    const reachable = new Set(scheduled);
    if (scheduled.length && pack.incidents["伪造事件"]) reachable.add("伪造事件");
    for (const definition of [
      ...Object.values(pack.plots),
      ...Object.values(pack.identities),
      ...[...roster].map((name) => pack.characters[name])
    ])
      for (const ability of definition?.abilities ?? [])
        for (const step of ability.steps) collect(step, step.effects);
    for (const name of reachable) {
      const event = pack.incidents[name];
      if (event && !event.supported) reasons.push(`未支持的事件：${name}。`);
      for (const step of event?.steps ?? []) collect(step, step.effects);
    }
  }
  for (const { name } of opening.incidents)
    if (!pack.incidents[name] && !pack.incidents["伪造事件"])
      reasons.push(`缺少公开事件的规则：${name}。`);
  return reasons;
}
function publicRoster(pack, opening) {
  return (opening.roster ?? opening.characters).map(
    (entry) => opening.characters.find((c) => c.id === entry.id) ?? {
      ...entry,
      status: "absent",
      area: pack.characters[entry.character]?.initial[0] ?? "hospital",
      counters: zeroCounters()
    }
  ).filter((c) => c.character !== "临时工？");
}
var targetId = (t) => JSON.stringify([t.key, t.value]);
function targetValues(key, values) {
  return new Set([...values].map(key.startsWith("identity:") ? shownIdentity : (v) => v));
}
function buildProfiles(pack, opening, stats) {
  const roster = publicRoster(pack, opening);
  const ordinary2 = roster.filter((c) => !["模仿犯", "局外人"].includes(c.character));
  const ys = Object.values(pack.plots).filter((p) => p.type === "Y");
  const xs = Object.values(pack.plots).filter((p) => p.type === "X");
  const xSets = pack.module === "FS" ? xs.map((x) => [x]) : xs.flatMap((x, i) => xs.slice(i + 1).map((z) => [x, z]));
  const profiles = [];
  for (const y of ys)
    for (const xSet of xSets) {
      const pool = {};
      for (const p of [y, ...xSet])
        for (const [name, count2] of Object.entries(p.identities))
          pool[name] = Math.min((pool[name] ?? 0) + count2, pack.identities[name]?.max ?? Infinity);
      for (let mobs = 0; mobs <= (pool["暴徒"] ?? 0); mobs++) {
        const counts = { ...pool, 暴徒: mobs };
        const required = Object.values(counts).reduce((sum, n) => sum + n, 0);
        if (required > ordinary2.length) continue;
        counts["平民"] = (counts["平民"] ?? 0) + ordinary2.length - required;
        const slots = Object.entries(counts).flatMap(([name, n]) => Array(n).fill(name));
        const domains = /* @__PURE__ */ new Map();
        const allRoles = Object.keys(pack.identities).filter(
          (id) => pack.identities[id].supported
        );
        const eligible = (character, identity) => {
          const base = baseIdentity(identity);
          if (character === "AI" && base === "平民") return false;
          if (character === "妹妹" && pack.identities[base]?.ignore) return false;
          if (y.name === "和我签订契约吧！" && base === "关键人物" && character !== "局外人" && !pack.characters[character]?.attributes.includes("少女"))
            return false;
          return true;
        };
        for (const c of roster) {
          if (!opening.characters.some((visible) => visible.id === c.id))
            domains.set(`area:${c.id}`, new Set(pack.characters[c.character]?.initial ?? []));
          let roles = c.character === "局外人" ? allRoles.filter((r) => r !== "平民" && r !== "因果残片" && !pool[r]) : c.character === "模仿犯" ? allRoles : [...new Set(slots)];
          if (opening.anniversary && roles.includes("平民")) roles = [...roles, fragment];
          domains.set(`identity:${c.id}`, new Set(roles.filter((r) => eligible(c.character, r))));
          if (c.character === "模仿犯")
            domains.set(
              `copy:${c.id}`,
              new Set(roster.filter((t) => t.id !== c.id).map((t) => t.id))
            );
          if (c.character === "转校生")
            domains.set(
              `enterDay:${c.id}`,
              new Set(
                c.status === "absent" ? Array.from({ length: opening.days }, (_, i) => String(i + 1)) : []
              )
            );
          else if (c.character === "神灵")
            domains.set(
              `enterLoop:${c.id}`,
              new Set(
                Array.from({ length: opening.loops }, (_, i) => i + 1).filter((n) => c.status === (n > 1 ? "absent" : "alive")).map(String)
              )
            );
          else if (c.status !== "alive") domains.set(`invalid:${c.id}`, /* @__PURE__ */ new Set());
          if (pack.characters[c.character]?.abilityArea?.publicMarker === "territory")
            domains.set(`territory:${c.id}`, new Set(opening.territory ? [opening.territory] : BOARDS));
        }
        for (const e of opening.incidents) {
          const types = [
            e.name,
            ...pack.incidents["伪造事件"] && e.name !== "伪造事件" ? ["伪造事件"] : []
          ].filter((name) => pack.incidents[name]?.supported);
          domains.set(`event:${e.day}`, new Set(types));
          domains.set(
            `culprit:${e.day}`,
            new Set(
              types.flatMap(
                (name) => pack.incidents[name]?.crowdThreshold !== void 0 ? BOARDS : roster.map((c) => c.id)
              )
            )
          );
        }
        const store = new ConstraintStore(domains, stats);
        store.add(
          allocation(
            ordinary2.map((c) => `identity:${c.id}`),
            slots,
            baseIdentity
          )
        );
        if (opening.anniversary)
          store.add(
            exactlyOne(
              roster.map((c) => `identity:${c.id}`),
              fragment
            )
          );
        for (const c of roster.filter((c2) => c2.character === "模仿犯")) {
          const role2 = `identity:${c.id}`, copy = `copy:${c.id}`;
          store.add({
            name: "copycat",
            reads: [copy, ...roster.map((c2) => `identity:${c2.id}`)],
            revise(s) {
              s.narrow(
                copy,
                [...s.values(copy)].filter(
                  (id) => [...s.values(`identity:${id}`)].some(
                    (r) => [...s.values(role2)].some((v) => baseIdentity(r) === baseIdentity(v))
                  )
                )
              );
              s.narrow(
                role2,
                [...s.values(role2)].filter(
                  (v) => [...s.values(copy)].some(
                    (id) => [...s.values(`identity:${id}`)].some(
                      (r) => baseIdentity(v) === baseIdentity(r)
                    )
                  )
                )
              );
              if (s.values(copy).size === 1) {
                const key = `identity:${[...s.values(copy)][0]}`;
                s.narrow(
                  key,
                  [...s.values(key)].filter(
                    (r) => [...s.values(role2)].some((v) => baseIdentity(r) === baseIdentity(v))
                  )
                );
              }
            }
          });
        }
        for (const e of opening.incidents)
          store.add(
            relation(
              "incident-kind",
              `event:${e.day}`,
              `culprit:${e.day}`,
              (type, culprit) => pack.incidents[type]?.crowdThreshold !== void 0 ? BOARDS.includes(culprit) : roster.some((c) => c.id === culprit)
            )
          );
        if (opening.incidents.every(
          (e) => [...store.values(`event:${e.day}`)].every(
            (name) => name !== "连续杀人" && pack.incidents[name]?.crowdThreshold === void 0
          )
        ))
          store.add(
            allocation(
              opening.incidents.map((e) => `culprit:${e.day}`),
              roster.map((c) => c.id),
              (v) => v,
              false
            )
          );
        for (let i = 0; i < opening.incidents.length; i++)
          for (const b of opening.incidents.slice(i + 1)) {
            const a = opening.incidents[i];
            const keys = [
              `event:${a.day}`,
              `culprit:${a.day}`,
              `event:${b.day}`,
              `culprit:${b.day}`
            ];
            store.add({
              name: "culprit-reuse",
              reads: keys,
              revise(s) {
                const supports2 = keys.map(() => /* @__PURE__ */ new Set());
                for (const at of s.values(keys[0]))
                  for (const ac of s.values(keys[1]))
                    for (const bt of s.values(keys[2]))
                      for (const bc of s.values(keys[3])) {
                        if (ac === bc && !BOARDS.includes(ac) && (at !== "连续杀人" || bt !== "连续杀人"))
                          continue;
                        [at, ac, bt, bc].forEach((v, i2) => supports2[i2].add(v));
                      }
                keys.forEach((key, i2) => s.narrow(key, supports2[i2]));
              }
            });
          }
        if (store.propagate())
          profiles.push({
            id: `${y.name}|${xSet.map((x) => x.name).join("|")}|${mobs}`,
            y: y.name,
            x: xSet.map((x) => x.name),
            identityCounts: counts,
            store,
            active: true
          });
      }
    }
  return profiles;
}
function applyDisclosure(profile, opening, o) {
  const d = o.data;
  if (o.type === "rule" && typeof d.rule === "string")
    return [profile.y, ...profile.x].includes(d.rule);
  if (o.type === "culprit" && typeof d.culprit === "string") {
    const key = `culprit:${d.day}`;
    if (profile.store.domains.has(key)) profile.store.narrow(key, [d.culprit]);
  }
  if (o.type === "identity" && typeof d.identity === "string" && typeof d.character === "string") {
    const c = (opening.roster ?? opening.characters).find((c2) => c2.id === d.character);
    const key = `identity:${d.character}`;
    if (c && !["临时工", "临时工？"].includes(c.character) && profile.store.domains.has(key))
      profile.store.narrow(
        key,
        [...profile.store.values(key)].filter(
          (r) => shownIdentity(r) === d.identity || r === "平民" && profile.x.includes("妄想扩大病毒") && d.identity === "杀人狂"
        )
      );
  }
  return profile.store.consistent;
}
function combinationKey(p) {
  return JSON.stringify([p.y, ...p.x.slice().sort()]);
}
function supports(profile, target) {
  if (!profile.active) return false;
  if (target.key === "rule") return [profile.y, ...profile.x].includes(target.value);
  if (target.key === "combination") return combinationKey(profile) === target.value;
  const values = profile.store.domains.get(target.key);
  return !!values && targetValues(target.key, values).has(target.value);
}
function* configurations(pack, opening, profiles, target) {
  for (const profile of profiles) {
    if (!profile.active || target && !supports(profile, target)) continue;
    const store = profile.store.clone();
    if (target && store.domains.has(target.key))
      store.narrow(
        target.key,
        [...store.values(target.key)].filter(
          (v) => (target.key.startsWith("identity:") ? shownIdentity(v) : v) === target.value
        )
      );
    for (const domain of assignments(
      store,
      () => profile.active ? profile.store.domains : void 0
    )) {
      if (!domain) {
        yield null;
        continue;
      }
      const value2 = (key) => [...domain.get(key)][0];
      const characters = publicRoster(pack, opening).map((c) => ({
        id: c.id,
        character: c.character,
        initialArea: domain.has(`area:${c.id}`) ? value2(`area:${c.id}`) : c.area,
        identity: baseIdentity(value2(`identity:${c.id}`)),
        ...c.character === "模仿犯" ? { copiedFrom: value2(`copy:${c.id}`) } : {},
        ...c.character === "转校生" ? { enterDay: Number(value2(`enterDay:${c.id}`)) } : {},
        ...c.character === "神灵" ? { enterLoop: Number(value2(`enterLoop:${c.id}`)) } : {},
        ...domain.has(`territory:${c.id}`) ? { territory: value2(`territory:${c.id}`) } : {}
      }));
      const setup = {
        module: opening.module,
        anniversary: opening.anniversary,
        loops: opening.loops,
        days: opening.days,
        captain: opening.captain,
        discussion: "allowed",
        y: profile.y,
        x: profile.x,
        characters,
        incidents: opening.incidents.map((e) => ({
          day: e.day,
          publicName: e.name,
          name: value2(`event:${e.day}`),
          culprit: value2(`culprit:${e.day}`)
        })),
        ...opening.anniversary ? {
          anniversaryFragment: characters.find((c) => value2(`identity:${c.id}`) === fragment)?.id
        } : {}
      };
      yield validateSetup(pack, setup).length ? null : setup;
    }
  }
}
function setupValues(setup) {
  const values = /* @__PURE__ */ new Map();
  for (const c of setup.characters) {
    values.set(`identity:${c.id}`, setup.anniversaryFragment === c.id ? "因果残片" : c.identity);
    if (c.copiedFrom) values.set(`copy:${c.id}`, c.copiedFrom);
    if (c.enterDay) values.set(`enterDay:${c.id}`, String(c.enterDay));
    if (c.enterLoop) values.set(`enterLoop:${c.id}`, String(c.enterLoop));
    if (c.territory) values.set(`territory:${c.id}`, c.territory);
  }
  for (const e of setup.incidents) {
    values.set(`event:${e.day}`, e.name);
    values.set(`culprit:${e.day}`, e.culprit);
  }
  return values;
}

// packages/engine/src/runtime/knowledge-history.ts
function matchesOpeningRoster(state, opening) {
  const actual = Object.values(state.characters);
  const roster = opening.roster ?? opening.characters.filter((c) => c.character !== "临时工？");
  return (!opening.territory || state.publicTerritory === opening.territory) && actual.filter((c) => c.character !== "临时工？").length === roster.length && roster.every((c) => actual.some((a) => a.id === c.id && a.character === c.character)) && opening.characters.every(
    (c) => actual.some(
      (a) => a.id === c.id && a.character === c.character && a.area === c.area && a.status === c.status
    )
  ) && actual.every(
    (c) => c.character === "临时工？" || c.status === "absent" || opening.characters.some((v) => v.id === c.id)
  );
}
var HistorySearch = class {
  constructor(pack, setup, evidence, opening) {
    this.pack = pack;
    this.evidence = evidence;
    const result = initializeDiscussion(pack, setup);
    if (!result.state) {
      this.uncertain = hasUnsupportedDiagnostic(result.diagnostics);
      return;
    }
    if (!matchesOpeningRoster(result.state, opening)) return;
    this.active.push({
      state: result.state,
      normalized: normalizeHistory(result.state.observations.protagonists),
      matched: 0
    });
  }
  active = [];
  witness;
  version = -1;
  uncertain = false;
  expansions = 0;
  compared = 0;
  sync() {
    if (this.version === this.evidence.version) return;
    const node = this.witness;
    if (node && node.normalized.length >= this.evidence.normalized.length) {
      while (node.matched < this.evidence.normalized.length) {
        this.compared++;
        if (node.normalized[node.matched] !== this.evidence.normalized[node.matched]) break;
        node.matched++;
      }
      if (node.matched === this.evidence.normalized.length) {
        this.version = this.evidence.version;
        return;
      }
    }
    if (this.witness) this.active.push(this.witness);
    this.witness = void 0;
    this.version = this.evidence.version;
  }
  get result() {
    this.sync();
    return this.witness ? "possible" : this.active.length || this.uncertain ? "unknown" : "excluded";
  }
  get blocked() {
    return this.uncertain && !this.active.length;
  }
  step() {
    this.sync();
    if (this.witness) return;
    const node = this.active.at(-1);
    if (!node) return;
    const end = Math.min(node.normalized.length, this.evidence.normalized.length);
    while (node.matched < end) {
      this.compared++;
      if (node.normalized[node.matched] !== this.evidence.normalized[node.matched]) {
        this.active.pop();
        return;
      }
      node.matched++;
    }
    if (node.normalized.length >= this.evidence.normalized.length) {
      this.witness = this.active.pop();
      return;
    }
    const pending = node.state.pending;
    if (!pending || node.state.winner) {
      if (!node.state.winner) this.uncertain = true;
      this.active.pop();
      return;
    }
    if (!node.choices || node.choicesVersion !== this.evidence.version) {
      const known = this.evidence.observations.slice(node.normalized.length).find((o) => o.type === "own-choice");
      node.choices = pending.actor !== "mastermind" && known ? function* () {
        if (known.data.actor === pending.actor) yield known.data.choice;
      }() : this.hiddenChoices(node.state, node.normalized.length);
      if (pending.kind === "guess" && !known) this.uncertain = true;
      node.choicesVersion = this.evidence.version;
      node.tried ??= /* @__PURE__ */ new Set();
    }
    const choice2 = node.choices.next();
    if (choice2.done) {
      this.active.pop();
      return;
    }
    const choiceKey = canonical(choice2.value);
    if (node.tried.has(choiceKey)) return;
    node.tried.add(choiceKey);
    this.expansions++;
    const next = advance(this.pack, node.state, pending.actor, {
      id: `knowledge-${node.state.revision}`,
      expectedRevision: node.state.revision,
      decisionId: pending.id,
      choice: choice2.value
    });
    if (next.status === "rejected") return;
    if (next.status === "paused") this.uncertain = true;
    const observations = next.state.observations.protagonists;
    this.active.push({
      state: next.state,
      matched: node.matched,
      normalized: [
        ...node.normalized,
        ...normalizeHistory(observations.slice(node.normalized.length))
      ]
    });
  }
  *hiddenChoices(state, offset) {
    if (state.pending?.kind !== "cards" || state.pending.actor !== "mastermind") {
      yield* enumerateChoices(state);
      return;
    }
    const records = this.evidence.observations.slice(offset).filter((o) => o.type === "cards" && o.loop === state.loop && o.day === state.day);
    const known = records.find(
      (o) => Array.isArray(o.data.placements) && o.data.placements.every((p) => p.owner === "mastermind")
    );
    if (!Array.isArray(known?.data.placements)) {
      yield* enumerateChoices(state);
      return;
    }
    const targets = known.data.placements.map((p) => p.target);
    const revealed = records.find((o) => o.phase === "card-resolution");
    const reveal2 = Array.isArray(revealed?.data.placements) ? revealed.data.placements : [];
    const cards = state.cards.filter((c) => c.owner === "mastermind" && c.status === "hand");
    function* place(i, placements) {
      if (i === targets.length) {
        yield {
          kind: "cards",
          placements: placements.slice().sort(
            (a, b) => cards.findIndex((c) => c.id === a.card) - cards.findIndex((c) => c.id === b.card)
          )
        };
        return;
      }
      const target = targets[i];
      const face = reveal2.find((p) => p.owner === "mastermind" && p.target === target)?.kind;
      for (const card of cards)
        if ((!face || card.kind === face) && !placements.some((p) => p.card === card.id))
          yield* place(i + 1, [...placements, { card: card.id, target }]);
    }
    yield* place(0, []);
  }
  get nodes() {
    return this.active.length + (this.witness ? 1 : 0);
  }
};

// packages/engine/src/runtime/knowledge-pair.ts
function distinctCounterPair(steps) {
  if (steps.length !== 2) return;
  const parts = [];
  const choices = steps.map((s) => s.choices?.[0]);
  for (const [i, step] of steps.entries()) {
    const c = choices[i], e = step.effects[0];
    if (!c || c.optional || step.moveOthersFromEffectiveArea || step.condition !== void 0 || step.choices?.length !== 1 || Array.isArray(c.options) || c.options.kind !== "alive" || step.effects.length !== 1 || e?.op !== "counter" || e.target !== "$" + c.key || e.counter === "$counter" || typeof e.amount !== "number" || !Number.isSafeInteger(e.amount))
      return;
    const condition = c.options.where;
    if (i === 0) {
      if (condition !== void 0 && condition !== true) return;
    } else {
      if (c.key === choices[0].key || !condition || typeof condition !== "object" || !("cmp" in condition) || condition.cmp !== "ne")
        return;
      const refs = [condition.left, condition.right].map(
        (v) => v && typeof v === "object" && "ref" in v ? v.ref : void 0
      );
      if (!refs.includes("$it") || !refs.includes("$" + choices[0].key)) return;
    }
    parts.push({ counter: e.counter, amount: e.amount });
  }
  return [parts[0], parts[1]];
}
var PairExecution = class {
  constructor(pair, mode, budget = 4096) {
    this.pair = pair;
    this.mode = mode;
    this.budget = budget;
  }
  positions = [{ step: 0, first: [], pending: [] }];
  ordinaryStep = 0;
  firstTarget;
  branches = 0;
  uncertain = false;
  // For distinguishable steps, a visible change gives its target directly.
  // A silent first subtraction needs only one different living witness.
  advanceOrdinary(actors, change) {
    const [first, second] = this.pair;
    const actor = change && actors.get(change.target);
    const matches = (part) => actor?.status === "alive" && change?.kind === "counter" && change.counter === part.counter && change.before === actor.counters[part.counter] && change.after !== change.before && change.after === Math.max(0, change.before + part.amount);
    const silent = (a) => Math.max(0, a.counters[first.counter] + first.amount) === a.counters[first.counter];
    if (!change) {
      const alive2 = [...actors.values()].filter((a) => a.status === "alive");
      return this.ordinaryStep === 2 || this.ordinaryStep === 1 && alive2.every((a) => a.id === this.firstTarget) || this.ordinaryStep === 0 && (alive2.length === 0 || alive2.length === 1 && silent(alive2[0]));
    }
    if (this.ordinaryStep === 0 && matches(first)) {
      this.firstTarget = change.target;
      this.ordinaryStep = 1;
      return true;
    }
    if (matches(second) && (this.ordinaryStep === 1 && this.firstTarget !== change.target || this.ordinaryStep === 0 && [...actors.values()].some(
      (a) => a.status === "alive" && a.id !== change.target && silent(a)
    ))) {
      this.ordinaryStep = 2;
      return true;
    }
    this.ordinaryStep = -1;
    return false;
  }
  advance(actors, change) {
    if (this.mode === "ordinary" && this.pair[1].amount > 0 && (this.pair[0].counter !== this.pair[1].counter || this.pair[0].amount < 0))
      return this.advanceOrdinary(actors, change);
    if (this.uncertain) return true;
    const found = /* @__PURE__ */ new Map();
    const alive2 = [...actors.values()].filter((a) => a.status === "alive");
    let remaining = this.budget;
    const visit = (pos) => {
      if (this.uncertain) return;
      if (pos.pending.length) {
        const match = pos.pending.find(
          (r) => change?.kind === "counter" && r.target === change.target && r.counter === change.counter && r.before === change.before && r.after === change.after
        );
        if (match) {
          const next = { ...pos, pending: pos.pending.filter((r) => r !== match) };
          found.set(JSON.stringify(next), next);
        }
        return;
      }
      if (pos.step === (this.mode === "repeated" ? 4 : 2)) {
        if (!change) found.set("end", pos);
        return;
      }
      const second = pos.step % 2 === 1, part = this.pair[second ? 1 : 0];
      const choices = (lane) => {
        const targets = alive2.map((a) => a.id).filter((id) => !second || id !== pos.first[lane]);
        if (!targets.length) return [""];
        if (this.mode === "parallel") return targets;
        return targets.filter((id) => {
          const before2 = actors.get(id).counters[part.counter];
          const after = Math.max(0, before2 + part.amount);
          return before2 === after || change?.kind === "counter" && change.target === id && change.counter === part.counter && change.before === before2 && change.after === after;
        });
      };
      const resolve = (targets) => {
        if (--remaining < 0) {
          this.uncertain = true;
          return;
        }
        this.branches++;
        const pending = [];
        for (const target2 of new Set(targets)) {
          const actor = actors.get(target2);
          if (!actor) continue;
          const before2 = actor.counters[part.counter];
          const amount = part.amount * targets.filter((id) => id === target2).length;
          const after = Math.max(0, before2 + amount);
          if (before2 !== after) pending.push({ target: target2, counter: part.counter, before: before2, after });
        }
        visit({ step: pos.step + 1, first: second ? [] : targets, pending });
      };
      const firstLane = choices(0);
      if (this.mode !== "parallel") {
        for (const first of firstLane) {
          if (this.uncertain) return;
          resolve([first]);
        }
        return;
      }
      const secondLane = choices(1);
      const silent = (id) => {
        const actor = actors.get(id);
        if (!actor) return true;
        const before2 = actor.counters[part.counter];
        return Math.max(0, before2 + part.amount) === before2;
      };
      const silentSecond = secondLane.filter(silent);
      for (const first of firstLane.filter(silent))
        for (const other2 of silentSecond) {
          if (this.uncertain) return;
          resolve([first, other2]);
        }
      if (this.uncertain || change?.kind !== "counter" || change.counter !== part.counter) return;
      const target = change.target;
      const before = actors.get(target)?.counters[part.counter];
      if (before === void 0 || before !== change.before || change.after === before) return;
      const inFirst = firstLane.includes(target), inSecond = secondLane.includes(target);
      if (change.after === Math.max(0, before + part.amount)) {
        if (inFirst)
          for (const other2 of secondLane) {
            if (this.uncertain) return;
            if (other2 !== target) resolve([target, other2]);
          }
        if (inSecond)
          for (const first of firstLane) {
            if (this.uncertain) return;
            if (first !== target) resolve([first, target]);
          }
      }
      if (!this.uncertain && inFirst && inSecond && change.after === Math.max(0, before + 2 * part.amount))
        resolve([target, target]);
    };
    for (const pos of this.positions) visit(pos);
    this.positions = [...found.values()];
    return this.uncertain || this.positions.length > 0;
  }
};

// packages/engine/src/runtime/knowledge-conditions.ts
var unknown = Symbol("unknown");
function publicValue(v, c) {
  if (v === null || typeof v !== "object") return v;
  if ("game" in v)
    return v.game === "day" || v.game === "loop" ? c.clock[v.game] : v.game === "days" ? c.days : v.game === "loops" ? c.loops : unknown;
  if ("op" in v) {
    const a = v.args.map((x) => publicValue(x, c));
    if (a.some((x) => typeof x !== "number")) return unknown;
    const n = a;
    return v.op === "add" ? n.reduce((a2, b) => a2 + b, 0) : v.op === "subtract" ? (n[0] ?? 0) - (n[1] ?? 0) : v.op === "min" ? Math.min(...n) : Math.max(...n);
  }
  const ref2 = (r) => r === "$self" ? c.owner : r.startsWith("$") ? c.bindings?.[r.slice(1)] : r;
  if ("ref" in v) return ref2(v.ref) ?? unknown;
  if ("count" in v && !c.staticOnly && v.count.kind === "alive") {
    let n = 0;
    for (const actor2 of c.characters.values()) {
      if (actor2.status !== "alive") continue;
      const yes = publicCondition(v.count.where, {
        ...c,
        bindings: { ...c.bindings, it: actor2.id }
      });
      if (yes === void 0) return unknown;
      if (yes) n++;
    }
    return n;
  }
  if (!("target" in v)) return unknown;
  const id = ref2(v.target);
  if (!id) return unknown;
  const actor = c.characters.get(id);
  if ("field" in v && v.field === "character") return actor?.character ?? unknown;
  if ("field" in v && v.field === "area" && (!c.staticOnly || c.moved && !c.moved.has(id)))
    return id === c.owner && c.virtualArea ? unknown : actor?.area ?? (id in c.boards ? id : unknown);
  if (c.staticOnly) return unknown;
  if ("counter" in v) {
    if (!actor)
      return v.counter === "intrigue" && id in c.boards ? c.boards[id] : unknown;
    const n = actor.counters[v.counter];
    if (v.raw) return n;
    return v.counter === "goodwill" ? n + actor.counters.hope : v.counter === "paranoia" ? n + actor.counters.despair : v.counter === "intrigue" ? Math.max(0, n + actor.counters.despair - actor.counters.hope) : n;
  }
  if ("field" in v) {
    if (v.field === "paranoiaLimit" && actor)
      return actor.character === "仙人" ? 0 : c.pack.characters[actor.character]?.paranoia ?? unknown;
    if (v.field === "status" || v.field === "character") return actor?.[v.field] ?? unknown;
    if (v.field === "rawTotal" && actor)
      return Object.values(actor.counters).reduce((a, b) => a + b, 0);
    if (v.field === "kinds" && actor)
      return Object.values(actor.counters).filter((n) => n > 0).length;
  }
  return unknown;
}
function publicCondition(v, c) {
  if (v === void 0) return true;
  if (typeof v === "boolean") return v;
  if ("all" in v) {
    const a = v.all.map((x) => publicCondition(x, c));
    return a.includes(false) ? false : a.every((x) => x === true) ? true : void 0;
  }
  if ("any" in v) {
    const a = v.any.map((x) => publicCondition(x, c));
    return a.includes(true) ? true : a.every((x) => x === false) ? false : void 0;
  }
  if ("not" in v) {
    const a = publicCondition(v.not, c);
    return a === void 0 ? void 0 : !a;
  }
  if ("incidentOccurred" in v && !c.staticOnly) return c.occurred?.(v.incidentOccurred);
  if ("attribute" in v) {
    const id = publicValue({ ref: v.target }, c);
    const actor = typeof id === "string" ? c.characters.get(id) : void 0;
    const def = actor && c.pack.characters[actor.character];
    if (def?.attributes.includes(v.attribute)) return true;
    if (def && !["神灵", "模仿犯", "临时工？", "UP主"].includes(actor.character)) return false;
  }
  if ("cmp" in v) {
    const a = publicValue(v.left, c), b = publicValue(v.right, c);
    if (a === unknown || b === unknown) return void 0;
    return v.cmp === "eq" ? a === b : v.cmp === "ne" ? a !== b : v.cmp === "ge" ? Number(a) >= Number(b) : v.cmp === "gt" ? Number(a) > Number(b) : v.cmp === "le" ? Number(a) <= Number(b) : Number(a) < Number(b);
  }
  return void 0;
}
function publicNumber(v, c) {
  const n = publicValue(v, c);
  return typeof n === "number" && Number.isFinite(n) ? n : void 0;
}

// packages/engine/src/runtime/knowledge-quiet.ts
function quietTargets(steps, ctx) {
  if (!steps.length) return [[]];
  const alive2 = [...ctx.characters.values()].filter((c) => c.status === "alive");
  function select2(s) {
    if (s.kind !== "alive") return;
    const ids = [];
    for (const a of alive2) {
      const enabled2 = publicCondition(s.where, { ...ctx, bindings: { it: a.id } });
      if (enabled2 === void 0) return;
      if (enabled2) ids.push(a.id);
    }
    return ids;
  }
  if (steps.length === 2 && !ctx.virtualArea && ctx.owner) {
    const [move, add2] = steps;
    const choice2 = move?.choices?.[0], first = move?.effects[0], second = add2?.effects[0];
    if (move?.condition === void 0 && add2?.condition === void 0 && !add2?.choices?.length && move?.choices?.length === 1 && choice2 && !choice2.optional && !Array.isArray(choice2.options) && choice2.options.kind === "boards" && !choice2.options.where && move.effects.length === 1 && first?.op === "move" && first.target === "$self" && first.area === "$" + choice2.key && add2?.effects.length === 1 && second?.op === "counter" && second.target === "$self.area" && second.counter === "intrigue" && typeof second.amount === "number") {
      const board2 = BOARDS.find((b) => b === ctx.characters.get(ctx.owner)?.area);
      if (board2) {
        const n = ctx.boards[board2];
        return n === Math.min(3, Math.max(0, n + second.amount)) ? [[]] : [];
      }
    }
  }
  if (steps.length !== 1) return;
  const step = steps[0];
  const enabled = publicCondition(step.condition, ctx);
  if (enabled === void 0) return;
  if (!enabled) return [[]];
  const choices = step.choices ?? [];
  const targetChoice = choices[0], counterChoice = choices[1], effect = step.effects[0];
  if (targetChoice && !targetChoice.optional && !Array.isArray(targetChoice.options) && step.effects.length === 1 && effect?.op === "counter" && effect.target === "$" + targetChoice.key && typeof effect.amount === "number" && effect.amount > 0 && (choices.length === 1 && effect.counter !== "$counter" || choices.length === 2 && effect.counter === "$counter" && counterChoice?.key === "counter" && !counterChoice.optional && Array.isArray(counterChoice.options) && counterChoice.options.length && counterChoice.options.every((k) => COUNTERS.some((c) => c === k)))) {
    const ids = select2(targetChoice.options);
    return ids ? ids.length ? [] : [[]] : void 0;
  }
  let targets = [""];
  if (choices.length) {
    const c = choices[0];
    if (choices.length !== 1 || c.actor && c.actor !== "mastermind" || c.optional || Array.isArray(c.options))
      return;
    const ids = select2(c.options);
    if (!ids) return;
    targets = ids.length ? ids : [""];
  }
  function collect(e, selected, victims) {
    if (e.op === "when") {
      const condition = publicCondition(e.condition, {
        ...ctx,
        bindings: { [choices[0]?.key ?? "target"]: selected }
      });
      if (condition === false) return "quiet";
      if (condition === void 0 || e.effects.length !== 1) return "unknown";
      return collect(e.effects[0], selected, victims);
    }
    if (e.op === "each" && e.effects.length === 1 && e.effects[0]?.op === "kill" && e.effects[0].target === "$it") {
      const ids = select2(e.selector);
      if (!ids) return "unknown";
      victims.push(...ids);
      return "quiet";
    }
    if (e.op !== "kill" && e.op !== "counter") return "unknown";
    const id = e.target === "$self" ? ctx.owner : choices[0] && e.target === "$" + choices[0].key ? selected : e.target;
    if (id === void 0 || id.startsWith("$")) return "unknown";
    if (e.op === "kill") {
      if (ctx.characters.get(id)?.status === "alive") victims.push(id);
      return "quiet";
    }
    if (e.op !== "counter" || step.effects.length !== 1 || typeof e.amount !== "number" || e.counter === "$counter")
      return "unknown";
    const board2 = BOARDS.find((b) => b === id);
    if (board2 && e.counter === "intrigue") {
      const n2 = ctx.boards[board2];
      return n2 === Math.min(3, Math.max(0, n2 + e.amount)) ? "quiet" : "changed";
    }
    const actor = ctx.characters.get(id);
    if (!actor) return id === "" ? "quiet" : "unknown";
    const n = actor.counters[e.counter];
    return n === Math.max(0, n + e.amount) ? "quiet" : "changed";
  }
  const alternatives = [];
  for (const target of targets) {
    const victims = [];
    const effects = step.effects.map((e) => collect(e, target, victims));
    if (effects.includes("unknown")) return;
    if (!effects.includes("changed")) alternatives.push(victims);
  }
  return alternatives;
}
function groupVictims(steps, ctx) {
  if (steps.length !== 1 || steps[0].choices?.length || steps[0].condition !== void 0) return;
  const groups = [];
  for (const effect of steps[0].effects) {
    if (effect.op !== "when" || effect.effects.length !== 1) return;
    const e = effect.effects[0];
    if (e.op === "protagonist-death") continue;
    if (e.op !== "each" || e.effects.length !== 1 || e.effects[0]?.op !== "kill" || e.effects[0].target !== "$it")
      return;
    groups.push(effect);
  }
  return groups.length ? quietTargets([{ effects: groups }], ctx)?.[0] : void 0;
}

// packages/engine/src/runtime/knowledge-traits.ts
var incidentTraits = {
  黑猫: { execution: "cancel" },
  教主: { execution: "repeat", thresholdMultiplier: 2 },
  临时工: { execution: "proxy", privateTrigger: true },
  手下: { maySuppress: true },
  仙人: { privateTrigger: true },
  AI: { totalThreshold: true }
};
var ordinary = {};
function traits(character) {
  return character && incidentTraits[character] || ordinary;
}
function hasVirtualArea(pack, character) {
  const rule = character && pack.characters[character];
  return character === "UP主" || !!(rule && (rule.abilityArea || rule.incidentAreaFromBase));
}
var characterEffects = {
  临时工: (phase, q) => phase === "day-end" && (q.kind === "kill" || q.counter === "guard" && q.sign === -1) ? "临时工日末死亡请求" : void 0,
  手下: (phase, q) => phase === "loop-start" && q.kind === "move" ? "手下选择开局区域" : void 0,
  学者: (phase, q) => phase === "loop-start" && q.sign === 1 && ["goodwill", "paranoia", "intrigue"].includes(q.counter ?? "") ? "学者轮回开始选择指示物" : void 0
};
function intrinsicCauses(pack, o, change, p, actor, characters, deaths, priorFriends, cats) {
  const causes = [];
  function add2(label, owner, requires = [], rule) {
    causes.push({
      category: rule ? "rule" : "character",
      label,
      owner,
      rule,
      requires,
      resources: [],
      notes: []
    });
  }
  if (actor && pack.characters[actor.character]?.protects && (change.kind === "move" || change.kind === "kill" || change.counter === "guard" && change.sign === -1)) add2(actor.character + "随行或代替受害者结算", actor.id);
  const character = actor && characterEffects[actor.character]?.(o.phase, change);
  if (character) add2(character, actor?.id);
  if (o.phase === "loop-start" && change.sign === 1) {
    if (change.target === "shrine" && change.counter === "intrigue")
      for (const c of cats) add2("黑猫的神社密谋", c.id);
    if (actor && change.counter === "paranoia" && priorFriends.has(actor.id) && p.x.includes("因果线"))
      add2("规则“因果线”的轮回开始效果", void 0, [], "因果线");
    if (actor && change.counter === "goodwill" && p.store.domains.get("identity:" + actor.id)?.has("亲友"))
      add2("已公开的亲友获得友好", actor.id, [{ key: "identity:" + actor.id, value: "亲友" }]);
  }
  if (actor && change.counter === "paranoia" && change.sign === 1 && deaths.size) {
    for (const [identity, partner] of [
      ["求爱者", "心上人"],
      ["心上人", "求爱者"]
    ]) {
      const survivor = "identity:" + actor.id;
      if (!p.store.domains.get(survivor)?.has(identity)) continue;
      for (const dead of deaths) {
        const key = "identity:" + dead;
        const special = ["临时工", "临时工？"].includes(characters.get(dead)?.character ?? "");
        if (dead === actor.id || !special && !p.store.domains.get(key)?.has(partner)) continue;
        add2(identity + "（" + actor.id + "）因" + dead + "死亡而增加不安", actor.id, [
          { key: survivor, value: identity },
          ...special ? [] : [{ key, value: partner }]
        ]);
      }
    }
  }
  return causes;
}

// packages/engine/src/runtime/knowledge-cards.ts
var CardReports = class {
  constructor(characters, boards) {
    this.characters = characters;
    this.boards = boards;
  }
  pendingGoodwill = /* @__PURE__ */ new Set();
  reveal;
  close(o) {
    const complete2 = o.type === "boundary" && o.phase === "mastermind-abilities" && this.reveal?.day === o.day && this.reveal.loop === o.loop;
    const missing = complete2 ? [...this.pendingGoodwill] : [];
    const unresolved = [];
    if (complete2) {
      for (const [id, report] of this.targets) {
        const actor = this.characters.get(id);
        if (actor && actor.status !== "alive") continue;
        if (report.move && actor && report.move !== actor.area)
          unresolved.push(id + " 的移动未发生，须核对禁行或替代移动");
        for (const part of ["plus", "minus"]) {
          if (Object.entries(report[part] ?? {}).some(([key, n]) => {
            if (key === report.bypass) return false;
            const old = actor?.counters[key] ?? (key === "intrigue" ? this.boards[id] : void 0);
            return old !== void 0 && old !== Math.min(actor ? Infinity : 3, Math.max(0, old + n));
          }))
            unresolved.push(id + " 缺少公开牌应产生的指示物变化");
        }
      }
    }
    this.reveal = void 0;
    this.pendingGoodwill.clear();
    this.targets.clear();
    return { missing, unresolved };
  }
  targets = /* @__PURE__ */ new Map();
  collect(o) {
    this.targets.clear();
    this.pendingGoodwill.clear();
    this.reveal = void 0;
    const placements = o.data.placements;
    if (!Array.isArray(placements) || placements.some((p) => !p || typeof p.kind !== "string" || typeof p.target !== "string"))
      return;
    const revealed = ["mastermind", "p0", "p1", "p2"].every(
      (owner) => placements.some((p) => p.owner === owner)
    );
    const blocks = placements.filter((p) => p.kind === "block-intrigue").length;
    if (revealed) this.reveal = o;
    const hopes = placements.filter((p) => p.kind === "hope+1").length;
    for (const target of new Set(placements.map((p) => p.target))) {
      const actor = this.characters.get(target);
      if (actor?.character === "幻想") continue;
      const kinds = placements.filter((p) => p.target === target).map((p) => p.kind);
      const dirs = kinds.filter((k) => ["horizontal", "vertical", "diagonal"].includes(k));
      const move = actor && dirs.length && !kinds.includes("block-movement") ? destination(actor.area, dirs) : void 0;
      const plus = {}, minus = {};
      let uncertain = false, bypass;
      for (const kind of kinds) {
        const m = /^(paranoia|goodwill|intrigue|hope|despair)([+-][12])$/.exec(kind);
        if (!m) continue;
        const counter = m[1] === "hope" && hopes >= 2 ? "goodwill" : m[1];
        if (kinds.includes("block-" + counter)) {
          if (!revealed) {
            uncertain = true;
            continue;
          }
          if (counter === "paranoia") continue;
          if (counter === "goodwill" || counter === "intrigue" && blocks === 1) {
            if (bypass && bypass !== counter) uncertain = true;
            bypass = counter;
          }
        }
        const n = Number(m[2]), part = n > 0 ? plus : minus;
        part[counter] = (part[counter] ?? 0) + n;
      }
      this.targets.set(target, {
        kinds,
        bypass,
        move: move || void 0,
        ...uncertain ? {} : { plus, minus }
      });
      if (revealed && !uncertain && bypass === "goodwill" && (plus.goodwill ?? 0) > 0 && actor?.status === "alive")
        this.pendingGoodwill.add(target);
    }
  }
  match(o) {
    if (o.phase !== "card-resolution") return;
    const id = String(o.data.character ?? o.data.board), r = this.targets.get(id);
    if (!r) return;
    if (o.type === "board" && BOARDS.includes(id)) {
      const old2 = this.boards[id];
      for (const part of ["plus", "minus"]) {
        const delta = r[part]?.intrigue;
        if (delta && old2 !== o.data.intrigue && Math.min(3, Math.max(0, old2 + delta)) === o.data.intrigue)
          return part;
      }
    }
    const old = this.characters.get(id);
    if (o.type !== "character" || !old || old.status !== "alive" || old.status !== o.data.status || !o.data.counters || typeof o.data.counters !== "object")
      return;
    const next = o.data.counters;
    if (old.area !== o.data.area) {
      if (r.move === o.data.area && COUNTERS.every((k) => old.counters[k] === next[k]))
        return "move";
      return;
    }
    if (!COUNTERS.some((k) => next[k] !== old.counters[k])) return;
    for (const part of ["plus", "minus"]) {
      const deltas = r[part];
      if (deltas && COUNTERS.every(
        (k) => Math.max(0, old.counters[k] + (deltas[k] ?? 0)) === next[k] || k === r.bypass && old.counters[k] === next[k]
      ))
        return part;
    }
  }
};

// packages/engine/src/runtime/knowledge-effects.ts
var reactive = /* @__PURE__ */ new Set(["death", "incident-completed", "goodwill-completed"]);
function directDeathEffect(source) {
  return source.ability?.timing === "death" && !source.delay && !source.invocation;
}
function sameArea(condition) {
  if (!condition || typeof condition !== "object") return false;
  if ("all" in condition) return condition.all.some(sameArea);
  if ("any" in condition) return condition.any.length > 0 && condition.any.every(sameArea);
  if (!("cmp" in condition) || condition.cmp !== "eq") return false;
  const field2 = (v, target) => !!v && typeof v === "object" && "field" in v && v.field === "area" && "target" in v && v.target === target;
  return field2(condition.left, "$it") && field2(condition.right, "$self") || field2(condition.right, "$it") && field2(condition.left, "$self");
}
function ownerRange(target, bindings, detached) {
  if (detached || !target) return;
  if (target === "$self") return "self";
  if (target === "$self.area") return "self-board";
  const options2 = target.startsWith("$") && bindings.get(target.slice(1));
  if (options2 && !Array.isArray(options2) && sameArea(options2.where)) return "same-area";
}
function dependsOnCulprit(value2, bindings) {
  if (typeof value2 === "string" && value2.startsWith("$")) {
    const key = value2.slice(1).split(".")[0];
    return key === "self" || key !== "it" && !bindings.has(key);
  }
  return !!value2 && typeof value2 === "object" && Object.values(value2).some((v) => dependsOnCulprit(v, bindings));
}
function bound(e) {
  if (e.op === "when") return e.effects.reduce((n, e2) => n + bound(e2), 0);
  if (e.op === "each")
    return e.selector.kind === "boards" ? 4 * e.effects.reduce((n, e2) => n + bound(e2), 0) : Infinity;
  if (["invoke-goodwill", "invoke-incident", "schedule", "move-corpse"].includes(e.op))
    return Infinity;
  if (e.op === "clear") return e.counter ? 1 : COUNTERS.length;
  if (e.op === "transfer" || e.op === "replace") return 2;
  return 1;
}
function singleTarget(effects) {
  return effects.length === 1 && (["counter", "move", "place", "remove", "kill", "revive", "clear", "replace"].includes(
    effects[0].op
  ) || effects[0].op === "when" && singleTarget(effects[0].effects));
}
function matchesChange(s, q) {
  if (s.kind && s.kind !== q.kind) return false;
  if (q.kind !== "counter") return true;
  if (s.sign !== void 0 && s.sign !== q.sign) return false;
  if (s.counter && !s.counter.startsWith("$")) return s.counter === q.counter;
  const choices = s.counter && s.choices.get(s.counter.slice(1));
  return !Array.isArray(choices) || choices.some((v) => v.startsWith("$") || v === q.counter);
}
function compileEffects(steps, timing, ability) {
  const result = [], choices = /* @__PURE__ */ new Map();
  const keys = steps.flatMap((step) => (step.choices ?? []).map((c) => c.key));
  const unique = new Set(keys.filter((k) => keys.indexOf(k) === keys.lastIndexOf(k)));
  function relatedChoices(c, comparison) {
    if (!c || typeof c !== "object") return [];
    if ("all" in c) return c.all.flatMap((part) => relatedChoices(part, comparison));
    if (!("cmp" in c) || c.cmp !== comparison) return [];
    const ref2 = (v) => v && typeof v === "object" && "ref" in v ? v.ref : void 0;
    const left = ref2(c.left), right = ref2(c.right);
    const other2 = left === "$it" ? right : right === "$it" ? left : void 0;
    return other2?.startsWith("$") && unique.has(other2.slice(1)) ? [other2.slice(1)] : [];
  }
  const reports = steps.some((s) => s.moveOthersFromEffectiveArea) ? Infinity : steps.reduce((n, s) => n + s.effects.reduce((n2, e) => n2 + bound(e), 0), 0);
  const safeSnapshot = !ability?.mandatory && steps.length === 1 && !steps[0].moveOthersFromEffectiveArea && singleTarget(steps[0].effects) && !reactive.has(timing);
  function walk(effects, at, bindings, conditions, detached = false, delay) {
    let independentOfCulprit = false;
    const add2 = (target, kind, counter, sign, destination2, amount, deathGuard) => result.push({
      ownerRange: ownerRange(target, bindings, detached),
      deathGuard,
      selection: !detached && target?.startsWith("$") && unique.has(target.slice(1)) ? {
        key: target.slice(1),
        different: relatedChoices(
          bindings.get(target.slice(1))?.where,
          "ne"
        ),
        equal: relatedChoices(
          bindings.get(target.slice(1))?.where,
          "eq"
        )
      } : void 0,
      counterSelection: !detached && counter?.startsWith("$") && unique.has(counter.slice(1)) ? counter.slice(1) : void 0,
      independentOfCulprit,
      timing: at,
      entryStep,
      target,
      kind,
      counter,
      sign,
      destination: destination2,
      amount,
      maxContribution: ability?.mandatory && amount !== void 0 && !bindings.has("it") && !detached ? Math.abs(amount) : void 0,
      choices: new Map(bindings),
      detached,
      ability,
      conditions,
      safeSnapshot,
      reports,
      delay
    });
    for (const e of effects) {
      independentOfCulprit = !ability && at === "incident" && !detached && !dependsOnCulprit([e, conditions, ...bindings.values()], bindings);
      switch (e.op) {
        case "counter":
          add2(
            e.target,
            "counter",
            e.counter,
            typeof e.amount === "number" ? Math.sign(e.amount) : void 0,
            void 0,
            typeof e.amount === "number" ? e.amount : void 0
          );
          break;
        case "when":
          walk(e.effects, at, bindings, [...conditions, e.condition], detached, delay);
          break;
        case "each":
          walk(
            e.effects,
            at,
            new Map([...bindings, ["it", e.selector]]),
            conditions,
            detached,
            delay
          );
          break;
        case "schedule":
          walk(
            e.effects,
            e.timing,
            /* @__PURE__ */ new Map(),
            [],
            true,
            delay ? { origin: "*", conditions: [] } : { day: e.day, loop: e.loop, origin: at, conditions }
          );
          break;
        case "invoke-goodwill":
        case "invoke-incident":
          result.push({
            ability,
            invocation: e,
            invocationTiming: at,
            timing: "*",
            choices: /* @__PURE__ */ new Map(),
            detached: true,
            conditions: [],
            safeSnapshot: false,
            reports: Infinity
          });
          break;
        case "clear":
          add2(e.target, "counter", e.counter, -1);
          break;
        case "transfer":
          add2(e.from, "counter", e.counter, -1);
          add2(e.to, "counter", e.counter, 1);
          break;
        case "replace":
          add2(e.target, "counter", e.from, -1);
          add2(e.target, "counter", e.to, 1);
          break;
        case "kill":
          add2(e.target, "kill");
          add2(e.target, "counter", "guard", -1, void 0, -1, true);
          break;
        case "revive":
          add2(e.target, "revive");
          break;
        case "remove":
          add2(e.target, "remove");
          break;
        case "move-corpse":
        case "move":
        case "place":
          add2(e.target, "move", void 0, void 0, e.area);
          break;
        case "reveal-identity":
        case "flag":
        case "protect-protagonists":
          break;
        case "protagonist-death":
          add2(void 0, "protagonist-death");
          break;
        case "fail":
          add2(void 0, "failure");
          break;
        case "end-loop":
        case "world-move":
        case "grant":
        case "ex":
        case "reveal-rule":
        case "reveal-culprit":
        case "recover-card":
        case "curse":
        case "same-identity":
          break;
        default:
          add2();
      }
    }
  }
  let entryStep = true;
  for (const step of steps) {
    for (const c of step.choices ?? []) choices.set(c.key, c.options);
    const at = reactive.has(timing) ? "*" : timing;
    const conditions = [ability?.condition, step.condition].filter(
      (v) => v !== void 0
    );
    if (step.moveOthersFromEffectiveArea) {
      result.push({
        kind: "move",
        timing: at,
        entryStep,
        ability,
        choices: new Map(choices),
        conditions,
        detached: reactive.has(timing),
        safeSnapshot: false,
        reports
      });
    } else walk(step.effects, at, choices, conditions, reactive.has(timing));
    entryStep = false;
  }
  for (const s of result) {
    if (s.maxContribution === void 0) continue;
    if (result.some(
      (other2) => other2 !== s && (!other2.kind || other2.kind === "counter") && (!other2.counter || other2.counter.startsWith("$") || other2.counter === s.counter) && (other2.sign === void 0 || other2.sign === s.sign)
    ))
      s.maxContribution = void 0;
  }
  return result;
}

// packages/engine/src/runtime/knowledge-pruning.ts
var ordinaryTriggerRoles = /* @__PURE__ */ new Set([
  "关键人物",
  "杀手",
  "主谋",
  "邪教徒",
  "亲友",
  "暴徒",
  "杀人狂",
  "传谣人",
  "平民",
  "魔女",
  "时间旅者",
  "心上人",
  "求爱者",
  "不安定因子",
  "因果残片"
]);
var PruningCatalog = class {
  constructor(pack, opening, roster) {
    this.pack = pack;
    this.publicTriggerModel = Object.keys(pack.identities).every(
      (i) => ordinaryTriggerRoles.has(i)
    );
    const definitions = [
      ...Object.values(pack.identities),
      ...Object.values(pack.plots),
      ...roster.map((c) => pack.characters[c.character]).filter(Boolean)
    ];
    const outstanding = new Set(
      definitions.flatMap((d) => d.abilities.filter((a) => a.mandatory && a.timing === "day-end"))
    );
    for (const [identity, definition] of Object.entries(pack.identities)) {
      for (const a of definition.abilities) {
        if (!a.mandatory || a.timing !== "day-end" || a.loopLimit !== void 0 || a.steps.length !== 1)
          continue;
        const step = a.steps[0], e = step.effects[0];
        if (step.choices?.length || step.effects.length !== 1 || e?.op !== "each" || e.selector.kind !== "alive" || e.effects.length !== 1 || e.effects[0]?.op !== "kill" || e.effects[0].target !== "$it")
          continue;
        this.dayEndKills.push({ identity, ability: a, step, selector: e.selector });
        outstanding.delete(a);
      }
    }
    this.otherDayEndObligations = outstanding.size;
    const scheduled = (e) => "effects" in e && (e.op === "schedule" && e.timing === "day-end" || e.effects.some(scheduled));
    const incidentSteps = /* @__PURE__ */ new Map();
    for (const [name, incident] of Object.entries(pack.incidents))
      incidentSteps.set(name, [...incident.steps, ...incident.afterIncidentSteps ?? []]);
    this.scheduledDayEnd = [
      ...definitions.flatMap((d) => d.abilities.flatMap((a) => a.steps)),
      ...[...incidentSteps.values()].flat()
    ].some((s) => s.effects.some(scheduled));
    this.failureRoles = Object.values(pack.identities).filter(
      (identity) => identity.abilities.some(
        (a) => a.timing === "death" && a.mandatory && a.condition === void 0 && a.threshold === void 0 && a.loopLimit === void 0 && a.steps.length === 1 && !a.steps[0].choices?.length && a.steps[0].condition === void 0 && a.steps[0].effects.length === 1 && a.steps[0].effects[0].op === "fail"
      )
    ).map((i) => i.name);
    const deathReactions = [
      ...Object.values(pack.identities),
      ...roster.map((c) => pack.characters[c.character])
    ].filter(Boolean).flatMap((d) => d.abilities).filter((a) => a.timing === "death");
    this.extraDeathReaction = deathReactions.some(
      (a) => a.steps.some((s) => s.effects.some((e) => e.op !== "fail"))
    );
    const completion = (a) => a.mandatory && a.timing === "incident-completed";
    this.completionRoles = Object.values(pack.identities).filter((d) => d.abilities.some(completion)).map((d) => d.name);
    this.completionCards = new Set(
      roster.filter((c) => pack.characters[c.character]?.abilities.some(completion)).map((c) => c.id)
    );
    const puppet = Object.values(pack.identities).some((i) => i.puppet);
    const abilities2 = (list) => list.flatMap((a) => compileEffects(a.steps, a.timing, a));
    for (const [name, d] of Object.entries(pack.identities))
      this.identities.set(name, abilities2(d.abilities));
    for (const [name, d] of Object.entries(pack.plots))
      this.rules.set(name, abilities2(d.abilities));
    for (const c of roster) {
      const list = pack.characters[c.character]?.abilities ?? [];
      const sources = abilities2(list);
      if (puppet || ["医生", "上位存在"].includes(c.character))
        for (const a of list.filter((a2) => a2.timing === "protagonist-abilities"))
          sources.push(
            ...compileEffects(
              a.steps,
              "mastermind-abilities",
              c.character === "上位存在" ? { ...a, threshold: 1 } : a
            )
          );
      if (c.character === "御神木" && list[0])
        sources.push(
          ...compileEffects(list[0].steps, "mastermind-abilities", { ...list[0], mandatory: true })
        );
      this.cards.set(c.id, sources);
    }
    for (const [name, steps] of incidentSteps) {
      this.events.set(name, compileEffects(steps, "incident"));
      const pair = distinctCounterPair(steps);
      if (pair) this.pairPrograms.set(name, pair);
    }
    const indirectOutputs = (source, seen) => {
      const e = source.invocation;
      if (!e) return [source];
      const key = JSON.stringify(e);
      if (seen.has(key)) return [source];
      const next = /* @__PURE__ */ new Set([...seen, key]);
      const at = source.invocationTiming ?? "*";
      const lists = e.op === "invoke-goodwill" ? roster.flatMap(
        (c) => (pack.characters[c.character]?.abilities ?? []).filter((a) => a.threshold !== void 0).map((a) => a.steps)
      ) : (e.name.startsWith("$") ? e.name === "$incident" && source.ability?.id === "ai" ? opening.incidents.map((i) => i.name) : Object.keys(pack.incidents) : [e.name]).flatMap((n) => incidentSteps.has(n) ? [incidentSteps.get(n)] : []);
      if (!lists.length) return [source];
      return lists.flatMap(
        (steps) => compileEffects(steps, at).flatMap((child) => indirectOutputs(child, next))
      );
    };
    for (const table of [this.rules, this.cards, this.events, this.identities])
      for (const sources of table.values())
        for (const source of sources)
          if (source.invocation) this.indirect.set(source, indirectOutputs(source, /* @__PURE__ */ new Set()));
  }
  identities = /* @__PURE__ */ new Map();
  rules = /* @__PURE__ */ new Map();
  cards = /* @__PURE__ */ new Map();
  events = /* @__PURE__ */ new Map();
  indirect = /* @__PURE__ */ new Map();
  effectIndex = /* @__PURE__ */ new Map();
  publicTriggerModel;
  failureRoles;
  extraDeathReaction;
  completionRoles;
  completionCards;
  dayEndKills = [];
  otherDayEndObligations;
  scheduledDayEnd;
  pairPrograms = /* @__PURE__ */ new Map();
  permitsOccurrence(name, c, occurred) {
    const definition = this.pack.incidents[name];
    const character = c?.character;
    if (!definition || definition.crowdThreshold !== void 0 || traits(character).privateTrigger)
      return true;
    if (!c) return true;
    if (c.status !== "alive") return occurred === false;
    if (traits(character).maySuppress && !occurred) return true;
    const counter = definition.thresholdCounter ?? "paranoia";
    const rawAmount = traits(character).totalThreshold && !definition.thresholdCounter ? Object.values(c.counters).reduce((a, b) => a + b, 0) : c.counters[counter] + (counter === "goodwill" ? c.counters.hope : counter === "paranoia" ? c.counters.despair : c.counters.despair - c.counters.hope);
    const amount = counter === "intrigue" ? Math.max(0, rawAmount) : rawAmount;
    const threshold = this.pack.characters[c.character].paranoia + (definition.thresholdOffset ?? 0) * (traits(character).thresholdMultiplier ?? 1);
    return amount >= threshold === occurred;
  }
  sourcesFor(group, id) {
    const table = {
      characters: this.cards,
      identities: this.identities,
      plots: this.rules,
      incidents: this.events
    }[group];
    return table.get(id) ?? [];
  }
  forChange(phase, change) {
    const key = [phase, change.kind, change.counter, change.sign].join("/");
    let result = this.effectIndex.get(key);
    if (!result) {
      const select2 = (table) => {
        const result2 = /* @__PURE__ */ new Map();
        for (const [name, list] of table) {
          const sources = list.filter(
            (s) => (s.timing === phase || s.timing === "*") && matchesChange(s, change) && (this.indirect.get(s)?.some(
              (out) => (out.timing === phase || out.timing === "*" || out.invocation) && matchesChange(out, change)
            ) ?? true)
          );
          if (sources.length) result2.set(name, sources);
        }
        return result2;
      };
      result = {
        identities: select2(this.identities),
        cards: select2(this.cards),
        rules: select2(this.rules),
        events: select2(this.events)
      };
      this.effectIndex.set(key, result);
    }
    return result;
  }
};
function indexOwners(roster, characters, change, virtualIdentities, pack) {
  const board2 = BOARDS.includes(change.target);
  const targetArea = board2 ? change.target : characters.get(change.target)?.area;
  let self, local;
  return (source) => {
    if (source.ownerRange === "self")
      return self ??= roster.filter((c) => c.id === change.target);
    if (!source.safeSnapshot || source.choices.has("areaMode") || virtualIdentities || !targetArea || source.ownerRange !== "same-area" && source.ownerRange !== "self-board")
      return roster;
    return local ??= roster.filter((c) => {
      const area = characters.get(c.id)?.area;
      return !area || area === targetArea || hasVirtualArea(pack, c.character);
    });
  };
}
function reaches(source, change, context) {
  if (!source.target || source.detached) return true;
  const id = change.target;
  const { owner } = context;
  const phase = context.clock.phase;
  const area = context.virtualArea || source.choices.has("areaMode") || !source.safeSnapshot && !(phase === "incident" && source.target === "$self.area" && !source.ability) ? void 0 : context.characters.get(owner ?? "")?.area;
  const board2 = BOARDS.includes(id);
  const to = source.destination;
  if (to && change.destination) {
    if (!to.startsWith("$") && to !== change.destination) return false;
    const options3 = source.choices.get(to.slice(1));
    if (Array.isArray(options3) && !options3.some((v) => v.startsWith("$") || v === change.destination))
      return false;
    if (area && Array.isArray(options3) && options3.length === 1 && options3[0] === "$adjacent-self" && !["horizontal", "vertical"].some((dir) => destination(area, [dir]) === change.destination))
      return false;
  }
  const target = source.target;
  if (!target.startsWith("$")) return target === id;
  if (target === "$self") return owner === void 0 || owner === id;
  if (target.endsWith(".area")) return board2 && (target !== "$self.area" || !area || area === id);
  const options2 = source.choices.get(target.slice(1));
  if (!options2) return true;
  if (Array.isArray(options2)) return options2.some((v) => v.startsWith("$") || v === id);
  if (board2 && !["boards", "alive-or-boards"].includes(options2.kind)) return false;
  if (!board2 && options2.kind === "boards") return false;
  const targetArea = board2 ? id : context.characters.get(id)?.area;
  return source.ownerRange !== "same-area" || !area || !targetArea || area === targetArea;
}
function eligibleSource(source, change, context, window, eventDay) {
  const o = context.clock, owner = context.owner;
  if (!reaches(source, change, context)) return false;
  if (directDeathEffect(source) && window.phase === o.phase && owner && !window.deaths.has(owner))
    return false;
  if (source.amount !== void 0 && change.before !== void 0 && change.after !== void 0 && source.safeSnapshot && !source.detached && source.ability && ["mastermind-abilities", "protagonist-abilities"].includes(o.phase)) {
    const cap = BOARDS.includes(change.target) ? 3 : Infinity;
    if (Math.min(cap, Math.max(0, change.before + source.amount)) !== change.after) return false;
  }
  if (source.entryStep && !source.detached && source.ability?.mandatory && (source.timing === "day-end" || source.timing === "loop-end") && window.endEntry) {
    Object.assign(context, window.endEntry, { staticOnly: false });
  }
  if (source.conditions.some((c) => publicCondition(c, context) === false)) return false;
  if (!source.detached) {
    const actor = context.characters.get(owner ?? "");
    if (!context.staticOnly && source.ability && actor && actor.status !== "alive" && !["loop-end", "incident-completed", "death"].includes(source.ability.timing))
      return false;
    if (source.ability?.threshold !== void 0) {
      const goodwill = publicNumber({ counter: "goodwill", target: "$self" }, context);
      if (goodwill !== void 0 && goodwill < source.ability.threshold) return false;
    }
    const target = source.choices.get((source.target ?? "").slice(1));
    if (target && !Array.isArray(target) && publicCondition(target.where, {
      ...context,
      bindings: { ...context.bindings, it: change.target }
    }) === false)
      return false;
  }
  if (source.delay?.day === void 0) return true;
  const phases = [
    "discussion",
    "loop-start",
    "day-start",
    "mastermind-cards",
    "protagonist-cards",
    "card-resolution",
    "mastermind-abilities",
    "protagonist-abilities",
    "incident",
    "captain-change",
    "day-end",
    "loop-end"
  ];
  for (let loop = 1; loop <= o.loop; loop++)
    for (let day = 1; day <= context.days; day++) {
      if (eventDay !== void 0 && (day !== eventDay || window.occurrence.get(loop + ":" + day) === false))
        continue;
      if (loop === o.loop && (day > o.day || day === o.day && source.delay.origin !== "*" && phases.indexOf(source.delay.origin) > phases.indexOf(o.phase)))
        continue;
      const origin = { ...context, staticOnly: true, clock: { ...o, loop, day } };
      if (source.delay.conditions.some((c) => publicCondition(c, origin) === false)) continue;
      const dueDay = publicNumber(source.delay.day, origin);
      const dueLoop = source.delay.loop === void 0 ? loop : publicNumber(source.delay.loop, origin);
      if ((dueDay === void 0 || dueDay === o.day) && (dueLoop === void 0 || dueLoop === o.loop))
        return true;
    }
  return false;
}

// packages/engine/src/runtime/knowledge-causes.ts
function counterCauses(causes, delta, budget = 4096, work) {
  if (delta <= 1 || causes.every((c) => (c.maxContribution ?? Infinity) >= delta)) return causes;
  const result = causes.filter((c) => (c.maxContribution ?? Infinity) >= delta);
  const small = causes.filter((c) => (c.maxContribution ?? Infinity) < delta);
  const suffix = new Array(small.length + 1).fill(0);
  for (let i = small.length - 1; i >= 0; i--)
    suffix[i] = suffix[i + 1] + small[i].maxContribution;
  const path = [];
  function visit(start, total) {
    if (--budget < 0 || path.length > 256) return false;
    if (work && path.length) work.branches++;
    if (total >= delta) {
      if (path.some((c) => total - c.maxContribution >= delta)) return true;
      const guards = /* @__PURE__ */ new Map();
      for (const c of path)
        for (const g of c.requires) {
          if (guards.has(g.key) && guards.get(g.key) !== g.value) return true;
          guards.set(g.key, g.value);
        }
      const choices = path.flatMap((c) => c.choices ?? []);
      if (choices.some(
        (a) => !a.different && choices.some(
          (b) => a.key === b.key && (b.different ? a.value === b.value : a.value !== b.value)
        )
      ))
        return true;
      result.push({
        choices,
        category: "joint",
        label: path.map((c) => c.label).join(" ＋ "),
        requires: [...guards].map(([key, value2]) => ({ key, value: value2 })),
        resources: path.flatMap((c) => c.resources),
        notes: [.../* @__PURE__ */ new Set([...path.flatMap((c) => c.notes), "净变化至少需要这些来源共同贡献。"])]
      });
      return true;
    }
    for (let i = start; i < small.length && total + suffix[i] >= delta; i++) {
      const c = small[i];
      path.push(c);
      if (!visit(i + 1, total + c.maxContribution)) return false;
      path.pop();
    }
    return true;
  }
  return visit(0, 0) ? result : void 0;
}
var CauseNetwork = class {
  constructor(quota, ordinary2, budget = 2e4) {
    this.quota = quota;
    this.ordinary = ordinary2;
    this.budget = budget;
  }
  byObservation = /* @__PURE__ */ new Map();
  excludedCauses = /* @__PURE__ */ new Set();
  components = [];
  checks = 0;
  uncertain = false;
  add(p, record) {
    this.addMany(p, [record]);
  }
  addMany(p, records) {
    for (const record of records) this.install(p, record);
    p.active = p.store.propagate();
  }
  install(p, record) {
    this.byObservation.set(record.key ?? record.observation, record);
    const sole = record.alternatives.length === 1 && record.alternatives[0];
    if (record.phase === "incident" && sole && sole.category === "event" && !sole.resources.length && !sole.choices?.length && sole.requires.length === 1) {
      const guard = sole.requires[0];
      const domain = p.store.values(guard.key);
      if (guard.key.startsWith("event:") && domain.size === 1 && domain.has(guard.value)) return;
    }
    const links = new Set(
      record.alternatives.flatMap((a) => [
        ...a.requires.map((r) => r.key),
        ...a.resources.map((r) => r.key),
        ...(a.choices ?? []).map((c) => c.key),
        ...a.requires.filter((r) => this.ordinary.has(r.key)).map((r) => `quota:${r.value}`)
      ])
    );
    for (const key of p.store.related(
      record.alternatives.flatMap((a) => a.requires.map((g) => g.key))
    ))
      links.add(key);
    const connected = this.components.filter((c) => [...c.links].some((k) => links.has(k)));
    const records = [...connected.flatMap((c) => c.records), record];
    for (const c of connected) {
      for (const k of c.links) links.add(k);
      p.store.upsert({ name: c.name, reads: [], revise() {
      } });
    }
    this.components = this.components.filter((c) => !connected.includes(c));
    const component = { name: `cause:${record.key ?? record.observation}`, records, links };
    this.components.push(component);
    const reads = [
      ...new Set(
        records.flatMap((r) => r.alternatives.flatMap((a) => a.requires.map((r2) => r2.key)))
      )
    ];
    const capacities = /* @__PURE__ */ new Map();
    for (const r of records)
      for (const a of r.alternatives)
        for (const resource of a.resources)
          capacities.set(resource.key, Math.max(capacities.get(resource.key) ?? 0, resource.limit));
    const windowLimits = /* @__PURE__ */ new Map();
    for (const r of records)
      for (const a of r.alternatives)
        for (const res of a.resources) {
          if (!res.activation) continue;
          windowLimits.set(res.key, Math.max(windowLimits.get(res.key) ?? 0, res.activation.limit));
        }
    const constraint = {
      name: component.name,
      reads: records.length === 1 && record.alternatives.every((a) => a.requires.length <= 1) ? reads : [...p.store.related(reads)],
      cause: true,
      revise: (store) => {
        const possible = (a) => !this.excludedCauses.has(a) && a.resources.every((r) => r.limit >= 1) && a.requires.every(
          (g) => store.values(g.key).has(g.value) && (!this.ordinary.has(g.key) || (this.quota.get(g.value) ?? Infinity) >= 1)
        );
        const rows = [];
        for (const r of records) {
          const row = r.alternatives.filter(possible);
          if (!row.length) return store.invalidate();
          const guard = row[0].requires[0];
          if (guard && this.quota.get(guard.value) === 1 && row.every(
            (a) => a.requires.length === 1 && a.requires[0].value === guard.value && this.ordinary.has(a.requires[0].key)
          )) {
            const owners = new Set(row.map((a) => a.requires[0].key));
            for (const key of this.ordinary) {
              const domain = store.domains.get(key);
              if (domain?.has(guard.value) && !owners.has(key))
                store.narrow(
                  key,
                  [...domain].filter((v) => v !== guard.value)
                );
            }
          }
          for (const { key } of row[0].requires) {
            if (row.some((a) => a.requires.every((g) => g.key !== key))) continue;
            store.narrow(
              key,
              row.flatMap((a) => a.requires.filter((g) => g.key === key).map((g) => g.value))
            );
          }
          rows.push(row);
        }
        if (!store.consistent || rows.length === 1 && rows[0].every(
          (a) => a.category !== "joint" && a.requires.filter((g) => store.values(g.key).size > 1).length <= 1
        ))
          return;
        if (rows.length > 1e3) {
          this.uncertain = true;
          return;
        }
        const candidates = rows.map((row) => row.filter(possible)).sort((a, b) => a.length - b.length);
        if (candidates.some((row) => !row.length)) return store.invalidate();
        const supported = /* @__PURE__ */ new Set();
        const allCauses = new Set(candidates.flat());
        const values = new Map(reads.map((key) => [key, /* @__PURE__ */ new Set()]));
        const selected = /* @__PURE__ */ new Map();
        const counts = /* @__PURE__ */ new Map();
        const used = /* @__PURE__ */ new Map();
        const windows = /* @__PURE__ */ new Map();
        const bindings = /* @__PURE__ */ new Map();
        const forbidden = /* @__PURE__ */ new Map();
        const path = [];
        let remaining = this.budget, exhausted = false, complete2 = false, found = false;
        const visit = (index) => {
          if (index === candidates.length) {
            const projection = store.probe(selected);
            if (!projection) return;
            found = true;
            for (const a of path) supported.add(a);
            for (const [key, supportedValues] of values) {
              for (const v of projection.values(key))
                if (!this.ordinary.has(key) || selected.get(key) === v || (counts.get(v) ?? 0) < (this.quota.get(v) ?? Infinity))
                  supportedValues.add(v);
            }
            complete2 = supported.size === allCauses.size && reads.every((key) => values.get(key).size === store.values(key).size);
            return;
          }
          for (const a of candidates[index]) {
            if (remaining-- <= 0) {
              exhausted = true;
              return;
            }
            this.checks++;
            if (a.requires.some((g) => selected.has(g.key) && selected.get(g.key) !== g.value))
              continue;
            if (a.choices?.some(
              (c) => c.different ? bindings.get(c.key) === c.value : bindings.has(c.key) && bindings.get(c.key) !== c.value || forbidden.get(c.key)?.has(c.value)
            ))
              continue;
            const added = a.requires.filter((g) => !selected.has(g.key));
            for (const g of added) {
              selected.set(g.key, g.value);
              if (this.ordinary.has(g.key)) counts.set(g.value, (counts.get(g.value) ?? 0) + 1);
            }
            if (added.every(
              (g) => (counts.get(g.value) ?? 0) <= (this.quota.get(g.value) ?? Infinity)
            )) {
              const addedWindows = [];
              let fits = true;
              for (const r of a.resources) {
                used.set(r.key, (used.get(r.key) ?? 0) + 1);
                if (used.get(r.key) > capacities.get(r.key)) fits = false;
                if (!r.activation) continue;
                const active = windows.get(r.key) ?? /* @__PURE__ */ new Set();
                if (!active.has(r.activation.window)) {
                  active.add(r.activation.window);
                  if (active.size > windowLimits.get(r.key)) fits = false;
                  windows.set(r.key, active);
                  addedWindows.push({ active, window: r.activation.window });
                }
              }
              const addedChoices = [];
              for (const c of a.choices ?? []) {
                if (c.different) {
                  const blocked = forbidden.get(c.key) ?? /* @__PURE__ */ new Set();
                  if (blocked.has(c.value)) continue;
                  blocked.add(c.value);
                  forbidden.set(c.key, blocked);
                } else {
                  if (bindings.has(c.key)) continue;
                  bindings.set(c.key, c.value);
                }
                addedChoices.push(c);
              }
              path.push(a);
              if (fits) visit(index + 1);
              path.pop();
              for (const c of addedChoices) {
                if (c.different) forbidden.get(c.key).delete(c.value);
                else bindings.delete(c.key);
              }
              for (const w of addedWindows) w.active.delete(w.window);
              for (const r of a.resources) used.set(r.key, used.get(r.key) - 1);
            }
            for (const g of added) {
              selected.delete(g.key);
              if (this.ordinary.has(g.key)) counts.set(g.value, counts.get(g.value) - 1);
            }
            if (complete2 || exhausted) return;
          }
        };
        visit(0);
        if (exhausted) {
          this.uncertain = true;
          return;
        }
        if (!found) return store.invalidate();
        if (store === p.store) {
          for (const a of allCauses) if (!supported.has(a)) this.excludedCauses.add(a);
        }
        for (const [key, keep] of values) store.narrow(key, keep);
      }
    };
    p.store.upsert(constraint);
  }
};

// packages/engine/src/runtime/knowledge-scope.ts
function bindChoices2(source, change, window) {
  const key = (name) => JSON.stringify([...window, name]);
  const choices = [];
  if (source.selection) {
    for (const name of [source.selection.key, ...source.selection.equal])
      choices.push({ key: key(name), value: change.target });
    for (const name of source.selection.different)
      choices.push({ key: key(name), value: change.target, different: true });
  }
  if (source.counterSelection && change.counter)
    choices.push({ key: key(source.counterSelection), value: change.counter });
  return choices.length ? choices : void 0;
}
var CausalScope = class {
  constructor(pack, opening) {
    this.pack = pack;
    this.opening = opening;
    this.hasIncidentAreaIdentity = Object.values(pack.identities).some(
      (identity) => identity.baseIncidentArea && identity.baseIncidentArea !== "actual"
    );
    this.days = opening.days;
    this.loops = opening.loops;
    this.characters = new Map(opening.characters.map((c) => [c.id, structuredClone(c)]));
    this.boards = { ...opening.boards };
    this.cardReports = new CardReports(this.characters, this.boards);
    this.initialAreas = new Map(opening.characters.map((c) => [c.id, c.area]));
    this.eventSchedule = opening.incidents;
    this.scheduledDays = new Set(opening.incidents.map((i) => i.day));
    this.roster = [...opening.roster ?? opening.characters];
    const temporary = this.roster.find((c) => c.character === "临时工");
    if (temporary && !this.roster.some((c) => c.character === "临时工？"))
      this.roster.push({ id: temporary.id + "_replacement", character: "临时工？" });
    this.catalog = new PruningCatalog(pack, opening, this.roster);
  }
  characters;
  boards;
  roster;
  catalog;
  networks = /* @__PURE__ */ new Map();
  relationFacts = /* @__PURE__ */ new Map();
  // At discussion entry the engine still exposes the previous loop's final
  // counters. Reset publications follow, before the loop-start boundary.
  lastBoundary;
  declared;
  directRequest;
  hasIncidentAreaIdentity;
  cardReports;
  initialAreas;
  resetTargets = /* @__PURE__ */ new Set();
  quietDayEnd = false;
  deathsInWindow = /* @__PURE__ */ new Set();
  impliedIdentities = {};
  cityQualifiedAtDeath = /* @__PURE__ */ new Set();
  endEntry;
  movedInWindow = /* @__PURE__ */ new Set();
  eventSchedule;
  scheduledDays;
  occurrence = /* @__PURE__ */ new Map();
  pairWindow;
  pairResults = /* @__PURE__ */ new WeakMap();
  pairStates = /* @__PURE__ */ new Map();
  pairBranches = 0;
  counterWork = { branches: 0 };
  fixedIncidentReports = /* @__PURE__ */ new Map();
  priorFriends = /* @__PURE__ */ new Set();
  window;
  publicRelations = [];
  days;
  loops;
  eventRelations = /* @__PURE__ */ new Map();
  incidentPairs = /* @__PURE__ */ new Map();
  knownProfiles = /* @__PURE__ */ new Map();
  version = 0;
  summary(o, kind) {
    return {
      kind,
      observation: o.sequence,
      phase: o.phase,
      target: String(o.data.board ?? o.data.day ?? ""),
      characters: [],
      rules: [],
      events: [],
      skippedCharacters: [],
      skippedRules: [],
      skippedEvents: [],
      conservative: [],
      deferred: false
    };
  }
  context(o, source, owner, target = String(o.data.board ?? o.data.character)) {
    const character = this.roster.find((c) => c.id === owner)?.character;
    return {
      clock: o,
      occurred: (name) => {
        if (this.pack.incidents["伪造事件"] || source.detached) return;
        const slots = this.eventSchedule.filter((e) => e.name === name && e.day <= o.day);
        const flags = slots.map((e) => this.occurrence.get(o.loop + ":" + e.day));
        if (flags.includes(true)) return true;
        if (flags.every((v) => v === false)) return false;
      },
      days: this.days,
      loops: this.loops,
      pack: this.pack,
      characters: this.characters,
      boards: this.boards,
      owner,
      target,
      bindings: !source.detached && source.target?.startsWith("$") && !source.target.includes(".") ? { [source.target.slice(1)]: target } : {},
      staticOnly: source.detached || !source.safeSnapshot,
      moved: source.detached || !this.lastBoundary ? void 0 : this.movedInWindow,
      virtualArea: hasVirtualArea(this.pack, character) || this.hasIncidentAreaIdentity && o.phase === "incident" || source.choices.has("areaMode")
    };
  }
  eligible(source, o, change, owner, eventDay) {
    return eligibleSource(
      source,
      change,
      this.context(o, source, owner, change.target),
      {
        phase: this.lastBoundary?.phase,
        deaths: this.deathsInWindow,
        endEntry: this.endEntry,
        occurrence: this.occurrence
      },
      eventDay
    );
  }
  resources(source, o, owner) {
    const a = source.ability;
    if (!a || source.detached || source.timing === "*") return [];
    const reports = Math.max(1, source.reports), base = a.sharedKey ?? `${owner}:${a.id}`;
    const ownerName = owner.startsWith("plot:") ? owner.slice(5) : this.roster.find((c) => c.id === owner)?.character ?? owner;
    const abilityName = { brain: "主谋能力", "rumor-intrigue": "区域密谋能力" }[a.id] ?? "相关能力";
    const label = `${ownerName}·${abilityName}${a.sharedKey ? "（共享使用次数）" : ""}`;
    const reportLimit = (n) => Number.isFinite(n) ? "最多解释 " + n + " 条公开变化" : "可解释多个对象的变化";
    const activation = JSON.stringify([o.day, o.phase, owner, a.id]);
    return [
      ...a.mandatory && Number.isFinite(reports) && ["day-end", "loop-end"].includes(a.timing) ? [
        {
          key: JSON.stringify(["mandatory", o.loop, o.day, o.phase, owner, a.id]),
          limit: reports,
          label: label + "：本次强制结算最多产生 " + reports + " 项变化"
        }
      ] : [],
      ...!a.mandatory ? [
        {
          key: `phase:${o.loop}:${o.day}:${o.phase}:mastermind:${base}`,
          limit: reports,
          activation: { window: activation, limit: 1 },
          label: `${label}：第 ${o.loop} 轮第 ${o.day} 日本阶段至多 1 次（${reportLimit(reports)}）`
        }
      ] : [],
      ...a.loopLimit !== void 0 ? [
        {
          key: `loop:${o.loop}:${base}`,
          limit: a.mandatory && a.sharedKey ? Infinity : a.loopLimit * reports,
          activation: { window: o.day + "/" + o.phase, limit: a.loopLimit },
          label: `${label}：第 ${o.loop} 轮至多 ${a.loopLimit} 次（${reportLimit(a.loopLimit * reports)}）`
        }
      ] : []
    ];
  }
  network(p) {
    this.knownProfiles.set(p.id, p);
    let network = this.networks.get(p.id);
    if (!network) {
      const ordinary2 = new Set(
        this.roster.filter((c) => !["局外人", "模仿犯", "临时工", "临时工？"].includes(c.character)).map((c) => `identity:${c.id}`)
      );
      network = new CauseNetwork(new Map(Object.entries(p.identityCounts)), ordinary2);
      this.networks.set(p.id, network);
    }
    return network;
  }
  get causeBranches() {
    let branches = this.pairBranches + this.counterWork.branches;
    for (const network of this.networks.values()) branches += network.checks;
    return branches;
  }
  relations(profiles) {
    const areas2 = {
      school: "学校",
      hospital: "医院",
      city: "都市",
      shrine: "神社"
    };
    const result = [];
    const initialCases = profiles.map((p) => {
      return {
        when: [[p.y, ...p.x].join(" ＋ ")],
        alternatives: ["同时满足本组合的全部联合条件"],
        limits: [
          `常规角色初始身份名额：${Object.entries(p.identityCounts).filter(([, n]) => n > 0).map(([r, n]) => `${r} × ${n}`).join("、")}。局外人、模仿犯不占用这些名额。`,
          ...this.roster.some((c) => c.character === "模仿犯") ? ["模仿犯的初始身份须与其复制对象相同；因果残片按平民身份参与此关系。"] : [],
          ...this.roster.some((c) => c.character === "局外人") ? ["局外人身份必须不在所选规则的身份池中。"] : [],
          ...this.pack.anniversary ? [
            "周年设定有平民时须指定一名因果残片；其基础身份按平民计算，仍须满足身份名额和复制关系。"
          ] : [],
          "同一角色重复担任普通事件当事人时，两次真实事件均须允许复用；区域当事人与真实事件类型必须匹配。"
        ],
        notes: []
      };
    });
    if (initialCases.length)
      result.push({
        id: "initial-relations",
        observation: 0,
        fact: "开局联合条件：规则组合决定身份名额，事件和特殊身份仍有跨表限制。",
        implications: [],
        cases: initialCases
      });
    for (const [factKey, fact] of this.relationFacts) {
      const grouped = /* @__PURE__ */ new Map();
      const all2 = [];
      for (const p of profiles.length ? profiles : this.knownProfiles.values()) {
        const network = this.networks.get(p.id);
        const record = network?.byObservation.get(factKey);
        if (!record) continue;
        const possible = profiles.length ? record.alternatives.filter(
          (a) => !network.excludedCauses.has(a) && a.requires.every((g) => p.store.values(g.key).has(g.value))
        ) : record.alternatives;
        all2.push(...possible);
        const row = {
          when: [],
          alternatives: [...new Set(possible.map((a) => a.label))],
          limits: [...new Set(possible.flatMap((a) => a.resources.map((r) => r.label)))],
          notes: [
            .../* @__PURE__ */ new Set([
              ...possible.flatMap((a) => a.notes),
              ...network?.uncertain ? ["关联约束检查达到预算，未知解释保留。"] : [],
              ...!profiles.length ? ["该组合已排除；此处保留形成矛盾的原因与限制。"] : []
            ])
          ]
        };
        const key = JSON.stringify(row), existing = grouped.get(key) ?? row;
        existing.when.push([p.y, ...p.x].join(" ＋ "));
        grouped.set(key, existing);
      }
      const implications = [];
      const rules = [...new Set(all2.flatMap((a) => a.rule ? [a.rule] : []))];
      const others = all2.filter((a) => !a.rule);
      if (profiles.length && rules.length === 1 && !others.length)
        implications.push(`所有相容解释都要求剧本含有“${rules[0]}”。`);
      if (rules.length && others.length && others.every((a) => a.requires.length > 0))
        implications.push(
          `若不包含${rules.map((r) => `“${r}”`).join("、")}中的任何规则，则至少满足：${[...new Set(others.map((a) => a.label))].join(" 或 ")}。`
        );
      result.push({
        id: `cause:${factKey}`,
        observation: fact.observation,
        fact: `第 ${fact.loop} 轮第 ${fact.day} 日：${fact.description ?? (areas2[fact.target] ?? fact.target) + "密谋增加"}，以下原因至少成立一项。`,
        implications,
        cases: [...grouped.values()].map((c) => ({ ...c, when: [...new Set(c.when)] }))
      });
    }
    for (const p of profiles)
      for (const entry of this.eventRelations.get(p.id) ?? []) {
        const existing = result.find((r) => r.id === entry.id);
        const projected = structuredClone(entry);
        const info = this.incidentPairs.get(p.id + ":" + entry.observation);
        const survivingPairs = info.pairs.filter(
          (pair) => p.store.values("event:" + info.day).has(pair.name) && p.store.values("culprit:" + info.day).has(pair.id)
        );
        projected.cases[0].alternatives = survivingPairs.map((pair) => pair.label);
        projected.cases[0].notes.push(...new Set(survivingPairs.flatMap((pair) => pair.pending)));
        if (existing) existing.cases.push(...projected.cases);
        else result.push(projected);
      }
    for (const entry of result) {
      const cases = /* @__PURE__ */ new Map();
      for (const row of entry.cases) {
        const key = JSON.stringify({ ...row, when: [] }), prior = cases.get(key);
        if (prior) prior.when = [.../* @__PURE__ */ new Set([...prior.when, ...row.when])];
        else cases.set(key, row);
      }
      entry.cases = [...cases.values()];
    }
    result.push(...structuredClone(this.publicRelations));
    return result.sort((a, b) => a.observation - b.observation);
  }
  /** Necessary cause clause, NOT an assertion that a complete hidden history exists. */
  pairModes(id) {
    const actor = this.roster.find((c) => c.id === id)?.character;
    if (!actor) return;
    if (traits(actor).execution === "cancel") return [];
    if (traits(actor).execution === "repeat") return ["repeated"];
    if (traits(actor).execution === "proxy") {
      const proxies = [...this.characters.values()].filter(
        (c) => c.character === "临时工？" && c.status === "alive"
      );
      if (proxies.length > 1) return;
      if (proxies.length && this.characters.get(id)?.status === "alive")
        return ["ordinary", "parallel"];
    }
    return ["ordinary"];
  }
  startPair(name, ids) {
    const modes = this.pairWindow.modes;
    const executions = /* @__PURE__ */ new Map();
    const options2 = ids.map((id) => this.pairModes(id));
    const ordinaryOnly = options2.every((m) => m?.length === 1 && m[0] === "ordinary");
    for (const mode of new Set(options2.flatMap((m) => m ?? []))) {
      const key = JSON.stringify([name, mode]);
      let execution = modes.get(key);
      if (!execution) {
        execution = new PairExecution(this.catalog.pairPrograms.get(name), mode);
        modes.set(key, execution);
      }
      executions.set(mode, execution);
    }
    return { name, reports: 0, ordinaryOnly, executions };
  }
  pairCulprits(tracker, ids, scope, sequence, change) {
    const valid = /* @__PURE__ */ new Set();
    for (const [mode, execution] of tracker.executions) {
      let result = this.pairResults.get(execution);
      if (result?.sequence !== sequence) {
        const before = execution.branches;
        result = { sequence, possible: execution.advance(this.characters, change) };
        this.pairResults.set(execution, result);
        this.pairBranches += execution.branches - before;
      }
      if (result.possible) valid.add(mode);
      if (execution.uncertain) scope.needsHistory = true;
    }
    if (tracker.ordinaryOnly) return valid.has("ordinary") ? ids : [];
    return ids.filter((id) => {
      const modes = this.pairModes(id);
      if (!modes) {
        scope.needsHistory = true;
        return true;
      }
      return modes.some((mode) => valid.has(mode));
    });
  }
  visibleEffect(o, profiles, change, description, declared, batch) {
    const scope = this.summary(o, description ? "visible-effect" : "board-intrigue");
    const board2 = change.target;
    scope.target = board2;
    const relevantRules = /* @__PURE__ */ new Set(), relevantCharacters = /* @__PURE__ */ new Set(), relevantEvents = /* @__PURE__ */ new Set();
    const allRules = new Set(profiles.flatMap((p) => [p.y, ...p.x]));
    const key = description ? [o.sequence, change.kind, change.counter].filter(Boolean).join("/") : o.sequence;
    const clauses = /* @__PURE__ */ new Map();
    const labels = /* @__PURE__ */ new Set();
    let checkedExclusion = false;
    const boardOnly = /* @__PURE__ */ new Set();
    const matches = /* @__PURE__ */ new Map();
    const eligible = (source, owner, day) => {
      let byOwner = matches.get(source);
      if (!byOwner) matches.set(source, byOwner = /* @__PURE__ */ new Map());
      const key2 = JSON.stringify([owner, day]);
      if (!byOwner.has(key2)) byOwner.set(key2, this.eligible(source, o, change, owner, day));
      return byOwner.get(key2);
    };
    const cats = this.roster.filter((c) => c.character === "黑猫");
    const victim = this.characters.get(change.target);
    const virtualVictim = this.hasIncidentAreaIdentity || !!(victim && this.pack.characters[victim.character]?.incidentAreaFromBase);
    const indexed = this.catalog.forChange(o.phase, change);
    const owners = indexOwners(
      this.roster,
      this.characters,
      change,
      this.hasIncidentAreaIdentity && o.phase === "incident",
      this.pack
    );
    const roleSources = /* @__PURE__ */ new Map();
    for (const [identity, sources] of indexed.identities) {
      for (const source of sources) {
        for (const c of owners(source)) {
          if (!eligible(source, c.id)) continue;
          let roles = roleSources.get(c.id);
          if (!roles) roleSources.set(c.id, roles = /* @__PURE__ */ new Map());
          const list = roles.get(identity);
          if (list) list.push(source);
          else roles.set(identity, [source]);
        }
      }
    }
    const cardSources = /* @__PURE__ */ new Map();
    for (const [id, sources] of indexed.cards) {
      const valid = sources.filter((s) => eligible(s, id));
      if (valid.length) cardSources.set(id, valid);
    }
    const participating = this.roster.filter(
      (c) => roleSources.has(c.id) || cardSources.has(c.id) || !description && indexed.identities.size > 0 && ["临时工", "临时工？"].includes(c.character)
    );
    const ruleSources = new Map(
      [...indexed.rules].filter(([id]) => allRules.has(id)).map(([id, ss]) => [id, ss.filter((s) => eligible(s))])
    );
    for (const p of profiles) {
      if (!p.active) continue;
      const alternatives = [];
      const pairCauses = /* @__PURE__ */ new Map();
      const guardCauses = /* @__PURE__ */ new Set();
      let unboundRepeat = false;
      let fixedReport;
      let fixedAlternatives = 0;
      const add2 = (source, category, label, owner, requires = [], rule) => alternatives.push({
        category,
        label,
        owner,
        ability: source.ability?.id,
        rule,
        requires,
        resources: this.resources(source, o, owner),
        choices: source.ability && source.reports > 1 && !source.detached && source.timing === o.phase ? bindChoices2(source, change, [
          "ability-choice",
          o.loop,
          o.day,
          o.phase,
          owner,
          source.ability.source,
          source.ability.id
        ]) : void 0,
        maxContribution: source.ability?.mandatory && source.timing === o.phase && ["day-end", "loop-end", "mastermind-abilities"].includes(o.phase) && !source.detached ? source.maxContribution : void 0,
        notes: source.detached ? [
          source.delay ? `可能的延迟效果于第 ${o.loop} 轮第 ${o.day} 日 ${o.phase} 到期，发动时点为 ${source.delay.origin}。` : directDeathEffect(source) ? "该能力在角色死亡时触发。" : "间接来源：保留先前发动条件。"
        ] : source.conditions.some(
          (c) => publicCondition(c, this.context(o, source, owner)) === void 0
        ) ? ["部分条件未知，保留可能解释。"] : []
      });
      for (const rule of [p.y, ...p.x])
        for (const source of ruleSources.get(rule) ?? []) {
          relevantRules.add(rule);
          add2(
            source,
            "rule",
            `规则“${rule}”的${source.detached ? "延迟或间接" : description ? source.ability?.id ?? "直接" : "区域密谋"}效果`,
            `plot:${rule}`,
            [],
            rule
          );
        }
      for (const c of participating) {
        if (["临时工", "临时工？"].includes(c.character)) {
          relevantCharacters.add(c.id);
          alternatives.push({
            category: "character",
            label: `${c.character}（${c.id}）的替身/当前身份来源待定`,
            requires: [],
            resources: [],
            notes: ["保留特殊身份转换解释。"]
          });
          continue;
        }
        for (const source of cardSources.get(c.id) ?? []) {
          relevantCharacters.add(c.id);
          add2(
            source,
            "character",
            `${c.character}（${c.id}）的${source.detached ? "间接效果" : description ? source.ability?.id ?? "角色能力" : "角色能力"}`,
            c.id
          );
        }
        const key2 = "identity:" + c.id, roles = roleSources.get(c.id);
        if (!roles) continue;
        for (const value2 of p.store.domains.get(key2) ?? []) {
          const identity = baseIdentity(value2);
          const matching = [...roles.get(identity) ?? []];
          if (identity === "怪杰") matching.push(...roles.get("主谋") ?? []);
          if (description && identity === "不安定因子") {
            if (this.boards.school >= 2) matching.push(...roles.get("传谣人") ?? []);
            if (this.cityQualifiedAtDeath.has(c.id)) matching.push(...roles.get("关键人物") ?? []);
          }
          if (description && value2 === "平民" && p.x.includes("妄想扩大病毒")) {
            const old = this.endEntry?.characters.get(c.id);
            if (!old || old.counters.paranoia + old.counters.despair >= 3)
              matching.push(...roles.get("杀人狂") ?? []);
          }
          if (matching.length) {
            relevantCharacters.add(c.id);
            for (const source of matching)
              add2(
                source,
                "character",
                source.detached && !directDeathEffect(source) ? `${c.character}（${c.id}）可能先前发动的 ${identity} 效果` : `${c.character}（${c.id}）是${identity}${description && source.ability ? "（" + source.ability.id + "）" : ""}`,
                c.id,
                source.detached && !directDeathEffect(source) ? [] : [{ key: key2, value: value2 }]
              );
          }
        }
      }
      for (const [name, sources] of indexed.events) {
        const eventDays = sources.some((s) => s.detached) ? [...p.store.domains.keys()].filter((k) => k.startsWith("event:")).map((k) => Number(k.slice(6))) : [o.day];
        for (const eventDay of eventDays) {
          const key2 = "event:" + eventDay;
          if (!p.store.domains.get(key2)?.has(name)) continue;
          for (const source of sources)
            if ((source.detached || !this.pairWindow?.completedFrame) && (!description || source.detached || Number(key2.slice(6)) === o.day && !this.pairWindow?.completedFrame && this.occurrence.get(o.loop + ":" + o.day) !== false) && (eligible(source, void 0, eventDay) || virtualVictim && !source.detached && eligible(source, change.target, eventDay))) {
              const day = key2.slice(6);
              const culpritKey = "culprit:" + day;
              const actors = p.store.domains.get(culpritKey) ?? /* @__PURE__ */ new Set(["未公开"]);
              const independent = !description || source.detached || source.independentOfCulprit && !virtualVictim;
              let culpritOptions = [void 0];
              if (!actors.size) continue;
              if (!independent || cats.some((c) => actors.has(c.id))) {
                const effective2 = [...actors].filter(
                  (id) => !cats.some((c) => c.id === id) && (independent || this.roster.find((c) => c.id === id)?.character === "临时工" || eligible(source, id, eventDay))
                );
                if (!effective2.length) continue;
                culpritOptions = effective2;
              }
              relevantEvents.add(day + ":" + name);
              if (o.phase === "incident" && independent && !source.detached && source.reports === 1 && change.kind === "counter" && source.target === change.target && source.amount) {
                fixedReport = JSON.stringify([
                  p.id,
                  o.loop,
                  o.day,
                  name,
                  change.target,
                  change.counter,
                  change.sign
                ]);
                fixedAlternatives += culpritOptions.length;
              }
              for (const id of culpritOptions) {
                add2(
                  source,
                  "event",
                  `第 ${day} 日真实事件为${name}，${source.delay ? "且有本日到期的相关效果" : "其结算可能导致本次变化"}` + (id ? `（当事人 ${id}）` : ""),
                  "event:" + key2,
                  [{ key: key2, value: name }, ...id ? [{ key: culpritKey, value: id }] : []]
                );
                const cause = alternatives.at(-1);
                if (source.deathGuard && !source.detached) guardCauses.add(cause);
                if (!source.detached && eventDay === o.day && this.catalog.pairPrograms.has(name))
                  pairCauses.set(cause, name);
                if (source.selection && !this.roster.some(
                  (c) => (traits(c.character).execution === "repeat" || traits(c.character).execution === "proxy") && (id ? c.id === id : actors.has(c.id))
                )) {
                  cause.choices = bindChoices2(source, change, [
                    "event-choice",
                    o.loop,
                    eventDay,
                    name
                  ]);
                  cause.notes.push(
                    "本次事件的 " + source.selection.key + " 选择 " + change.target + (source.selection.different.length ? "，须与 " + source.selection.different.join("、") + " 不同。" : "。")
                  );
                } else if (source.selection) unboundRepeat = true;
              }
            }
        }
      }
      if (description) {
        for (const cause of intrinsicCauses(
          this.pack,
          o,
          change,
          p,
          this.characters.get(change.target),
          this.characters,
          this.deathsInWindow,
          this.priorFriends,
          cats
        )) {
          alternatives.push(cause);
          if (cause.rule) relevantRules.add(cause.rule);
          if (cause.owner) relevantCharacters.add(cause.owner);
        }
      }
      const direct = declared ? alternatives.filter(
        (a) => a.category === "character" && a.owner === declared.id && a.ability === declared.ability
      ) : [];
      let unique = [
        ...new Map(
          (direct.length ? direct : alternatives).map((a) => [JSON.stringify(a), a])
        ).values()
      ];
      const window = this.pairWindow;
      const pairName = unique.length ? pairCauses.get(unique[0]) : void 0;
      if (pairName && unique.every((a) => pairCauses.get(a) === pairName) && !batch && window && o.phase === "incident" && window.loop === o.loop && window.day === o.day) {
        let tracker = this.pairStates.get(p);
        const key2 = "culprit:" + o.day;
        const ids = [...p.store.values(key2)];
        if (!tracker && window.reports === 0) {
          tracker = this.startPair(pairName, ids);
          this.pairStates.set(p, tracker);
        }
        if (tracker?.name === pairName && tracker.reports === window.reports) {
          checkedExclusion = true;
          tracker.reports++;
          const valid = this.pairCulprits(tracker, ids, scope, o.sequence, change);
          if (!tracker.ordinaryOnly) for (const id of ids) relevantCharacters.add(id);
          if (tracker.ordinaryOnly && valid.length === ids.length && p.store.values("event:" + o.day).size === 1)
            boardOnly.add(p);
          unique = unique.flatMap((a) => {
            a.notes.push("一次结算的两名目标必须不同，教主再次结算时重新选择。");
            if (tracker.executions.has("parallel"))
              a.notes.push("临时工与替身分别选目标，同一步的指示物变化合并结算。");
            if (valid.length === ids.length) return [a];
            return valid.filter((id) => a.requires.every((g) => g.key !== key2 || g.value === id)).map((id) => ({
              ...a,
              requires: [...a.requires.filter((g) => g.key !== key2), { key: key2, value: id }],
              label: a.label + "，当事人为 " + id
            }));
          });
        } else scope.needsHistory = true;
      } else if (unboundRepeat || pairCauses.size) scope.needsHistory = true;
      if (guardCauses.size && o.phase === "incident" && !["临时工", "临时工？"].includes(this.characters.get(change.target)?.character ?? "")) {
        const key2 = "identity:" + change.target;
        const domain = p.store.domains.get(key2);
        if (domain && [...domain].some((v) => this.pack.identities[shownIdentity(v)]?.immortal)) {
          const mortal = [...domain].filter(
            (v) => !this.pack.identities[shownIdentity(v)]?.immortal
          );
          checkedExclusion = true;
          unique = unique.flatMap(
            (a) => guardCauses.has(a) ? mortal.map((value2) => ({
              ...a,
              requires: [...a.requires, { key: key2, value: value2 }],
              label: a.label + "，守护实际消耗，" + change.target + " 的身份为" + shownIdentity(value2)
            })) : [a]
          );
        }
      }
      if (change.before !== void 0 && change.after !== void 0) {
        const joint = counterCauses(
          unique,
          Math.abs(change.after - change.before),
          void 0,
          this.counterWork
        );
        if (joint) unique = joint;
        else {
          scope.needsHistory = true;
          scope.conservative.push("合并指示物来源达到局部预算，保留未区分的解释。");
        }
      }
      if (fixedReport && fixedAlternatives === alternatives.length && p.store.values("event:" + o.day).size === 1) {
        const priorReports = this.fixedIncidentReports.get(fixedReport) ?? 0;
        if (priorReports > 0) {
          if (priorReports >= 2) scope.needsHistory = true;
          const culpritKey = "culprit:" + o.day;
          const repeaters = this.roster.filter(
            (c) => (traits(c.character).execution === "repeat" || traits(c.character).execution === "proxy") && p.store.values(culpritKey).has(c.id)
          );
          const repeated = unique.flatMap(
            (a) => repeaters.filter((c) => a.requires.every((g) => g.key !== culpritKey || g.value === c.id)).map((c) => ({
              ...a,
              label: a.label + "，由" + c.character + "（" + c.id + "）重复结算",
              requires: [
                ...a.requires.filter((g) => g.key !== culpritKey),
                { key: culpritKey, value: c.id }
              ]
            }))
          );
          unique.splice(0, unique.length, ...repeated);
        }
        this.fixedIncidentReports.set(fixedReport, priorReports + 1);
      }
      for (const a of unique) {
        scope.conservative.push(...a.notes);
        labels.add(a.label);
      }
      clauses.set(p, unique);
    }
    if (description && !labels.size && !checkedExclusion) return;
    const allBoardOnly = !scope.needsHistory && clauses.size > 0 && [...clauses].every(
      ([p, alternatives]) => boardOnly.has(p) || this.pairWindow?.day === o.day && this.pairWindow.loop === o.loop && o.phase === "incident" && alternatives.length === 1 && alternatives.every(
        (a) => a.category === "event" && !a.notes.length && !a.resources.length && !a.choices?.length && a.requires.length === 1 && a.requires[0]?.key === "event:" + o.day && p.store.values(a.requires[0].key).size === 1 && p.store.values(a.requires[0].key).has(a.requires[0].value)
      )
    );
    if (!allBoardOnly) {
      this.relationFacts.set(key, {
        observation: o.sequence,
        loop: o.loop,
        day: o.day,
        phase: o.phase,
        target: board2,
        description
      });
      this.version++;
      for (const [p, alternatives] of clauses) {
        const record = {
          key: typeof key === "string" ? key : void 0,
          observation: o.sequence,
          phase: o.phase,
          alternatives
        };
        if (batch) {
          const records = batch.records.get(p) ?? [];
          records.push(record);
          batch.records.set(p, records);
        } else this.network(p).add(p, record);
      }
    }
    const project = () => {
      const surviving = [...clauses].filter(([p]) => p.active).flatMap(([p, causes]) => causes.filter((c) => !this.networks.get(p.id)?.excludedCauses.has(c) && c.requires.every((g) => p.store.values(g.key).has(g.value))));
      if (!scope.needsHistory && !batch && surviving.length) {
        for (const guard of surviving[0].requires) {
          if (guard.key.startsWith("identity:") && surviving.every((c) => c.requires.some(
            (g) => g.key === guard.key && g.value === guard.value
          ))) {
            this.impliedIdentities[guard.key.slice(9)] = { identity: shownIdentity(guard.value), observation: o.sequence };
          }
        }
        if (o.phase === "mastermind-abilities" && change.kind === "counter" && change.counter === "paranoia" && change.after === (change.before ?? NaN) + 1 && surviving.every((c) => c.ability === "gossip" && c.requires.length === 1))
          scope.locallyExplained = true;
      }
      scope.alternatives = [...new Set(surviving.map((cause) => cause.label))];
      if (declared && scope.alternatives.length === 1) {
        relevantCharacters.clear();
        relevantCharacters.add(declared.id);
        relevantRules.clear();
        relevantEvents.clear();
      }
      scope.characters = [...relevantCharacters];
      scope.rules = [...relevantRules];
      scope.events = [...relevantEvents];
      scope.skippedCharacters = this.roster.filter((c) => !relevantCharacters.has(c.id)).map((c) => c.id);
      scope.skippedRules = [...allRules].filter((r) => !relevantRules.has(r));
      scope.skippedEvents = [
        ...new Set(
          profiles.flatMap(
            (p) => [...p.store.domains].filter(([key2]) => key2.startsWith("event:")).flatMap(([key2, values]) => [...values].map((n) => `${key2.slice(6)}:${n}`))
          )
        )
      ].filter((e) => !relevantEvents.has(e));
      scope.conservative = [...new Set(scope.conservative)];
    };
    if (batch) batch.projections.push(project);
    else project();
    return scope;
  }
  quietIncident(o, profiles, survivors) {
    const w = this.pairWindow;
    if (!w || !survivors && (w.hasReport || o.phase !== "incident" || o.day !== o.data.day) || w.loop !== o.loop || w.day !== o.day || !["FS", "BTX"].includes(this.pack.module))
      return;
    const scope = this.summary(o, "visible-effect");
    scope.alternatives = [];
    const ek = "event:" + o.day, ck = "culprit:" + o.day;
    const names = new Set(
      profiles.filter((p) => p.active).flatMap((p) => [...p.store.domains.get(ek) ?? []])
    );
    if (!survivors && names.size && [...names].every((name) => {
      const d = this.pack.incidents[name];
      return d && !d.afterIncidentSteps?.length && quietTargets(d.steps, {
        clock: o,
        pack: this.pack,
        characters: this.characters,
        boards: this.boards,
        days: this.days,
        loops: this.loops
      })?.some((v) => !v.length);
    })) {
      scope.events = [...names].map((name) => o.day + ":" + name);
      scope.skippedCharacters = this.roster.map((c) => c.id);
      scope.skippedRules = [...new Set(profiles.flatMap((p) => [p.y, ...p.x]))];
      w.settledQuietly = true;
      return scope;
    }
    const rows = /* @__PURE__ */ new Map();
    let informative = false;
    const alive2 = [...this.characters.values()].filter((c) => c.status === "alive");
    const cache = /* @__PURE__ */ new Map();
    for (const p of profiles) {
      if (!p.active) continue;
      const events = p.store.domains.get(ek), ids = p.store.domains.get(ck);
      if (!events?.size || !ids?.size) return;
      const causes = [];
      for (const name of events)
        for (const id of ids) {
          const actor = this.characters.get(id);
          const incident = this.pack.incidents[name];
          const guards = [
            { key: ek, value: name },
            { key: ck, value: id }
          ];
          const add2 = (label, extra = []) => causes.push({
            category: "event",
            label: name + "（当事人 " + id + "）：" + label,
            requires: [...guards, ...extra],
            resources: [],
            notes: []
          });
          scope.events.push(o.day + ":" + name);
          let free = false;
          const unknown2 = () => {
            scope.needsHistory = true;
            free = true;
            add2("保留未核验的结算解释");
          };
          if (traits(actor?.character).execution === "cancel" && !incident?.afterIncidentSteps?.length) {
            free = true;
            add2("黑猫当事人取消事件效果");
          } else if (!actor || ["临时工", "临时工？"].includes(actor.character) || this.pack.characters[actor.character]?.incidentAreaFromBase || !incident || incident.afterIncidentSteps?.length)
            unknown2();
          else {
            const key = JSON.stringify([name, id]);
            if (!cache.has(key)) {
              const pair = this.catalog.pairPrograms.get(name);
              if (survivors) cache.set(key, [survivors]);
              else if (pair) {
                const execution = new PairExecution(pair, "ordinary");
                cache.set(key, execution.advance(this.characters) ? [[]] : []);
              } else
                cache.set(
                  key,
                  quietTargets(incident.steps, {
                    clock: o,
                    pack: this.pack,
                    owner: id,
                    characters: this.characters,
                    boards: this.boards,
                    days: this.days,
                    loops: this.loops,
                    virtualArea: this.hasIncidentAreaIdentity
                  })
                );
            }
            const alternatives = cache.get(key);
            if (!alternatives) unknown2();
            else
              for (const targets of alternatives) {
                if (!targets.length) {
                  free = true;
                  add2("公开盘面允许无变化");
                  break;
                }
                const required = [];
                let supported = true, unsupported = false;
                for (const target of new Set(targets)) {
                  const c = this.characters.get(target);
                  const domain = p.store.domains.get("identity:" + target);
                  if (!domain || ["临时工", "临时工？"].includes(c.character) || c.counters.guard === 0 && alive2.some(
                    (a) => a.id !== target && a.area === c.area && this.pack.characters[a.character]?.protects
                  )) {
                    unsupported = true;
                    break;
                  }
                  const immortal2 = [...domain].filter(
                    (v) => this.pack.identities[shownIdentity(v)]?.immortal
                  );
                  if (!immortal2.length) {
                    supported = false;
                    break;
                  }
                  if (immortal2.length === domain.size) continue;
                  if (immortal2.length !== 1) {
                    unsupported = true;
                    break;
                  }
                  required.push({ key: "identity:" + target, value: immortal2[0] });
                }
                if (unsupported) {
                  unknown2();
                  break;
                }
                if (supported) {
                  if (!required.length) free = true;
                  add2(targets.join("、") + " 的死亡请求被不死身份阻止", required);
                  if (free) break;
                }
              }
          }
          if (!free) informative = true;
        }
      rows.set(p, causes);
    }
    scope.events = [...new Set(scope.events)];
    if (informative) {
      this.version++;
      this.relationFacts.set(o.sequence, {
        observation: o.sequence,
        loop: o.loop,
        day: o.day,
        phase: o.phase,
        target: "事件",
        description: survivors ? "事件阶段结束，部分应受死亡请求的角色未发生死亡或守护变化" : "事件已发生，结算无现象"
      });
      for (const [p, alternatives] of rows) {
        this.network(p).add(p, {
          observation: o.sequence,
          phase: o.phase,
          alternatives
        });
        if (!p.active) continue;
        const viable = alternatives.filter(
          (a) => !this.network(p).excludedCauses.has(a) && a.requires.every((g) => p.store.values(g.key).has(g.value))
        );
        scope.characters.push(
          ...viable.flatMap(
            (a) => a.requires.filter((g) => g.key === ck || g.key.startsWith("identity:")).map((g) => g.key === ck ? g.value : g.key.slice(9))
          )
        );
        scope.alternatives.push(...viable.map((a) => a.label));
      }
      scope.characters = [...new Set(scope.characters)];
      scope.alternatives = [...new Set(scope.alternatives)];
    }
    scope.skippedCharacters = this.roster.filter((c) => !scope.characters.includes(c.id)).map((c) => c.id);
    scope.skippedRules = [...new Set(profiles.flatMap((p) => [p.y, ...p.x]))];
    if (!scope.needsHistory && !survivors) w.settledQuietly = true;
    return scope;
  }
  incident(o, profiles) {
    const day = o.data.day;
    if (o.phase !== "incident" || typeof day !== "number" || typeof o.data.occurred !== "boolean")
      return;
    if (!this.catalog.publicTriggerModel) return;
    if (profiles.some((p) => p.y === "士的宁毒液" || p.x.includes("灭亡讴歌"))) return;
    const scope = this.summary(o, "incident-occurrence");
    this.version++;
    const eventKey = `event:${day}`, culpritKey = `culprit:${day}`;
    const roster = this.roster;
    const passing = /* @__PURE__ */ new Map();
    for (const p of profiles) {
      if (!p.store.domains.has(eventKey) || !p.store.domains.has(culpritKey)) continue;
      scope.events.push(...[...p.store.values(eventKey)].map((n) => `${day}:${n}`));
      scope.characters.push(...p.store.values(culpritKey));
      const allowed = /* @__PURE__ */ new Set();
      const pairs = [...p.store.values(eventKey)].flatMap(
        (name) => [...p.store.values(culpritKey)].filter((id) => {
          let candidates = passing.get(name);
          if (!candidates) passing.set(name, candidates = /* @__PURE__ */ new Map());
          if (!candidates.has(id))
            candidates.set(
              id,
              this.catalog.permitsOccurrence(
                name,
                this.characters.get(id),
                o.data.occurred === true
              )
            );
          if (!candidates.get(id)) return false;
          allowed.add(JSON.stringify([name, id]));
          return true;
        }).map((id) => ({
          name,
          id,
          pending: [],
          label: `真实事件为${name} 且 当事人为${roster.find((c) => c.id === id)?.character ?? id}（${id}）`
        }))
      );
      if (o.data.occurred)
        for (const pair of pairs) {
          if (traits(roster.find((c) => c.id === pair.id)?.character).execution === "cancel")
            continue;
          for (const source of this.catalog.events.get(pair.name) ?? []) {
            if (!source.delay?.day) continue;
            const origin = { ...this.context(o, source), staticOnly: true };
            const dueLoop = source.delay.loop === void 0 ? o.loop : publicNumber(source.delay.loop, origin);
            const dueDay = publicNumber(source.delay.day, origin);
            pair.pending.push(
              `若真实事件为${pair.name}且当事人为${pair.id}并成功安排，区域效果于第 ${dueLoop ?? "？"} 轮第 ${dueDay ?? "？"} 日 ${source.timing} 到期。`
            );
          }
        }
      this.incidentPairs.set(p.id + ":" + o.sequence, { day, pairs });
      const entries2 = this.eventRelations.get(p.id) ?? [];
      entries2.push({
        id: `incident:${o.sequence}`,
        observation: o.sequence,
        fact: `第 ${o.loop} 轮第 ${day} 日事件${o.data.occurred ? "发生" : "未发生"}：真实事件与当事人必须成对相容。`,
        implications: [],
        cases: [
          {
            when: [[p.y, ...p.x].join(" ＋ ")],
            alternatives: [],
            limits: [],
            notes: ["未知的特殊触发或禁止条件保留，不将无现象视为未发生。"]
          }
        ]
      });
      this.eventRelations.set(p.id, entries2);
      p.store.add(
        relation(
          `incident-trigger:${o.sequence}`,
          eventKey,
          culpritKey,
          (name, id) => allowed.has(JSON.stringify([name, id]))
        )
      );
      p.active = p.store.propagate();
    }
    scope.characters = [...new Set(scope.characters)];
    scope.events = [...new Set(scope.events)];
    scope.skippedCharacters = roster.filter((c) => !scope.characters.includes(c.id)).map((c) => c.id);
    scope.skippedRules = [...new Set(profiles.flatMap((p) => [p.y, ...p.x]))];
    scope.conservative = [
      "仅约束当事人与真实事件；黑猫无效果不等于事件未发生，教主重复效果另行核验，手下可能受禁止事件效果影响。"
    ];
    return scope;
  }
  mandatoryWindow(o, profiles) {
    if (o.type === "boundary" && o.phase === "discussion") {
      this.priorFriends = new Set(
        [...this.characters.values()].filter((c) => o.loop > 1 && c.counters.goodwill + c.counters.hope > 0).map((c) => c.id)
      );
    }
    if (o.type === "boundary" && o.phase === "loop-start") {
      const alive2 = [...this.characters.values()].filter((c) => c.status === "alive");
      this.window = {
        loop: o.loop,
        next: o.sequence + 1,
        missing: new Set(alive2.filter((c) => this.priorFriends.has(c.id)).map((c) => c.id)),
        cats: new Set(alive2.filter((c) => c.character === "黑猫").map((c) => c.id))
      };
      return;
    }
    const w = this.window;
    if (!w) return;
    if (o.loop !== w.loop || o.sequence !== w.next++) {
      this.window = void 0;
      return;
    }
    if (o.phase === "loop-start") {
      const id = String(o.data.character);
      if (o.type === "character") {
        const old = this.characters.get(id);
        const next = o.data.counters;
        if (!old || o.data.status !== "alive" || next?.paranoia === void 0 || next.paranoia > old.counters.paranoia)
          w.missing.delete(id);
        if (o.data.status !== "alive") w.cats.delete(id);
      }
      if (o.type === "board" && o.data.board === "shrine" && typeof o.data.intrigue === "number" && o.data.intrigue > this.boards.shrine)
        w.cats.clear();
      return;
    }
    this.window = void 0;
    if (o.type !== "boundary" || o.phase !== "day-start") return;
    const conflict = w.missing.size > 0 && profiles.some((p) => p.x.includes("因果线"));
    if (!w.cats.size && !conflict) return;
    const scope = this.summary(o, "mandatory-absence");
    scope.characters = [.../* @__PURE__ */ new Set([...w.cats, ...conflict ? w.missing : []])];
    scope.rules = conflict ? ["因果线"] : [];
    scope.skippedRules = [...new Set(profiles.flatMap((p) => [p.y, ...p.x]))].filter(
      (r) => !scope.rules.includes(r)
    );
    scope.skippedCharacters = this.roster.filter((c) => !scope.characters.includes(c.id)).map((c) => c.id);
    scope.skippedEvents = [
      ...new Set(
        profiles.flatMap(
          (p) => [...p.store.domains].filter(([k]) => k.startsWith("event:")).flatMap(([k, vs]) => [...vs].map((v) => k.slice(6) + ":" + v))
        )
      )
    ];
    const missing = w.cats.size ? "黑猫存活，但神社未出现强制密谋增加" : "上一轮有友好或希望的存活角色未出现因果线强制的不安增加";
    this.publicRelations.push({
      id: "absence:" + o.sequence,
      fact: missing,
      observation: o.sequence,
      implications: [w.cats.size ? "本观察序列与轮回开始效果矛盾。" : "排除含因果线的规则组合。"],
      cases: [
        {
          when: ["第 " + o.loop + " 轮轮回开始窗口已关闭"],
          alternatives: [],
          limits: [],
          notes: ["涉及角色 " + scope.characters.join("、")]
        }
      ]
    });
    for (const p of profiles) if (w.cats.size || p.x.includes("因果线")) p.active = false;
    this.version++;
    return scope;
  }
  publicUpdate(o) {
    const d = o.data;
    switch (o.type) {
      case "boundary": {
        const previous = this.lastBoundary;
        if (previous?.phase === "day-end" || previous?.phase === "loop-end") return false;
        if (previous?.phase === "incident" && this.scheduledDays.has(previous.day) && !this.occurrence.has(previous.loop + ":" + previous.day))
          return false;
        return true;
      }
      case "own-choice": {
        const choice2 = d.choice;
        return !!choice2 && typeof choice2 === "object" && "kind" in choice2 && (["cards", "continue", "pass"].includes(String(choice2.kind)) || choice2.kind === "ability" && "owner" in choice2 && "ability" in choice2 && this.roster.some(
          (c) => c.id === choice2.owner && this.pack.characters[c.character]?.abilities.some((a) => a.id === choice2.ability)
        ));
      }
      case "cards":
        return Array.isArray(d.placements);
      case "no-effect":
        return false;
      // Classified with event and identity domains in consume().
      case "declaration":
        return typeof d.ability === "string" && this.roster.some(
          (c) => c.id === d.character && this.pack.characters[c.character]?.abilities.some((a) => a.id === d.ability)
        );
      case "rule":
        return typeof d.rule === "string";
      case "culprit":
        return this.roster.some((c) => c.id === d.culprit) && typeof d.day === "number" && this.scheduledDays.has(d.day);
      case "identity":
        return typeof d.identity === "string" && this.roster.some(
          (c) => c.id === d.character && !["临时工", "临时工？"].includes(c.character)
        );
      case "board":
        if (o.phase === "loop-start" && this.window?.loop === o.loop && this.window.cats.size && d.board === "shrine" && d.intrigue === this.boards.shrine + 1)
          return true;
        return false;
      default:
        return false;
    }
  }
  // A quiet closed window can rule out a mandatory kill. Read the entry
  // snapshot: two simultaneous killers can both die before either report is read.
  closedDayEnd(o, profiles) {
    const entry = this.endEntry, prev = this.lastBoundary;
    if (o.type !== "boundary" || !entry || !this.quietDayEnd || prev?.phase !== "day-end") return;
    const actors = [...entry.characters.values()].filter((c) => c.status === "alive");
    if (actors.some(
      (c) => ["临时工", "临时工？"].includes(c.character) || this.pack.characters[c.character]?.protects || hasVirtualArea(this.pack, c.character)
    ))
      return;
    const ordinary2 = prev.loop === o.loop && (prev.day === this.days ? o.phase === "loop-end" && prev.day === o.day : o.phase === "day-start" && o.day === prev.day + 1);
    const outstanding = this.catalog.otherDayEndObligations;
    let unknown2 = this.catalog.scheduledDayEnd || !ordinary2 || actors.some((c) => c.counters.guard > 0);
    const scopes = /* @__PURE__ */ new Set(), cases = [];
    for (const { identity, ability: a, step, selector } of this.catalog.dayEndKills) {
      for (const owner of actors) {
        const ctx = {
          clock: prev,
          days: this.days,
          loops: this.loops,
          pack: this.pack,
          ...entry,
          owner: owner.id
        };
        const enabled = publicCondition(a.condition, ctx), stepEnabled = publicCondition(step.condition, ctx);
        if (enabled === void 0 || stepEnabled === void 0) unknown2 = true;
        if (enabled !== true || stepEnabled !== true) continue;
        for (const target of actors) {
          const selected = publicCondition(selector.where, {
            ...ctx,
            bindings: { it: target.id }
          });
          if (selected === void 0 || target.id === owner.id && selected === true)
            unknown2 = true;
          if (target.id === owner.id || target.counters.guard || selected !== true) continue;
          for (const p of profiles) {
            const from = "identity:" + owner.id, to = "identity:" + target.id;
            const uses = (v) => shownIdentity(v) === identity || identity === "杀人狂" && v === "平民" && p.x.includes("妄想扩大病毒") && owner.counters.paranoia + owner.counters.despair >= 3;
            const domain = p.store.domains.get(from);
            if (!p.active || !domain || ![...domain].some(uses) || !p.store.domains.has(to))
              continue;
            p.store.add(
              relation(
                "missing-kill:" + o.sequence + ":" + owner.id + ":" + target.id + ":" + a.id,
                from,
                to,
                (v, t) => !uses(v) || !!this.pack.identities[shownIdentity(t)]?.immortal
              )
            );
            p.active = p.store.propagate();
            scopes.add(owner.id);
            scopes.add(target.id);
            const statement = owner.character + "（" + owner.id + "）若以" + identity + "结算，则" + target.character + "（" + target.id + "）必须具有不死身份";
            cases.push({
              when: [[p.y, ...p.x].join(" ＋ ")],
              alternatives: [statement],
              limits: [],
              notes: []
            });
          }
        }
      }
    }
    if (!cases.length && (unknown2 || outstanding)) return;
    const scope = this.summary(o, "mandatory-absence");
    scope.characters = [...scopes];
    scope.skippedCharacters = this.roster.map((c) => c.id).filter((id) => !scopes.has(id));
    scope.alternatives = [...new Set(cases.flatMap((c) => c.alternatives))];
    scope.needsHistory = unknown2 || outstanding > 0;
    if (!cases.length) return scope;
    this.publicRelations.push({
      id: "missing-kill:" + o.sequence,
      observation: o.sequence,
      fact: "日末窗口已关闭，盘面没有发生强制死亡或守护变化。",
      implications: [],
      cases
    });
    this.version++;
    return scope;
  }
  bypass(o, profiles, key, id) {
    const actor = this.characters.get(id), area = actor?.area ?? id;
    const changed = o.type === "board" ? o.data.intrigue !== this.boards[id] : actor && o.data.counters[key] !== actor.counters[key];
    if (!changed) return;
    const role2 = key === "goodwill" ? "时间旅者" : "邪教徒";
    const owners = key === "goodwill" ? [id] : [...this.characters.values()].filter(
      (c) => c.status === "alive" && (c.area === area || c.character === "UP主" || this.pack.characters[c.character]?.abilityArea?.publicMarker === "territory" && (!this.opening.territory || this.opening.territory === area))
    ).map((c) => c.id);
    const before = actor?.counters[key] ?? this.boards[id];
    const after = o.type === "board" ? Number(o.data.intrigue) : o.data.counters[key];
    const change = {
      kind: "counter",
      target: id,
      counter: key,
      sign: Math.sign(after - before)
    };
    if (this.roster.some((c) => ["临时工", "临时工？"].includes(c.character)) || Object.values(this.catalog.forChange(o.phase, change)).some(
      (table) => [...table.values()].some((sources) => sources.some((s) => this.eligible(s, o, change)))
    ))
      return;
    const causes = /* @__PURE__ */ new Set();
    for (const p of profiles) {
      if (!p.active) continue;
      const alternatives = owners.filter((owner) => p.store.domains.get("identity:" + owner)?.has(role2)).map((owner) => ({
        category: "character",
        label: this.roster.find((c) => c.id === owner)?.character + "（" + owner + "）是" + role2,
        requires: [{ key: "identity:" + owner, value: role2 }],
        resources: [],
        notes: []
      }));
      alternatives.forEach((a) => causes.add(a.label));
      this.network(p).add(p, {
        observation: o.sequence,
        phase: o.phase,
        alternatives
      });
    }
    this.version++;
    this.relationFacts.set(o.sequence, {
      observation: o.sequence,
      loop: o.loop,
      day: o.day,
      phase: o.phase,
      target: id,
      description: "禁止牌生效窗口仍发生" + (key === "goodwill" ? "友好" : "密谋") + "变化"
    });
    const scope = this.summary(o, "visible-effect");
    scope.target = id;
    scope.characters = owners;
    scope.alternatives = [...causes];
    scope.skippedCharacters = this.roster.map((c) => c.id).filter((c) => !owners.includes(c));
    return scope;
  }
  arrival(o, profiles) {
    if (o.type !== "character" || o.phase !== "day-start" || o.data.status !== "alive" || this.lastBoundary?.phase !== "day-start" || this.lastBoundary.loop !== o.loop || this.lastBoundary.day !== o.day)
      return;
    const id = String(o.data.character), old = this.characters.get(id), entry = this.roster.find((c) => c.id === id);
    if (entry?.character !== "转校生" || old && old.status !== "absent" || !o.data.counters || typeof o.data.counters !== "object" || !COUNTERS.every(
      (k) => o.data.counters[k] === (old?.counters[k] ?? 0)
    ))
      return;
    if (old ? old.area !== o.data.area : !this.pack.characters[entry.character]?.initial.some((a) => a === o.data.area))
      return;
    for (const p of profiles) {
      const day = "enterDay:" + id, area = "area:" + id;
      if (p.store.domains.has(day)) p.store.narrow(day, [String(o.day)]);
      if (p.store.domains.has(area)) p.store.narrow(area, [String(o.data.area)]);
      p.active = p.store.propagate();
    }
    return this.publicFact(
      o,
      "转校生登场",
      ["登场日为第 " + o.day + " 日，初始区域为 " + o.data.area],
      "arrival",
      id
    );
  }
  reset(o, profiles) {
    if (o.phase !== "discussion" || this.lastBoundary?.phase !== "discussion" || this.lastBoundary.loop !== o.loop || o.day !== 1 || o.type !== "board" && o.type !== "character")
      return;
    const id = String(o.data.board ?? o.data.character), key = o.type + ":" + id;
    if (this.resetTargets.has(key)) return;
    if (o.type === "board") {
      if (!BOARDS.includes(id) || o.data.intrigue !== 0 || this.boards[id] === 0)
        return;
    } else {
      const actor = this.roster.find((c) => c.id === id);
      if (!actor || !o.data.counters || typeof o.data.counters !== "object" || !COUNTERS.every((k) => o.data.counters[k] === 0))
        return;
      const area = this.initialAreas.get(id);
      if (area ? area !== o.data.area : !this.pack.characters[actor.character]?.initial.some((a) => a === o.data.area))
        return;
      if (actor.character === "神灵") {
        if (!["absent", "alive"].includes(String(o.data.status))) return;
      } else if (o.data.status !== (["转校生", "临时工？"].includes(actor.character) ? "absent" : "alive"))
        return;
      for (const p of profiles) {
        const areaKey = "area:" + id;
        if (p.store.domains.has(areaKey)) p.store.narrow(areaKey, [String(o.data.area)]);
        const date = "enterLoop:" + id;
        if (actor.character === "神灵" && p.store.domains.has(date))
          p.store.narrow(
            date,
            [...p.store.values(date)].filter(
              (v) => Number(v) <= o.loop === (o.data.status === "alive")
            )
          );
        p.active = p.store.propagate();
      }
    }
    this.resetTargets.add(key);
    return this.publicFact(
      o,
      "第 " + o.loop + " 轮 " + id + " 重置",
      ["按开局区域、登场时点及零指示物重置"],
      "loop-reset"
    );
  }
  publicFact(o, fact, alternatives, id, actor) {
    const scope = this.summary(o, "visible-effect");
    scope.target = String(o.data.character ?? o.data.board ?? "");
    scope.characters = actor ? [actor] : [];
    scope.skippedCharacters = this.roster.map((c) => c.id).filter((c) => !scope.characters.includes(c));
    scope.alternatives = alternatives;
    this.publicRelations.push({
      id: id + ":" + o.sequence,
      observation: o.sequence,
      fact,
      implications: [],
      cases: [{ when: [], alternatives, limits: [], notes: [] }]
    });
    this.version++;
    return scope;
  }
  refusal(o, profiles) {
    const actor = this.characters.get(String(o.data.character));
    if (!actor || ["临时工", "临时工？"].includes(actor.character) || !this.pack.characters[actor.character]?.abilities.some((a) => a.id === o.data.ability))
      return;
    const key = "identity:" + actor.id;
    for (const p of profiles) {
      const domain = p.store.domains.get(key);
      if (!domain) continue;
      p.store.narrow(
        key,
        [...domain].filter((v) => {
          let identity = shownIdentity(v);
          if (identity === "平民" && p.x.includes("妄想扩大病毒") && actor.counters.paranoia + actor.counters.despair >= 3)
            identity = "杀人狂";
          return actor.counters.hope === 0 && (actor.counters.despair > 0 || !!this.pack.identities[identity]?.ignore);
        })
      );
      p.active = p.store.propagate();
    }
    return this.publicFact(
      o,
      actor.character + "拒绝友好能力",
      [actor.counters.despair ? "绝望使其拒绝" : "当前身份允许或强制拒绝"],
      "refused",
      actor.id
    );
  }
  classifyChanges(o, profiles, changes) {
    if (![
      "mastermind-abilities",
      "protagonist-abilities",
      "incident",
      "day-end",
      "loop-start",
      "loop-end",
      "day-start"
    ].includes(o.phase) || this.lastBoundary?.phase !== o.phase || this.lastBoundary.loop !== o.loop || this.lastBoundary.day !== o.day || !changes.length)
      return;
    const names = {
      move: "移动",
      kill: "死亡",
      revive: "复活",
      remove: "移除",
      counter: "指示物变化",
      failure: "主人公败北",
      "protagonist-death": "主人公死亡"
    };
    const counters = {
      paranoia: "不安",
      intrigue: "密谋",
      guard: "守护",
      goodwill: "友好",
      despair: "绝望",
      hope: "希望"
    };
    const declaration = this.declared;
    let certain;
    if (declaration && declaration.sequence === o.sequence - 1 && declaration.phase === o.phase && changes.length === 1) {
      const owner = this.characters.get(declaration.id);
      const ability = owner && this.pack.characters[owner.character]?.abilities.find((a) => a.id === declaration.ability);
      const effects = ability?.steps[0]?.effects;
      const e = effects?.length === 1 && effects[0];
      const c = changes[0];
      if (e && e.op === "counter" && e.counter === c.counter && typeof e.amount === "number" && Math.sign(e.amount) === c.sign && !ability?.steps[0]?.condition) {
        const target = e.target === "$self" ? owner?.id : e.target.startsWith("$") ? declaration.choices[e.target.slice(1)] : e.target;
        if (target === c.target && owner && this.characters.has(target) && c.counter) {
          const old = this.characters.get(target).counters[c.counter];
          const next = o.data.counters[c.counter];
          if (next !== old && next === Math.max(0, old + e.amount))
            certain = { id: owner.id, ability: ability.id };
        }
      }
    }
    const batch = changes.length > 1 ? { records: /* @__PURE__ */ new Map(), projections: [] } : void 0;
    const fields = [];
    const scopes = changes.map((change) => {
      const who = this.roster.find((c) => c.id === change.target)?.character ?? change.target;
      const label = (who === "主人公" ? "" : who + "（" + change.target + "）") + (change.counter ? counters[change.counter] + (change.sign === 1 ? "增加" : "减少") : names[change.kind] + (change.destination ? "至 " + change.destination : ""));
      fields.push(label);
      return this.visibleEffect(o, profiles, change, label, certain, batch);
    });
    if (batch) {
      for (const [p, records] of batch.records) this.network(p).addMany(p, records);
      for (const project of batch.projections) project();
    }
    const local = scopes.filter((s) => !!s);
    if (!local.length) return;
    const merged = this.summary(o, "visible-effect");
    merged.target = changes[0].target;
    if (batch)
      merged.fields = fields.map((field2, i) => ({ field: field2, alternatives: scopes[i]?.alternatives }));
    for (const k of ["characters", "rules", "events", "alternatives", "conservative"])
      merged[k] = [...new Set(local.flatMap((s) => s[k] ?? []))];
    for (const [skipped, used] of [
      ["skippedCharacters", "characters"],
      ["skippedRules", "rules"],
      ["skippedEvents", "events"]
    ])
      merged[skipped] = [...new Set(local.flatMap((s) => s[skipped]))].filter(
        (v) => !merged[used].includes(v)
      );
    if (local.length !== scopes.length || local.some((s) => s.needsHistory))
      merged.needsHistory = true;
    if (changes.length === 1 && local[0]?.locallyExplained) merged.locallyExplained = true;
    return merged;
  }
  consume(o, profiles) {
    const prior = this.declared;
    if (prior?.independent && prior.sequence + 1 === o.sequence && o.type !== "refused") {
      const actor = this.characters.get(prior.id);
      const ability = actor && this.pack.characters[actor.character]?.abilities.find((a) => a.id === prior.ability);
      if (actor && ability?.threshold !== void 0 && !ability.cannotRefuse && actor.counters.hope === 0 && !["临时工", "临时工？"].includes(actor.character)) {
        const key = "identity:" + prior.id;
        for (const p of profiles) {
          const domain = p.store.domains.get(key);
          if (!p.active || !domain) continue;
          p.store.narrow(
            key,
            [...domain].filter(
              (v) => actor.counters.despair === 0 && this.pack.identities[shownIdentity(v)]?.ignore !== "mandatory"
            )
          );
          p.active = p.store.propagate();
        }
      }
    }
    const requested = this.directRequest;
    const choice2 = o.type === "own-choice" ? o.data.choice : void 0;
    if (!(choice2 && typeof choice2 === "object" && "kind" in choice2 && choice2.kind === "select"))
      this.directRequest = void 0;
    if (o.phase === "protagonist-abilities" && choice2 && typeof choice2 === "object" && "kind" in choice2 && choice2.kind === "ability" && "owner" in choice2 && typeof choice2.owner === "string" && "ability" in choice2 && typeof choice2.ability === "string") {
      const actor = this.characters.get(choice2.owner);
      const ability = actor && this.pack.characters[actor.character]?.abilities.find((a) => a.id === choice2.ability);
      if (actor && ability?.threshold !== void 0) {
        if (actor.counters.goodwill + actor.counters.hope < ability.threshold) {
          for (const p of profiles) p.active = false;
          return this.publicFact(
            o,
            actor.character + "独立请求的有效友好低于门槛",
            [],
            "goodwill-threshold",
            actor.id
          );
        }
        this.directRequest = { id: actor.id, ability: ability.id };
      }
    }
    if (this.pairWindow && !["own-choice", "no-effect", "boundary", "incident"].includes(o.type))
      this.pairWindow.hasReport = true;
    const closed = this.closedDayEnd(o, profiles);
    let pairClosed;
    if (o.type === "boundary" && this.pairWindow) {
      const { day, loop, reports } = this.pairWindow;
      if (!this.pairWindow.settledQuietly && o.phase === "captain-change" && o.loop === loop && o.day === day) {
        const group = this.pairWindow.group;
        if (group?.changed && group.remaining.size) {
          if (group.uncertain) {
            pairClosed = this.summary(o, "mandatory-absence");
            pairClosed.needsHistory = true;
            pairClosed.conservative.push(
              "事件期间存在移动、替身或其他盘面变化，核验未结算的死亡请求。"
            );
          } else pairClosed = this.quietIncident(o, profiles, [...group.remaining]);
        }
        const used = /* @__PURE__ */ new Set();
        let needsHistory = false;
        let narrowed = false;
        for (const p of profiles) {
          const ek = "event:" + day, ck = "culprit:" + day;
          const names = p.store.domains.get(ek);
          if (!names || ![...names].some((n) => this.catalog.pairPrograms.has(n))) continue;
          let tracker = this.pairStates.get(p);
          if (!tracker && reports === 0 && names.size === 1)
            tracker = this.startPair([...names][0], [...p.store.values(ck)]);
          if (!tracker || tracker.reports !== reports || names.size !== 1 || !names.has(tracker.name)) {
            needsHistory = true;
            continue;
          }
          used.add(tracker.name);
          const result = { needsHistory: false };
          const changed = p.store.narrow(ck, [
            ...this.pairCulprits(tracker, [...p.store.values(ck)], result, o.sequence),
            ...[...p.store.values(ck)].filter(
              (id) => reports === 0 && this.characters.get(id)?.character === "黑猫"
            )
          ]);
          needsHistory ||= result.needsHistory;
          narrowed ||= changed;
          if (changed) p.active = p.store.propagate();
        }
        if (!used.size && reports === 0) needsHistory = true;
        if (used.size || needsHistory) {
          pairClosed = narrowed || needsHistory ? this.publicFact(
            o,
            "事件阶段结束，核对两步事件剩余的必选效果。",
            [...used].map((n) => n + "每次结算须完成两步，两名目标不同。"),
            "incident-close"
          ) : this.summary(o, "visible-effect");
          pairClosed.events = [...used].map((n) => day + ":" + n);
          pairClosed.needsHistory = needsHistory;
        }
      }
      if (o.phase === "captain-change" && o.loop === loop && o.day === day && this.deathsInWindow.size && ["FS", "BTX"].includes(this.pack.module)) {
        const notes = /* @__PURE__ */ new Set();
        const ordinary2 = (id) => !["临时工", "临时工？"].includes(this.characters.get(id)?.character ?? "");
        for (const p of profiles.filter((p2) => p2.active)) {
          for (const dead of this.deathsInWindow) {
            const from = "identity:" + dead;
            const domain = p.store.domains.get(from);
            if (!ordinary2(dead) || !domain) continue;
            if (p.store.narrow(
              from,
              [...domain].filter((v) => !this.catalog.failureRoles.includes(shownIdentity(v)))
            ))
              notes.add(dead + " 死亡后仍正常进入队长交换，排除死亡必定触发败北的身份。");
            if (!p.store.consistent) break;
            for (const target of this.characters.values()) {
              if (target.status !== "alive" || !ordinary2(target.id) || this.pairWindow.arrivals.has(target.id) || this.pairWindow.paranoiaRise.has(target.id))
                continue;
              const to = "identity:" + target.id, roles = p.store.domains.get(to);
              if (!roles) continue;
              const pairs = [
                ["求爱者", "心上人"],
                ["心上人", "求爱者"]
              ].filter(([a, b]) => domain.has(a) && roles.has(b));
              if (!pairs.length) continue;
              if (this.catalog.extraDeathReaction) {
                pairClosed ??= this.summary(o, "mandatory-absence");
                pairClosed.needsHistory = true;
                continue;
              }
              p.store.add(
                relation(
                  "missing-partner:" + o.sequence + ":" + dead + ":" + target.id,
                  from,
                  to,
                  (a, b) => !pairs.some(([x, y]) => a === x && b === y)
                )
              );
              notes.add(
                dead + " 死亡后 " + target.id + " 未增加不安，排除这两人的求爱者与心上人配对。"
              );
            }
          }
          p.active = p.store.propagate();
        }
        if (notes.size) {
          const end = this.publicFact(
            o,
            "事件结束时应发生的死亡联动未发生。",
            [...notes],
            "incident-death-reaction"
          );
          pairClosed ??= end;
        }
      }
      if (o.phase === "captain-change" && o.loop === loop && o.day === day) {
        if (this.catalog.completionRoles.length || this.catalog.completionCards.size) {
          const owners = /* @__PURE__ */ new Set();
          for (const p of profiles.filter((p2) => p2.active))
            for (const id of p.store.domains.get("culprit:" + day) ?? []) {
              const actor = this.roster.find((c) => c.id === id);
              if (this.catalog.completionCards.has(id) || this.catalog.completionRoles.some(
                (role2) => p.store.domains.get("identity:" + id)?.has(role2)
              ) || actor?.character === "临时工")
                owners.add(id);
            }
          if (owners.size) {
            pairClosed ??= this.summary(o, "mandatory-absence");
            pairClosed.needsHistory = true;
            pairClosed.characters = [.../* @__PURE__ */ new Set([...pairClosed.characters, ...owners])];
            pairClosed.conservative.push(
              "当事人可能有事件结算后的强制能力，保留其触发条件和后续效果并核验历史。"
            );
          }
        }
      }
      this.pairStates.clear();
      this.pairWindow = void 0;
    }
    if (o.type === "boundary") this.resetTargets.clear();
    if (o.phase === "day-end" && o.type !== "boundary" && !["own-choice", "cards"].includes(o.type))
      this.quietDayEnd = false;
    if (o.type === "boundary") {
      this.quietDayEnd = o.phase === "day-end";
      this.deathsInWindow.clear();
      this.cityQualifiedAtDeath.clear();
      this.movedInWindow.clear();
      this.endEntry = ["day-end", "loop-end"].includes(o.phase) ? { boards: { ...this.boards }, characters: new Map(this.characters) } : void 0;
    }
    if (o.type === "boundary") this.lastBoundary = { loop: o.loop, day: o.day, phase: o.phase };
    const closedCards = o.type === "boundary" || o.phase !== "card-resolution" ? this.cardReports.close(o) : void 0;
    if (o.type === "cards" && o.phase === "card-resolution") this.cardReports.collect(o);
    const card = this.cardReports.match(o);
    if (card) delete this.cardReports.targets.get(String(o.data.character ?? o.data.board))[card];
    if (o.type === "character" && this.cardReports.pendingGoodwill.has(String(o.data.character))) {
      const id = String(o.data.character);
      const old = this.characters.get(id);
      const next = o.data.counters?.goodwill;
      if (next === void 0 || next !== old.counters.goodwill || o.data.status !== "alive")
        this.cardReports.pendingGoodwill.delete(id);
    }
    let scope = this.mandatoryWindow(o, profiles) ?? closed ?? pairClosed ?? this.reset(o, profiles) ?? this.arrival(o, profiles);
    if (closedCards?.missing.length && ["FS", "BTX"].includes(this.pack.module)) {
      const excluded = [];
      for (const id of closedCards.missing) {
        const key = "identity:" + id;
        if (!profiles.some((p) => p.active && p.store.domains.get(key)?.has("时间旅者"))) continue;
        const indexed = this.catalog.forChange("card-resolution", {
          kind: "counter",
          target: id,
          counter: "goodwill",
          sign: 1
        });
        if (this.roster.some((c) => ["临时工", "临时工？"].includes(c.character)) || Object.values(indexed).some((table) => table.size)) {
          closedCards.unresolved.push(id + " 的友好禁止窗口有替身或其他结算来源");
          continue;
        }
        for (const p of profiles) {
          const domain = p.store.domains.get(key);
          if (!p.active || !domain || ![...domain].some((v) => shownIdentity(v) === "时间旅者"))
            continue;
          p.store.narrow(
            key,
            [...domain].filter((v) => shownIdentity(v) !== "时间旅者")
          );
          p.active = p.store.propagate();
          if (!excluded.includes(id)) excluded.push(id);
        }
      }
      if (excluded.length) {
        scope = this.publicFact(
          o,
          "友好禁止与友好增加牌已结算，目标未增加友好",
          excluded.map((id) => id + " 排除时间旅者"),
          "blocked-goodwill"
        );
        scope.characters = excluded;
        scope.skippedCharacters = this.roster.map((c) => c.id).filter((id) => !excluded.includes(id));
      }
    }
    if (closedCards?.unresolved.length) {
      scope ??= this.summary(o, "mandatory-absence");
      scope.needsHistory = true;
      scope.conservative.push(...closedCards.unresolved);
    }
    if (o.type === "declaration" && typeof o.data.character === "string" && typeof o.data.ability === "string") {
      this.declared = {
        independent: requested?.id === o.data.character && requested?.ability === o.data.ability && o.phase === "protagonist-abilities",
        sequence: o.sequence,
        id: o.data.character,
        ability: o.data.ability,
        phase: o.phase,
        choices: o.data.choices ?? {}
      };
    }
    if (o.type === "failure" && ["protagonist-death", "protagonist-failure"].includes(String(o.data.result)))
      scope = this.classifyChanges(o, profiles, [
        {
          kind: o.data.result === "protagonist-death" ? "protagonist-death" : "failure",
          target: "主人公"
        }
      ]);
    if (o.type === "refused") scope = this.refusal(o, profiles);
    if (card) {
      const target = String(o.data.character ?? o.data.board);
      const label = card === "move" ? "公开移动牌结算至 " + o.data.area : "公开行动牌的" + (card === "plus" ? "增加" : "减少") + "效果与全部指示物变化吻合";
      scope = this.summary(o, "visible-effect");
      scope.target = target;
      scope.alternatives = [
        this.cardReports.targets.get(target).kinds.join(" ＋ ") + " · " + label
      ];
      scope.skippedCharacters = this.roster.map((c) => c.id);
      scope.locallyExplained = true;
      if (card === "move") {
        const actor = this.characters.get(target);
        if (actor && this.pack.characters[actor.character]?.protects) {
          scope.alternatives.push(actor.character + "跟随同区保护对象移动");
          scope = this.publicFact(o, target + " 的移动结算", scope.alternatives, "cards", target);
        }
        if (actor && this.pack.characters[actor.character]?.forbidden.some((area) => area === o.data.area)) {
          scope.needsHistory = true;
          scope.conservative.push("移动进入原禁行区域，还须满足解除禁行条件。");
        }
      }
      const bypass = this.cardReports.targets.get(target).bypass;
      if (bypass && card !== "move") {
        const old = this.characters.get(target);
        const changed = o.type === "board" || old && o.data.counters[bypass] !== old.counters[bypass];
        if (changed) {
          const narrowed = this.bypass(o, profiles, bypass, target);
          if (narrowed) scope = narrowed;
          else scope.needsHistory = true;
        }
      }
    }
    if (o.type === "board" && BOARDS.includes(o.data.board) && typeof o.data.intrigue === "number") {
      const board2 = o.data.board;
      if (o.phase === "mastermind-abilities" && o.data.intrigue > this.boards[board2])
        scope = this.visibleEffect(o, profiles, {
          kind: "counter",
          target: board2,
          counter: "intrigue",
          sign: 1,
          before: this.boards[board2],
          after: o.data.intrigue
        });
      else if (!card && this.boards[board2] !== o.data.intrigue && !(o.phase === "loop-start" && board2 === "shrine" && this.roster.some((c) => c.character === "黑猫")))
        scope = this.classifyChanges(o, profiles, [
          {
            kind: "counter",
            target: board2,
            counter: "intrigue",
            sign: Math.sign(o.data.intrigue - this.boards[board2]),
            before: this.boards[board2],
            after: o.data.intrigue
          }
        ]) ?? scope;
      this.boards[board2] = o.data.intrigue;
    } else if (o.type === "no-effect") {
      scope = this.quietIncident(o, profiles) ?? scope;
      const window = this.pairWindow;
      if (window && o.phase === "incident" && window.loop === o.loop && o.day === window.day && o.data.day === o.day) {
        window.completedFrame = true;
        window.hasReport = true;
      }
    } else if (o.type === "incident") {
      if (typeof o.data.occurred === "boolean" && o.phase === "incident" && o.data.day === o.day)
        this.occurrence.set(o.loop + ":" + o.day, o.data.occurred);
      this.pairStates.clear();
      this.pairWindow = o.phase === "incident" && o.data.occurred === true && o.data.day === o.day ? {
        loop: o.loop,
        day: o.day,
        reports: 0,
        modes: /* @__PURE__ */ new Map(),
        hasReport: false,
        paranoiaRise: /* @__PURE__ */ new Set(),
        arrivals: /* @__PURE__ */ new Set()
      } : void 0;
      scope = this.incident(o, profiles);
      if (this.pairWindow && ["FS", "BTX"].includes(this.pack.module)) {
        const names = new Set(
          profiles.filter((p) => p.active).flatMap((p) => [...p.store.domains.get("event:" + o.day) ?? []])
        );
        const def = names.size === 1 && this.pack.incidents[[...names][0]];
        const targets = def && groupVictims(def.steps, {
          clock: o,
          pack: this.pack,
          characters: this.characters,
          boards: this.boards,
          days: this.days,
          loops: this.loops
        });
        if (targets && targets.length)
          this.pairWindow.group = {
            remaining: new Set(targets),
            changed: false,
            uncertain: [...this.characters.values()].some(
              (c) => c.status === "alive" && this.pack.characters[c.character]?.protects
            )
          };
      }
    } else if (o.type === "character" && typeof o.data.character === "string") {
      const old = this.characters.get(o.data.character);
      const entry = this.roster.find((c) => c.id === o.data.character);
      if (old && !card && o.data.counters && typeof o.data.counters === "object") {
        const changes = [];
        const target = old.id;
        if (old.area !== o.data.area && typeof o.data.area === "string")
          changes.push({ kind: "move", target, destination: o.data.area });
        if (old.status === "alive" && o.data.status === "dead")
          changes.push({ kind: "kill", target });
        if (old.status === "dead" && o.data.status === "alive")
          changes.push({ kind: "revive", target });
        if (old.status === "alive" && o.data.status === "removed")
          changes.push({ kind: "remove", target });
        for (const counter of COUNTERS) {
          const n = o.data.counters[counter];
          if (typeof n === "number" && n !== old.counters[counter])
            changes.push({
              kind: "counter",
              target,
              counter,
              sign: Math.sign(n - old.counters[counter]),
              before: old.counters[counter],
              after: n
            });
        }
        if (this.pairWindow && o.phase === "incident") {
          if (changes.some((c) => c.counter === "paranoia" && c.sign === 1))
            this.pairWindow.paranoiaRise.add(target);
          if (old.status !== "alive" && o.data.status === "alive")
            this.pairWindow.arrivals.add(target);
        }
        const group = this.pairWindow?.group;
        if (group && changes.length) {
          group.changed = true;
          if (changes.some((c) => c.kind === "kill" || c.counter === "guard" && c.sign === -1))
            group.remaining.delete(target);
          if (changes.some((c) => c.kind === "move" || c.kind === "revive" || c.kind === "remove"))
            group.uncertain = true;
        }
        if (old.status === o.data.status || changes.some((c) => ["kill", "revive", "remove"].includes(c.kind)))
          scope = this.classifyChanges(o, profiles, changes) ?? scope;
        if (old.status === "alive" && o.data.status === "dead") {
          this.deathsInWindow.add(target);
          if (this.boards.city >= 2) this.cityQualifiedAtDeath.add(target);
          if (!["临时工", "临时工？"].includes(old.character))
            for (const p of profiles) {
              const key = "identity:" + target, domain = p.store.domains.get(key);
              if (domain && p.active) {
                p.store.narrow(
                  key,
                  [...domain].filter((v) => !this.pack.identities[shownIdentity(v)]?.immortal)
                );
                p.active = p.store.propagate();
              }
            }
        }
      }
      if (old && old.area !== o.data.area) this.movedInWindow.add(old.id);
      if (entry && typeof o.data.area === "string" && typeof o.data.status === "string" && o.data.counters)
        this.characters.set(entry.id, {
          ...old,
          ...entry,
          area: o.data.area,
          status: o.data.status,
          counters: structuredClone(o.data.counters)
        });
    }
    if (this.pairWindow?.group && o.phase === "incident" && (o.type === "board" || o.type === "character" && !this.characters.get(String(o.data.character))))
      this.pairWindow.group.uncertain = true;
    if (this.pairWindow && o.phase === "incident" && ["character", "board", "no-effect", "failure"].includes(o.type))
      this.pairWindow.reports++;
    if (scope && pairClosed?.needsHistory) scope.needsHistory = true;
    return scope;
  }
};

// packages/engine/src/runtime/knowledge-live.ts
var hasHermit = (opening) => [...opening.characters, ...opening.roster ?? []].some((c) => c.character === "仙人");
function waitingForCharacters(revision) {
  return {
    revision,
    status: "waiting",
    domainComplete: false,
    ruleDigest: "",
    generated: 0,
    possible: 0,
    unresolved: 0,
    excluded: 0,
    expansions: 0,
    elapsedMs: 0,
    identities: {},
    rules: [],
    culprits: {},
    reasons: [],
    evidenceThrough: 0
  };
}
function unsupportedDomain(pack, opening) {
  const reasons = [];
  if (pack.module !== opening.module || pack.anniversary !== opening.anniversary || opening.loop !== 1 || opening.phase !== "discussion" || opening.day !== 1)
    reasons.push("求解需要相同规则版本的第一轮开局公开视图。");
  if (!["FS", "BTX"].includes(pack.module)) reasons.push("增量约束求解器当前支持 FS、BTX。");
  if (hasHermit(opening)) reasons.push("仙人的无界整数 X 尚需符号数值约束，不能截断为有限精确域。");
  if (Object.values(pack.plots).some((p) => !p.supported || p.pair))
    reasons.push("当前内容包含未支持的规则或双面身份约束。");
  return reasons.concat(incompleteContent(pack, opening));
}
var LiveKnowledge = class {
  constructor(pack, opening, searchBudget = 1e5) {
    this.pack = pack;
    this.opening = opening;
    this.searchBudget = searchBudget;
    this.reasons = unsupportedDomain(pack, opening);
    this.profiles = !this.reasons.length || this.reasons.length === 1 && hasHermit(opening) ? buildProfiles(pack, opening, this.stats) : [];
    const initial = this.targets();
    const columns = (prefix) => [...new Set(initial.filter((t) => t.key.startsWith(prefix)).map((t) => t.value))].sort();
    this.openingColumns = {
      identities: columns("identity:"),
      rules: columns("rule"),
      culprits: columns("culprit:"),
      days: opening.incidents.map((e) => String(e.day))
    };
    if (this.profiles.length) this.causal = new CausalScope(pack, opening);
    this.ensureQueries(initial);
  }
  profiles;
  stats = { checks: 0, removed: 0, branches: 0 };
  evidence = { observations: [], normalized: [], version: 0 };
  revision = -1;
  constraintVersion = 0;
  projectedTargets;
  records = /* @__PURE__ */ new Map();
  rejected = /* @__PURE__ */ new Set();
  queries = /* @__PURE__ */ new Map();
  verified = /* @__PURE__ */ new Set();
  revalidate = [];
  cursor = 0;
  started = performance.now();
  limited = false;
  work = 0;
  epochWork = 0;
  expansions = 0;
  generated = 0;
  initializations = 0;
  priorRoots = 0;
  priorExpansions = 0;
  historyComparisons = 0;
  deductions = [];
  causal;
  openingColumns;
  scope;
  deferred = true;
  // Exhaust all surviving *joint configurations* once a coupled window is seen.
  // Retain the iterator, rejected configurations, and every surviving replay
  // stack across append(): later evidence can only remove solutions.
  joint;
  jointUnknown = false;
  enumeratedRecords = /* @__PURE__ */ new Set();
  windowReports = 0;
  trace = [];
  windowPhase;
  publicContradiction = false;
  get historySearchDeferred() {
    return this.deferred;
  }
  transition;
  reasons;
  /** Complete logs and incremental deliveries share the same prefix validation. */
  update(history, revision) {
    if (revision < this.revision) throw Error("观察版本不能回退。");
    if (history.length < this.evidence.observations.length)
      throw Error("观察必须追加，不能改写已有历史。");
    this.append(history, 0, revision);
  }
  get observationCount() {
    return this.evidence.observations.length;
  }
  /** Empty and retried deliveries never wake inference. */
  append(observations, after, revision) {
    if (!Number.isSafeInteger(after) || after < 0 || after > this.evidence.observations.length)
      throw Error("观察追加偏移不连续。");
    const normalized = normalizeHistory(observations);
    const overlap = Math.min(this.evidence.observations.length - after, observations.length);
    for (let i = 0; i < overlap; i++)
      if (observations[i].sequence !== after + i + 1 || normalized[i] !== this.evidence.normalized[after + i])
        throw Error("观察必须追加，不能改写已有历史。");
    const fresh = [], suffix = [];
    for (let i = overlap; i < observations.length; i++) {
      const o = observations[i];
      const index = o.sequence - 1;
      const offset = index - this.evidence.normalized.length;
      if (!Number.isSafeInteger(index) || index < 0 || offset > fresh.length)
        throw Error("观察序号不连续。");
      if (offset === fresh.length) {
        fresh.push(o);
        suffix.push(normalized[i]);
      } else if ((offset < 0 ? this.evidence.normalized[index] : suffix[offset]) !== normalized[i]) {
        throw Error("同序号观察内容冲突。");
      }
    }
    if (revision < this.revision && fresh.length) throw Error("观察版本不能回退。");
    this.revision = Math.max(this.revision, revision);
    if (!fresh.length) return;
    this.priorRoots = this.initializations;
    this.priorExpansions = this.expansions;
    this.transition = {
      historyCandidates: [],
      fromVersion: this.evidence.version,
      toVersion: this.evidence.version + 1,
      firstObservation: this.evidence.observations.length + 1,
      lastObservation: this.evidence.observations.length + fresh.length
    };
    this.evidence.observations.push(...structuredClone(fresh));
    this.evidence.normalized.push(...suffix);
    this.evidence.version++;
    this.epochWork = this.work;
    this.limited = false;
    this.verified.clear();
    this.revalidate = [...this.records.values()];
    this.deferred = false;
    this.scope = void 0;
    if (!this.causal) return;
    const before = this.stats.removed, profileCount = this.profiles.length, relationVersion = this.causal.version;
    for (const [index, o] of fresh.entries()) {
      const prior = this.stats.removed, size = this.profiles.length;
      const publicUpdate = this.causal.publicUpdate(o);
      const scope = this.causal.consume(o, this.profiles);
      const wasJoint = !!this.joint;
      if (o.type === "boundary") {
        if (this.windowReports >= 2) this.startJointSearch();
        this.windowPhase = o.phase;
        this.windowReports = 0;
      } else if (o.phase === this.windowPhase && [
        "incident",
        "mastermind-abilities",
        "protagonist-abilities",
        "day-end",
        "loop-end",
        "card-resolution",
        "loop-start"
      ].includes(o.phase) && [
        "incident",
        "character",
        "board",
        "declaration",
        "failure",
        "refused",
        "identity",
        "no-effect"
      ].includes(o.type)) {
        if (!scope?.locallyExplained || scope.needsHistory) this.windowReports++;
      }
      if (scope?.needsHistory || !scope?.locallyExplained && o.phase === this.windowPhase && (o.type === "character" || o.type === "board" || o.type === "failure") && ((scope?.fields?.length ?? 0) > 1 || (scope?.alternatives?.length ?? 0) > 1))
        this.startJointSearch();
      if (scope) this.scope = scope;
      if (scope?.needsHistory || !scope && !publicUpdate) {
        this.transition.historyCandidates.push(o.sequence);
      }
      this.profiles = this.profiles.filter((p) => p.active);
      if (o.type === "identity" || o.type === "rule" || o.type === "culprit")
        this.profiles = this.profiles.filter(
          (p) => p.active = applyDisclosure(p, this.opening, o) && p.store.propagate()
        );
      if (size && !this.profiles.length) this.publicContradiction = true;
      const removed = this.stats.removed - prior + size - this.profiles.length;
      const needsHistory = !!scope?.needsHistory || !scope && !publicUpdate;
      this.trace.push({
        observation: o.sequence,
        removed,
        mode: this.joint ? "joint" : needsHistory ? "history" : "local",
        reason: !wasJoint && this.joint ? "本观察触发联合历史核验" : needsHistory ? "公开窗口仍有未建模的历史条件" : scope ? "已按公开盘面传播原因约束" : "更新公开盘面",
        ...scope?.alternatives?.length && { alternatives: scope.alternatives }
      });
      if (removed)
        this.deductions.push({
          observation: this.evidence.observations.length - fresh.length + index + 1,
          removed,
          reason: scope ? "按效果、时点与对象分类建立必要原因约束；角色区域只筛选角色来源，无关规则保留。仅在关联约束收紧时继续传播。" : "公开信息收紧对应变量，并沿声明的约束依赖传播；数量为候选取值及规则分支删除次数。"
        });
    }
    if (before !== this.stats.removed || profileCount !== this.profiles.length || relationVersion !== this.causal.version)
      this.constraintVersion++;
    if (before !== this.stats.removed || profileCount !== this.profiles.length) {
      this.projectedTargets = void 0;
      this.ensureQueries();
    }
    this.revalidate = this.revalidate.filter((record) => {
      if (!this.admissible(record.setup, record.values)) {
        this.enumeratedRecords.delete(record);
        this.records.delete(this.key(record.setup));
        return false;
      }
      const compared = record.search.compared;
      const valid = record.search.result === "possible";
      this.historyComparisons += record.search.compared - compared;
      if (valid) this.markWitness(record);
      return !valid;
    });
    this.finishJointSearch();
    this.deferred = !this.joint && this.transition.historyCandidates.length === 0;
    if (this.scope) this.scope.deferred = this.deferred;
  }
  startJointSearch() {
    if (!this.joint && !this.reasons.length)
      this.joint = { iterator: configurations(this.pack, this.opening, this.profiles), exhausted: false };
  }
  /** Explicitly enumerate complete assignments, even for a single observation. */
  verifyCombinations() {
    this.startJointSearch();
    this.verifyAll();
  }
  /** Explicit full-history validation, independent of the lightweight local cause pass. */
  verifyAll() {
    this.deferred = false;
    if (this.scope) this.scope.deferred = false;
    this.limited = false;
    this.epochWork = this.work;
    this.revalidate = [...this.records.values()];
    this.queries.clear();
    this.ensureQueries();
  }
  targets() {
    if (this.projectedTargets) return this.projectedTargets;
    const targets = /* @__PURE__ */ new Map();
    const add2 = (t) => targets.set(targetId(t), t);
    for (const p of this.profiles) {
      add2({ key: "combination", value: combinationKey(p) });
      for (const value2 of [p.y, ...p.x]) add2({ key: "rule", value: value2 });
      for (const [key, values] of p.store.domains)
        for (const value2 of targetValues(key, values)) add2({ key, value: value2 });
    }
    this.projectedTargets = [...targets.values()];
    return this.projectedTargets;
  }
  ensureQueries(targets = this.targets()) {
    const ids = new Set(targets.map(targetId));
    for (const id of this.queries.keys()) if (!ids.has(id)) this.queries.delete(id);
    for (const target of targets)
      if (!this.queries.has(targetId(target)))
        this.queries.set(targetId(target), {
          target,
          iterator: configurations(this.pack, this.opening, this.profiles, target),
          exhausted: false,
          unknown: false
        });
  }
  key(setup) {
    return canonical({
      ...setup,
      discussion: "allowed",
      x: [...setup.x].sort(),
      characters: setup.characters.map((c) => ({
        ...c,
        initialArea: c.initialArea ?? this.pack.characters[c.character]?.initial[0],
        ...c.character === "神灵" ? { enterLoop: c.enterLoop ?? 1 } : {}
      })).sort((a, b) => a.id.localeCompare(b.id)),
      incidents: setup.incidents.map((e) => ({ ...e, publicName: e.publicName ?? e.name })).sort((a, b) => a.day - b.day)
    });
  }
  admissible(setup, values = setupValues(setup)) {
    return this.profiles.some(
      (p) => p.y === setup.y && canonical([...p.x].sort()) === canonical([...setup.x].sort()) && [...values].every(([key, value2]) => supports(p, { key, value: value2 }))
    );
  }
  record(setup) {
    const key = this.key(setup), old = this.records.get(key);
    if (old) return old;
    const values = setupValues(setup);
    for (const c of setup.characters)
      if (!this.opening.characters.some((v) => v.id === c.id))
        values.set(`area:${c.id}`, c.initialArea ?? this.pack.characters[c.character].initial[0]);
    const result = {
      setup,
      values,
      search: new HistorySearch(this.pack, setup, this.evidence, this.opening)
    };
    this.records.set(key, result);
    this.generated++;
    this.initializations++;
    return result;
  }
  markWitness(record) {
    this.verified.add(targetId({ key: "combination", value: combinationKey(record.setup) }));
    for (const [key, value2] of record.values) this.verified.add(targetId({ key, value: value2 }));
    for (const value2 of [record.setup.y, ...record.setup.x])
      this.verified.add(targetId({ key: "rule", value: value2 }));
  }
  stepRecord(record) {
    const before = record.search.expansions, compared = record.search.compared;
    record.search.step();
    this.expansions += record.search.expansions - before;
    this.historyComparisons += record.search.compared - compared;
    const result = record.search.result;
    if (result === "possible") {
      this.markWitness(record);
    } else if (result === "excluded") {
      this.rejected.add(this.key(record.setup));
      this.enumeratedRecords.delete(record);
      this.records.delete(this.key(record.setup));
    }
    return result;
  }
  exclude(target) {
    const before = this.stats.removed, count2 = this.profiles.length;
    this.profiles = this.profiles.filter((p) => {
      if (!supports(p, target)) return true;
      if (target.key === "rule" || target.key === "combination") {
        p.active = false;
        return false;
      }
      p.store.narrow(
        target.key,
        [...p.store.values(target.key)].filter(
          (v) => (target.key.startsWith("identity:") ? shownIdentity(v) : v) !== target.value
        )
      );
      return p.active = p.store.propagate();
    });
    this.constraintVersion++;
    this.deductions.push({
      observation: this.evidence.observations.length,
      removed: this.stats.removed - before + count2 - this.profiles.length,
      reason: `${target.key} = ${target.value} 的合法联合配置及隐藏行动解释均已排除；结果沿依赖传播。`
    });
    this.projectedTargets = void 0;
    this.ensureQueries();
  }
  tick(milliseconds = 15, maxWork = this.searchBudget) {
    if (this.paused) return;
    const deadline = performance.now() + milliseconds;
    while (performance.now() < deadline && this.profiles.length) {
      if (this.work - this.epochWork >= maxWork || this.records.size > 512 || this.rejected.size > 1e5 || this.work % 100 === 0 && [...this.records.values()].reduce((n, r) => n + r.search.nodes, 0) > 4e3) {
        this.limited = true;
        break;
      }
      this.work++;
      const cached = this.revalidate.at(-1);
      if (cached) {
        if (!this.admissible(cached.setup, cached.values)) {
          this.enumeratedRecords.delete(cached);
          this.records.delete(this.key(cached.setup));
          this.revalidate.pop();
          if (!this.revalidate.length) this.finishJointSearch();
          continue;
        }
        if (this.stepRecord(cached) !== "unknown" || cached.search.blocked) this.revalidate.pop();
        if (!this.revalidate.length) this.finishJointSearch();
        continue;
      }
      if (this.joint) {
        if (this.joint.exhausted) break;
        const next2 = this.joint.iterator.next();
        if (next2.done) {
          this.joint.exhausted = true;
          this.finishJointSearch();
        } else if (next2.value && this.admissible(next2.value) && !this.rejected.has(this.key(next2.value))) {
          const record = this.record(next2.value);
          this.enumeratedRecords.add(record);
          if (record.search.result === "possible") this.markWitness(record);
          else this.revalidate.push(record);
        }
        continue;
      }
      const pending = [...this.queries.values()].filter(
        (q2) => !this.verified.has(targetId(q2.target)) && !(q2.exhausted && q2.unknown)
      );
      if (!pending.length) break;
      const q = pending[this.cursor++ % pending.length];
      if (q.current) {
        if (!this.admissible(q.current.setup, q.current.values)) {
          q.current = void 0;
          continue;
        }
        const result = this.stepRecord(q.current);
        if (result !== "unknown" || q.current.search.blocked) {
          if (q.current.search.blocked) q.unknown = true;
          q.current = void 0;
        }
        continue;
      }
      const next = q.iterator.next();
      if (next.done) {
        q.exhausted = true;
        if (!q.unknown) this.exclude(q.target);
        continue;
      }
      if (!next.value) continue;
      const setup = next.value;
      if (!this.admissible(setup) || this.rejected.has(this.key(setup))) continue;
      q.current = this.record(setup);
    }
  }
  finishJointSearch() {
    if (!this.joint?.exhausted || this.revalidate.length) return;
    this.jointUnknown = [...this.records.values()].some((r) => r.search.result === "unknown");
    if (this.jointUnknown) return;
    for (const t of [...this.targets()]) if (!this.verified.has(targetId(t))) this.exclude(t);
  }
  /** Return the exact joint space only at a completed, supported checkpoint. */
  jointSolutions() {
    if (this.reasons.length && !this.publicContradiction) return;
    if (!this.profiles.length) return [];
    if (!this.joint?.exhausted || this.revalidate.length || this.jointUnknown) return;
    return [...this.enumeratedRecords].map((r) => structuredClone(r.setup));
  }
  get paused() {
    return !!this.reasons.length || !this.profiles.length || this.limited || this.deferred || (this.joint ? this.joint.exhausted && !this.revalidate.length : !this.revalidate.length && [...this.queries.values()].every(
      (q) => this.verified.has(targetId(q.target)) || q.exhausted && q.unknown
    ));
  }
  /** Explicit single-configuration query; no implicit count or global traversal. */
  queryConfiguration(setup) {
    if (this.publicContradiction) return "excluded";
    if (this.reasons.length) return "unknown";
    const diagnostics = validateSetup(this.pack, setup);
    if (hasUnsupportedDiagnostic(diagnostics)) return "unknown";
    if (diagnostics.length || setup.days !== this.opening.days || setup.loops !== this.opening.loops || setup.captain !== this.opening.captain || canonical(setup.incidents.map((e) => ({ day: e.day, name: e.publicName ?? e.name }))) !== canonical(this.opening.incidents) || !this.admissible(setup))
      return "excluded";
    if (this.rejected.has(this.key(setup))) return "excluded";
    const record = this.record(setup);
    for (let steps = 0; steps < this.searchBudget && record.search.result === "unknown" && !record.search.blocked && record.search.nodes <= 4e3; steps++)
      this.stepRecord(record);
    return record.search.result;
  }
  snapshot() {
    if (this.opening.phase === "briefing") return waitingForCharacters(this.revision < 0 ? this.opening.revision : this.revision);
    const identities2 = {}, culprits = {}, realIncidents = {}, parameters = {};
    const verified = {
      identities: {},
      rules: [],
      culprits: {},
      realIncidents: {}
    };
    const rules = [], targets = this.targets();
    const add2 = (record, key, value2) => (record[key] ??= []).push(value2);
    for (const t of targets) {
      const confirmed = this.verified.has(targetId(t));
      if (t.key === "rule") {
        rules.push(t.value);
        if (confirmed) verified.rules.push(t.value);
      } else if (t.key.startsWith("identity:")) {
        add2(identities2, t.key.slice(9), t.value);
        if (confirmed) add2(verified.identities, t.key.slice(9), t.value);
      } else if (t.key.startsWith("culprit:")) {
        add2(culprits, t.key.slice(8), t.value);
        if (confirmed) add2(verified.culprits, t.key.slice(8), t.value);
      } else if (t.key.startsWith("event:")) {
        add2(realIncidents, t.key.slice(6), t.value);
        if (confirmed) add2(verified.realIncidents, t.key.slice(6), t.value);
      } else if (t.key !== "combination") add2(parameters, t.key, t.value);
    }
    for (const c of this.opening.roster ?? this.opening.characters)
      if (c.character === "仙人") parameters["x:" + c.id] = ["非负整数（符号域）"];
    const verifiedValues = targets.filter((t) => this.verified.has(targetId(t))).length;
    const possible = [...this.records.values()].filter(
      (r) => r.search.result === "possible"
    ).length;
    return {
      representation: "constraints",
      calculationTrace: [...this.trace],
      historySearchDeferred: this.deferred,
      openingColumns: this.openingColumns,
      jointCount: !this.profiles.length && (!this.reasons.length || this.publicContradiction) ? 0 : this.joint?.exhausted && !this.revalidate.length && !this.jointUnknown ? this.enumeratedRecords.size : null,
      revision: this.revision,
      ruleDigest: this.pack.digest,
      status: this.publicContradiction ? "contradiction" : this.reasons.length ? "unsupported" : !this.profiles.length ? "contradiction" : verifiedValues === targets.length && (!this.joint || this.joint.exhausted && !this.jointUnknown && !this.revalidate.length) ? "exact" : this.paused ? "incomplete" : "running",
      domainComplete: !this.reasons.length,
      generated: this.generated,
      possible,
      unresolved: targets.length - verifiedValues,
      excluded: this.rejected.size,
      expansions: this.expansions,
      elapsedMs: Math.round(performance.now() - this.started),
      identities: identities2,
      impliedIdentities: Object.fromEntries(Object.entries(this.causal?.impliedIdentities ?? {}).filter(([id, fact]) => identities2[id]?.length === 1 && identities2[id]?.[0] === fact.identity)),
      rules: rules.sort(),
      culprits,
      realIncidents,
      parameters,
      verified,
      ruleCombinations: [
        ...new Map(this.profiles.map((p) => [canonical([p.y, p.x]), { y: p.y, x: p.x }])).values()
      ],
      reasons: [
        ...this.reasons,
        ...this.deferred ? ["局部约束传播完成；未展开无关身份。剩余候选尚未完成联合历史核验，可按需核验。"] : [],
        ...this.limited ? ["本次联合搜索达到预算；尚未验证的候选继续保留，新增信息后继续推进。"] : []
      ],
      evidenceThrough: this.evidence.observations.length,
      deductions: this.deductions.slice(-100),
      scope: this.scope,
      relations: this.causal?.relations(this.profiles) ?? [],
      transition: this.transition && {
        ...this.transition,
        newHistoryRoots: this.initializations - this.priorRoots,
        historyBranches: this.expansions - this.priorExpansions
      },
      propagation: {
        ...this.stats,
        informationVersion: this.evidence.version,
        constraintVersion: this.constraintVersion,
        pending: targets.length - verifiedValues,
        candidateValues: targets.length,
        verifiedValues,
        initializations: this.initializations,
        historyComparisons: this.historyComparisons,
        causeBranches: this.causal?.causeBranches ?? 0
      }
    };
  }
};

// packages/engine/src/runtime/knowledge-enumerated.ts
function unsupportedDomain2(pack, opening) {
  const reasons = [];
  if ([...opening.characters, ...opening.roster ?? []].some((c) => c.character === "仙人"))
    reasons.push("仙人的非负整数 X 尚无有限公开上界，需要符号域支持。");
  if (Object.values(pack.plots).some((p) => !p.supported)) reasons.push("存在尚未支持的规则。");
  return reasons.concat(incompleteContent(pack, opening));
}
function* generateDomain(pack, opening) {
  const roster = publicRoster(pack, opening);
  const absent = roster.flatMap(
    (c, i) => opening.characters.some((v) => v.id === c.id) ? [] : [i]
  );
  const ys = Object.values(pack.plots).filter((p) => p.type === "Y");
  const xs = Object.values(pack.plots).filter((p) => p.type === "X");
  const xSets = pack.module === "FS" ? xs.map((x) => [x]) : xs.flatMap((x, i) => xs.slice(i + 1).map((z) => [x, z]));
  for (const y of ys)
    for (const xSet of xSets) {
      const basePool = {};
      const pairs = [];
      for (const p of [y, ...xSet]) {
        for (const [identity, count2] of Object.entries(p.identities))
          basePool[identity] = Math.min(
            (basePool[identity] ?? 0) + count2,
            pack.identities[identity]?.max ?? Infinity
          );
        if (p.pair) pairs.push(p.pair);
      }
      const additions = xSet.some((p) => p.name === "捏造的秘密") ? [void 0, "杀手", "主谋", "因果残片"] : [void 0];
      for (const secretAddition of additions) {
        if (secretAddition && basePool[secretAddition]) continue;
        const pool = { ...basePool, ...secretAddition ? { [secretAddition]: 1 } : {} };
        const characters = roster.map((c) => ({
          id: c.id,
          character: c.character,
          initialArea: c.area,
          identity: "平民"
        }));
        function* assign(index, remainingPairs) {
          const slots = characters.slice(index).filter((c) => !["局外人", "模仿犯"].includes(c.character)).length;
          const required = Object.entries(pool).filter(([k]) => !["平民", "暴徒"].includes(k)).reduce((n, [, count2]) => n + count2, 0) + remainingPairs.length;
          if (required > slots) {
            yield null;
            return;
          }
          if (index < characters.length) {
            const c = characters[index];
            if (c.character === "模仿犯") {
              yield* assign(index + 1, remainingPairs);
              return;
            }
            const identities2 = c.character === "局外人" ? Object.keys(pack.identities).filter(
              (k) => k !== "平民" && !pool[k] && !basePool[k] && !pairs.some((p) => p.includes(k))
            ) : ["平民", ...Object.keys(pool).filter((k) => k !== "平民" && pool[k] > 0)];
            for (const identity of identities2) {
              c.identity = identity;
              delete c.reverseIdentity;
              const counted = c.character !== "局外人" && identity !== "平民";
              if (counted) pool[identity]--;
              yield* assign(index + 1, remainingPairs);
              if (counted) pool[identity]++;
            }
            if (c.character !== "局外人")
              for (let i = 0; i < remainingPairs.length; i++) {
                [c.identity, c.reverseIdentity] = remainingPairs[i];
                yield* assign(
                  index + 1,
                  remainingPairs.filter((_, j) => i !== j)
                );
              }
            delete c.reverseIdentity;
            return;
          }
          if (remainingPairs.length || Object.entries(pool).some(([k, n]) => k !== "平民" && k !== "暴徒" && n !== 0)) {
            yield null;
            return;
          }
          const setup = {
            module: opening.module,
            anniversary: opening.anniversary,
            loops: opening.loops,
            days: opening.days,
            captain: opening.captain,
            discussion: "allowed",
            y: y.name,
            x: xSet.map((p) => p.name),
            characters: structuredClone(characters),
            incidents: [],
            secretAddition
          };
          function* parameters(i) {
            if (i < setup.characters.length) {
              const c = setup.characters[i];
              function* next() {
                if (pack.characters[c.character]?.abilityArea?.publicMarker === "territory") {
                  for (const territory of opening.territory ? [opening.territory] : BOARDS) {
                    c.territory = territory;
                    yield* parameters(i + 1);
                  }
                } else yield* parameters(i + 1);
              }
              if (c.character === "模仿犯") {
                for (const target of setup.characters.filter((t) => t.id !== c.id)) {
                  c.identity = target.identity;
                  c.reverseIdentity = target.reverseIdentity;
                  c.copiedFrom = target.id;
                  yield* next();
                }
              } else if (c.character === "转校生") {
                for (let day = 1; day <= setup.days; day++) {
                  c.enterDay = day;
                  yield* next();
                }
              } else if (c.character === "神灵") {
                for (let loop = 1; loop <= setup.loops; loop++) {
                  c.enterLoop = loop;
                  yield* next();
                }
              } else yield* next();
              return;
            }
            yield* initialAreas(0);
          }
          function* initialAreas(i) {
            if (i === absent.length) {
              yield* incidents(0);
              return;
            }
            const c = setup.characters[absent[i]];
            for (const area of pack.characters[c.character].initial) {
              c.initialArea = area;
              yield* initialAreas(i + 1);
            }
          }
          function* incidents(i) {
            if (i < opening.incidents.length) {
              const event = opening.incidents[i];
              const names = [
                event.name,
                ...pack.incidents["伪造事件"] && event.name !== "伪造事件" ? ["伪造事件"] : []
              ];
              for (const name of names)
                for (const culprit of pack.incidents[name]?.crowdThreshold !== void 0 ? BOARDS : characters.map((c) => c.id)) {
                  setup.incidents[i] = { day: event.day, name, publicName: event.name, culprit };
                  yield* incidents(i + 1);
                }
              return;
            }
            const fragments = opening.anniversary ? setup.characters.filter((c) => c.identity === "平民").map((c) => c.id) : [void 0];
            const alternateYs = setup.x.includes("疯狂的真相") ? ys.filter((p) => p.name !== setup.y).map((p) => p.name) : [void 0];
            const roles = pack.module === "LL" ? ["A", "B", "C"].flatMap(
              (p0) => ["A", "B", "C"].filter((p1) => p1 !== p0).map((p1) => ({
                p0,
                p1,
                p2: ["A", "B", "C"].find((r) => r !== p0 && r !== p1)
              }))
            ) : [void 0];
            for (const fragment2 of fragments)
              for (const alternateY of alternateYs)
                for (const privateRoles of roles) {
                  setup.anniversaryFragment = fragment2;
                  setup.alternateY = alternateY;
                  setup.privateRoles = privateRoles;
                  const matchesOpening = setup.characters.every(
                    (c) => roster.find((p) => p.id === c.id)?.status === (c.enterDay || (c.enterLoop ?? 1) > 1 ? "absent" : "alive")
                  );
                  yield !matchesOpening || validateSetup(pack, setup).length ? null : structuredClone(setup);
                }
          }
          yield* parameters(0);
        }
        yield* assign(0, pairs);
      }
    }
}
function initialDomain(pack, opening) {
  const names = opening.incidents.map((i) => i.name);
  const restricted = ["强迫症", "愚者", "双胞胎", "祭品", "怪杰", "侦探"];
  const independent = ["FS", "BTX"].includes(pack.module) && names.length > 0 && !restricted.some((name) => pack.identities[name]) && !pack.plots["灭亡讴歌"] && !pack.incidents["伪造事件"] && names.every(
    (name) => pack.incidents[name]?.supported && pack.incidents[name]?.crowdThreshold === void 0 && name !== "连续杀人"
  );
  const n = publicRoster(pack, opening).length;
  const weight = independent ? names.reduce((value2, _, i) => value2 * Math.max(0, n - i), 1) : 1;
  if (!independent || !Number.isSafeInteger(weight))
    return { domain: generateDomain(pack, opening), weight: 1, factored: false };
  return {
    domain: weight === 0 ? function* () {
    }() : generateDomain(pack, { ...opening, incidents: [] }),
    weight,
    factored: true
  };
}
var EnumeratedKnowledge = class _EnumeratedKnowledge {
  constructor(pack, opening, cacheLimit = 5e3, materializeForComparison = false) {
    this.pack = pack;
    this.opening = opening;
    this.cacheLimit = cacheLimit;
    this.materializeForComparison = materializeForComparison;
    if (!Number.isSafeInteger(cacheLimit) || cacheLimit < 0)
      throw new Error("Invalid knowledge cache limit.");
    this.reasons = unsupportedDomain2(pack, opening);
    const initial = materializeForComparison ? { domain: generateDomain(pack, opening), weight: 1, factored: false } : initialDomain(pack, opening);
    this.domain = initial.domain;
    this.initialWeight = initial.weight;
    if (initial.factored) this.initialCached = false;
  }
  domain;
  candidates = [];
  expected = [];
  observations = [];
  complete = false;
  cursor = 0;
  revision = -1;
  expansions = 0;
  epochExpansions = 0;
  generationStopped = false;
  generationAttempts = 0;
  initialOnly = true;
  discarded = 0;
  initialCount = 0;
  initialCached = true;
  initialWeight = 1;
  streamed = false;
  streamedPossible = 0;
  streamedIdentities = {};
  streamedRules = /* @__PURE__ */ new Set();
  streamedCulprits = {};
  initialIdentities = {};
  initialRules = /* @__PURE__ */ new Set();
  initialCulprits = {};
  limited = false;
  deductions = [];
  started = performance.now();
  reasons;
  update(history, revision) {
    const next = normalizeHistory(history);
    if (this.expected.some((o, i) => next[i] !== o))
      throw new Error("观察必须追加，不能改写已有历史。");
    const openingHistory = normalizeHistory(this.opening.observations);
    if (this.initialOnly && (next.length > openingHistory.length || next.some((o, i) => o !== openingHistory[i]))) {
      this.initialOnly = false;
      if (!this.initialCached) {
        this.domain = generateDomain(this.pack, this.opening);
        this.complete = false;
        this.generationStopped = false;
        this.generationAttempts = 0;
      }
    }
    if (next.length !== this.expected.length && !this.initialOnly && (!this.initialCached || this.streamed)) {
      this.streamed = true;
      this.candidates = [];
      this.discarded = 0;
      this.streamedPossible = 0;
      this.streamedIdentities = {};
      this.streamedRules.clear();
      this.streamedCulprits = {};
      this.domain = generateDomain(this.pack, this.opening);
      this.complete = false;
      this.generationStopped = false;
      this.generationAttempts = 0;
      this.deductions = [];
    }
    if (next.length !== this.expected.length) {
      for (const c of this.candidates) {
        c.active.push(...c.frontier);
        c.frontier = [];
      }
      this.epochExpansions = this.expansions;
      this.limited = false;
    }
    this.expected = next;
    this.observations = structuredClone(history);
    this.revision = revision;
    this.propagate();
  }
  propagate(candidates = this.candidates) {
    if (this.materializeForComparison) return;
    if (!["FS", "BTX"].includes(this.pack.module)) return;
    for (let i = 0; i < this.expected.length; i++) {
      const observation = JSON.parse(this.expected[i]);
      const d = observation.data;
      let removed = 0;
      for (const candidate of candidates) {
        if (!candidate.root && !candidate.active.length && !candidate.frontier.length && !candidate.uncertain)
          continue;
        const setup = candidate.setup;
        let contradicts = false;
        if (observation.type === "identity" && typeof d.identity === "string") {
          const c = setup.characters.find((c2) => c2.id === d.character);
          if (c && c.character !== "临时工")
            contradicts = (setup.anniversaryFragment === c.id ? "因果残片" : c.identity) !== d.identity && !(c.identity === "平民" && setup.anniversaryFragment !== c.id && setup.x.includes("妄想扩大病毒") && d.identity === "杀人狂");
        }
        if (observation.type === "rule" && typeof d.rule === "string")
          contradicts = ![setup.y, ...setup.x].includes(d.rule);
        if (observation.type === "culprit" && typeof d.culprit === "string")
          contradicts = setup.incidents.find((e) => e.day === d.day)?.culprit !== d.culprit;
        if (contradicts) {
          candidate.root = false;
          candidate.active = [];
          candidate.frontier = [];
          candidate.uncertain = false;
          removed++;
        }
      }
      if (removed) {
        const prior = this.deductions.find((d2) => d2.observation === i + 1);
        if (prior) prior.removed += removed;
        else
          this.deductions.push({
            observation: i + 1,
            removed,
            reason: `正式公开的${observation.type === "identity" ? "身份" : observation.type === "rule" ? "规则" : "当事人"}与联合配置冲突；其余变量随联合配置传播。`
          });
      }
    }
  }
  tick(milliseconds = 20, maxExpansions = 2e4) {
    if (this.reasons.length) return;
    const end = performance.now() + milliseconds;
    while (performance.now() < end && this.expansions - this.epochExpansions < maxExpansions && !this.limited) {
      const finished = this.candidates.at(-1);
      if (this.streamed && finished?.frontier.length) {
        const setup = finished.setup;
        this.streamedPossible++;
        this.streamedRules.add(setup.y);
        setup.x.forEach((x) => this.streamedRules.add(x));
        for (const c of setup.characters) {
          const values = this.streamedIdentities[c.id] ??= [];
          const value2 = setup.anniversaryFragment === c.id ? "因果残片" : c.identity;
          if (!values.includes(value2)) values.push(value2);
        }
        for (const i of setup.incidents) {
          const values = this.streamedCulprits[String(i.day)] ??= [];
          if (!values.includes(i.culprit)) values.push(i.culprit);
        }
        this.candidates.pop();
      }
      const last = this.candidates.at(-1);
      if (!this.initialOnly && !this.complete && last && !last.root && !last.active.length && !last.frontier.length && !last.uncertain) {
        this.candidates.pop();
        this.discarded++;
      }
      const tail = this.candidates.at(-1);
      if (!this.complete && !this.generationStopped && (this.initialOnly || !tail || tail.frontier.length || !tail.root && !tail.active.length)) {
        const next2 = this.domain.next();
        this.generationAttempts++;
        this.complete = !!next2.done;
        if (next2.value && this.initialOnly) {
          this.initialCount += this.initialWeight;
          if (this.initialCached && this.initialCount <= this.cacheLimit) {
            this.candidates.push({
              setup: next2.value,
              active: [],
              root: true,
              frontier: [],
              uncertain: false
            });
          } else if (this.initialCached) {
            this.candidates = [];
            this.initialCached = false;
          }
          const setup = next2.value;
          this.initialRules.add(setup.y);
          setup.x.forEach((x) => this.initialRules.add(x));
          for (const c of setup.characters) {
            const values = this.initialIdentities[c.id] ??= [];
            const value2 = setup.anniversaryFragment === c.id ? "因果残片" : c.identity;
            if (!values.includes(value2)) values.push(value2);
          }
          for (const i of setup.incidents) {
            const values = this.initialCulprits[String(i.day)] ??= [];
            if (!values.includes(i.culprit)) values.push(i.culprit);
          }
          if (this.initialWeight !== 1 || !setup.incidents.length)
            for (const event of this.opening.incidents) {
              this.initialCulprits[String(event.day)] = publicRoster(this.pack, this.opening).map(
                (c) => c.id
              );
            }
        } else if (next2.value) {
          this.candidates.push({
            setup: next2.value,
            active: [],
            root: true,
            frontier: [],
            uncertain: false
          });
        }
        if (!this.initialOnly && !this.streamed && this.candidates.length > this.cacheLimit) {
          this.streamed = true;
          this.initialCached = false;
          this.candidates = [];
          this.discarded = 0;
          this.domain = generateDomain(this.pack, this.opening);
          this.complete = false;
          this.generationAttempts = 0;
          this.deductions = [];
          continue;
        }
        if (!this.initialOnly && this.candidates.length >= 1e5) this.generationStopped = true;
        if (!this.initialOnly && next2.value) this.propagate([this.candidates.at(-1)]);
        if (!this.complete && !this.generationStopped && (this.initialOnly || !next2.value))
          continue;
      }
      const candidate = !this.complete && !this.generationStopped ? this.candidates.at(-1) : this.candidates[this.cursor++ % this.candidates.length];
      if (!candidate) break;
      if (this.rootSatisfied(candidate)) break;
      if (candidate.frontier.length) {
        if (this.candidates.every((c) => c.frontier.length || !c.root && !c.active.length)) break;
        continue;
      }
      if (candidate.root) {
        const initial = initializeDiscussion(this.pack, candidate.setup);
        candidate.root = false;
        candidate.uncertain = !initial.state;
        if (initial.state) candidate.active.push({ state: initial.state });
      }
      if (!candidate.active.length) {
        if (this.candidates.every((c) => c.frontier.length || !c.root && !c.active.length)) break;
        continue;
      }
      const node = candidate.active[candidate.active.length - 1];
      const actual = node.normalized ??= normalizeHistory(node.state.observations.protagonists);
      if (actual.slice(0, this.expected.length).some((o, i) => o !== this.expected[i])) {
        candidate.active.pop();
        continue;
      }
      if (actual.length >= this.expected.length) {
        candidate.frontier.push(candidate.active.pop());
        continue;
      }
      const pending = node.state.pending;
      if (!pending || node.state.winner) {
        if (!node.state.winner) candidate.uncertain = true;
        candidate.active.pop();
        continue;
      }
      if (!node.choices) {
        const known = this.observations.slice(actual.length).find((o) => o.type === "own-choice");
        node.choices = pending.actor !== "mastermind" && known ? function* () {
          if (known.data.actor === pending.actor) yield known.data.choice;
        }() : this.hiddenChoices(node.state, actual.length);
        if (pending.kind === "guess" && !known) candidate.uncertain = true;
      }
      const next = node.choices.next();
      if (next.done) {
        candidate.active.pop();
        continue;
      }
      this.expansions++;
      const advanced = advance(this.pack, node.state, pending.actor, {
        id: `knowledge-${node.state.revision}`,
        expectedRevision: node.state.revision,
        decisionId: pending.id,
        choice: next.value
      });
      if (advanced.status === "rejected") continue;
      if (advanced.status === "paused") candidate.uncertain = true;
      candidate.active.push({ state: advanced.state });
      if (this.expansions % 100 === 0 && this.candidates.reduce((n, c) => n + c.active.length + c.frontier.length, 0) > 16e3)
        this.limited = true;
    }
    if (this.expansions - this.epochExpansions >= maxExpansions) this.limited = true;
  }
  rootSatisfied(candidate) {
    return candidate.root && this.opening.phase === "discussion" && this.opening.loop === 1 && this.expected.length <= this.opening.observations.length && this.expected.every((o, i) => normalizeHistory(this.opening.observations)[i] === o);
  }
  /** Trusted-host query for one entire initial configuration, not independent marginal guesses. */
  queryConfiguration(setup) {
    if (this.reasons.length) return "unknown";
    const key = (s) => canonical({
      y: s.y,
      x: [...s.x].sort(),
      module: s.module,
      anniversary: s.anniversary,
      anniversaryFragment: s.anniversaryFragment,
      alternateY: s.alternateY,
      secretAddition: s.secretAddition,
      privateRoles: s.privateRoles,
      characters: s.characters.map((c) => ({
        ...c,
        initialArea: c.initialArea ?? this.pack.characters[c.character]?.initial[0] ?? "hospital",
        enterLoop: c.enterLoop ?? 1
      })).sort((a, b) => a.id.localeCompare(b.id)),
      incidents: s.incidents.map((i) => ({ ...i, publicName: i.publicName ?? i.name }))
    });
    if (this.initialOnly) {
      const started = initializeDiscussion(this.pack, setup);
      if (!started.state)
        return hasUnsupportedDiagnostic(started.diagnostics) ? "unknown" : "excluded";
      return setup.module === this.opening.module && setup.anniversary === this.opening.anniversary && setup.days === this.opening.days && setup.loops === this.opening.loops && setup.captain === this.opening.captain && matchesOpeningRoster(started.state, this.opening) && canonical(setup.incidents.map((i) => ({ day: i.day, name: i.publicName ?? i.name }))) === canonical(this.opening.incidents) && this.expected.every(
        (o, i) => normalizeHistory(started.state.observations.protagonists)[i] === o
      ) ? "possible" : "excluded";
    }
    if (hasUnsupportedDiagnostic(validateSetup(this.pack, setup))) return "unknown";
    const target = key(setup);
    const matches = this.candidates.filter((c) => key(c.setup) === target);
    if (matches.some((c) => this.rootSatisfied(c) || c.frontier.length)) return "possible";
    if (this.streamed) {
      const check = new _EnumeratedKnowledge(this.pack, this.opening);
      check.update(this.opening.observations, this.opening.revision);
      if (check.queryConfiguration(setup) === "excluded") return "excluded";
      check.initialOnly = false;
      check.initialCached = true;
      check.domain = function* () {
        yield structuredClone(setup);
      }();
      check.update(this.observations, this.revision);
      while (!check.paused) check.tick(20);
      const result = check.snapshot();
      return result.possible ? "possible" : result.status === "contradiction" ? "excluded" : "unknown";
    }
    if (matches.some((c) => c.root || c.active.length || c.uncertain) || !this.complete || this.streamed || this.reasons.length)
      return "unknown";
    return "excluded";
  }
  *hiddenChoices(state, offset) {
    if (state.pending?.kind !== "cards" || state.pending.actor !== "mastermind") {
      yield* enumerateChoices(state);
      return;
    }
    const records = this.observations.slice(offset).filter((o) => o.type === "cards" && o.loop === state.loop && o.day === state.day);
    const known = records.find(
      (o) => Array.isArray(o.data.placements) && o.data.placements.every((p) => p.owner === "mastermind")
    );
    if (!known || !Array.isArray(known.data.placements)) {
      yield* enumerateChoices(state);
      return;
    }
    const targets = known.data.placements.map((p) => p.target);
    const revealed = records.find((o) => o.phase === "card-resolution");
    const reveal2 = Array.isArray(revealed?.data.placements) ? revealed.data.placements : [];
    const cards = state.cards.filter((c) => c.owner === "mastermind" && c.status === "hand");
    function* place(i, placements) {
      if (i === targets.length) {
        yield {
          kind: "cards",
          placements: placements.slice().sort(
            (a, b) => cards.findIndex((c) => c.id === a.card) - cards.findIndex((c) => c.id === b.card)
          )
        };
        return;
      }
      const target = targets[i];
      const face = reveal2.find((p) => p.owner === "mastermind" && p.target === target)?.kind;
      for (const card of cards)
        if ((!face || card.kind === face) && !placements.some((p) => p.card === card.id))
          yield* place(i + 1, [...placements, { card: card.id, target }]);
    }
    yield* place(0, []);
  }
  get paused() {
    return this.limited || this.reasons.length > 0 || (this.complete || this.generationStopped) && this.candidates.every(
      (c) => this.rootSatisfied(c) || c.frontier.length || !c.root && !c.active.length
    );
  }
  snapshot() {
    if (this.initialOnly)
      return {
        revision: this.revision,
        ruleDigest: this.pack.digest,
        status: this.reasons.length ? "unsupported" : this.complete ? this.initialCount ? "exact" : "contradiction" : "running",
        domainComplete: this.complete,
        generated: this.initialCount,
        possible: this.initialCount,
        unresolved: 0,
        excluded: 0,
        expansions: 0,
        elapsedMs: Math.round(performance.now() - this.started),
        identities: structuredClone(this.initialIdentities),
        rules: [...this.initialRules].sort(),
        culprits: structuredClone(this.initialCulprits),
        reasons: [...this.reasons],
        evidenceThrough: this.expected.length
      };
    const kept = this.candidates.filter(
      (c) => c.root || c.frontier.length || c.active.length || c.uncertain
    );
    const currentPossible = kept.filter((c) => this.rootSatisfied(c) || c.frontier.length).length;
    const possible = this.streamedPossible + currentPossible;
    const unresolved = kept.length - currentPossible;
    const identities2 = structuredClone(this.streamedIdentities), culprits = structuredClone(this.streamedCulprits);
    const rules = new Set(this.streamedRules);
    for (const c of kept) {
      rules.add(c.setup.y);
      c.setup.x.forEach((x) => rules.add(x));
      for (const char of c.setup.characters) {
        const values = identities2[char.id] ??= [];
        const identity = c.setup.anniversaryFragment === char.id ? "因果残片" : char.identity;
        if (!values.includes(identity)) values.push(identity);
      }
      for (const event of c.setup.incidents) {
        const values = culprits[String(event.day)] ??= [];
        if (!values.includes(event.culprit)) values.push(event.culprit);
      }
    }
    const status = this.reasons.length ? "unsupported" : !this.complete ? this.generationStopped || this.limited ? "incomplete" : "running" : !kept.length && !this.streamedPossible ? "contradiction" : unresolved ? "incomplete" : "exact";
    return {
      revision: this.revision,
      ruleDigest: this.pack.digest,
      status,
      domainComplete: this.complete,
      generated: this.candidates.length + this.discarded + this.streamedPossible,
      possible,
      unresolved,
      excluded: this.candidates.length + this.discarded - kept.length,
      expansions: this.expansions,
      elapsedMs: Math.round(performance.now() - this.started),
      identities: identities2,
      rules: [...rules].sort(),
      culprits,
      reasons: [
        ...this.reasons,
        ...unresolved ? ["仍有隐藏历史未穷尽；未判定候选继续保留。"] : [],
        ...this.generationStopped ? ["初始构造达到配置或尝试次数预算；未生成部分仍未知，不能作全域排除。"] : [],
        ...this.limited ? ["本观察版本达到搜索或内存预算；新增观察后继续，未搜索分支仍保留。"] : []
      ],
      evidenceThrough: this.expected.length,
      deductions: this.deductions.map((d) => ({ ...d }))
    };
  }
};

// packages/content/src/official/compile.ts
import { createHash } from "node:crypto";

// packages/content/src/official/interaction-rules.ts
var characterTraits = {
  大人物: {
    abilityArea: {
      actor: "mastermind",
      modes: ["actual", "territory"],
      publicMarker: "territory",
      selection: "before-declaration"
    }
  },
  仙人: {
    incidentAreaFromBase: "clockwise",
    abilities: [
      {
        id: "immortal-revive",
        timing: "protagonist-abilities",
        threshold: 5,
        loopLimit: 1,
        // 首步先声明目的地和尸体，拒绝检查之后才执行移动。次步复查已声明目标。
        steps: [
          {
            choices: [
              { key: "area", options: ["hospital", "shrine", "city", "school", "far"] },
              { key: "target", options: ["$corpses-after-self-move"], allowEmpty: true }
            ],
            effects: [{ op: "move", target: "$self", area: "$area" }]
          },
          {
            condition: {
              cmp: "eq",
              left: { field: "area", target: "$target" },
              right: { field: "area", target: "$self" }
            },
            effects: [
              {
                op: "when",
                condition: {
                  cmp: "eq",
                  left: { field: "status", target: "$target" },
                  right: "dead"
                },
                effects: [
                  { op: "revive", target: "$target" },
                  { op: "counter", target: "$target", counter: "goodwill", amount: { ref: "$x" } }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  从者: { protects: { characters: ["大人物", "大小姐"], selectedTargetFlag: "protect" } }
};
var identityTraits = {
  胆小鬼: {
    abilities: [
      {
        id: "coward",
        timing: "mastermind-abilities",
        mandatory: true,
        condition: { cmp: "ge", left: { counter: "paranoia", target: "$self" }, right: 2 },
        steps: [
          {
            choices: [{ key: "area", options: ["$adjacent-any-self"] }],
            effects: [{ op: "move", target: "$self", area: "$area" }]
          }
        ]
      }
    ]
  },
  双胞胎: { baseIncidentArea: "diagonal" },
  侦探: { sameAreaIncidentTrigger: { cmp: "eq", left: { game: "ex" }, right: 0 } }
};
var incidentTraits2 = {
  孤守: { afterIncidentSteps: [{ moveOthersFromEffectiveArea: true, effects: [] }] }
};
var moduleAbilities = {
  HSA: [
    {
      owner: "module:zombies",
      ability: {
        id: "zombie-move",
        source: "module.HSA.zombie",
        timing: "day-end",
        steps: [
          {
            choices: [
              { key: "target", options: ["$zombie-corpses"] },
              { key: "area", options: ["$adjacent-corpse"] }
            ],
            effects: [{ op: "move-corpse", target: "$target", area: "$area" }]
          }
        ]
      }
    }
  ]
};

// packages/content/src/official/source-catalog.json
var source_catalog_default = {
  schema: 1,
  policy: "wiki > lloyd > ricardo per field; project rulings explicit",
  entries: [
    {
      id: "e17686c361a8dc2b",
      name: "学者",
      kind: "characters",
      module: null,
      source: "facts/data/characters/e17686c361a8dc2b.json",
      sha256: "293d560ed2dd9bd720880e5257f4d1c6cc8e39e03aa941f1a4fc87e4e7733828",
      fields: {
        角色名: "学者",
        初始区域: "医院",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "男性",
          "成人"
        ],
        特性: "每輪輪迴開始時，往該角色身上放置友好，不安，密謀指示物中的任意1枚。",
        友好能力: [
          {
            text: "（友好3）移除該角色身上所有的指示物。隨後，如果本局遊戲使用Ex槽，選擇Ex槽+1或-1。",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AD%B8%E8%80%85",
          snapshot: "sources/wiki/pages/021480e95f4e88ae.json",
          capturedAt: "2026-09-27T03:31:54.369Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AD%B8%E8%80%85",
          snapshot: "sources/wiki/pages/021480e95f4e88ae.json",
          capturedAt: "2026-09-27T03:31:54.369Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AD%B8%E8%80%85",
          snapshot: "sources/wiki/pages/021480e95f4e88ae.json",
          capturedAt: "2026-09-27T03:31:54.369Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AD%B8%E8%80%85",
          snapshot: "sources/wiki/pages/021480e95f4e88ae.json",
          capturedAt: "2026-09-27T03:31:54.369Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AD%B8%E8%80%85",
          snapshot: "sources/wiki/pages/021480e95f4e88ae.json",
          capturedAt: "2026-09-27T03:31:54.369Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AD%B8%E8%80%85",
          snapshot: "sources/wiki/pages/021480e95f4e88ae.json",
          capturedAt: "2026-09-27T03:31:54.369Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AD%B8%E8%80%85",
          snapshot: "sources/wiki/pages/021480e95f4e88ae.json",
          capturedAt: "2026-09-27T03:31:54.369Z"
        }
      }
    },
    {
      id: "6145e115e8bfb5ab",
      name: "Basic Tragedy X",
      kind: "modules",
      module: "BTX",
      source: "facts/data/modules/6145e115e8bfb5ab.json",
      sha256: "1e6298e7147937554e75e8f000978aa2975966388d0250abd4dcb76d3770b30a",
      fields: {
        special: [
          "基础游戏模组，5条规则Y、7条规则X，所有现行模组以此为准"
        ]
      },
      provenance: {
        special: {
          provider: "lloyd",
          path: "sources/lunhui/tragedy_loop_appendix(3)(1).md"
        }
      }
    },
    {
      id: "136dd14d0de11e0f",
      name: "谋杀计划",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/136dd14d0de11e0f.json",
      sha256: "61a580357d0d661de0f7892f3fdbf1b704548543f82221f02d5cc5fe6b849951",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          杀手: "①",
          主谋: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "13deb6e5725d7cbf",
      name: "被封印的邪灵",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/13deb6e5725d7cbf.json",
      sha256: "d031425ec7f53f4772d748d79fe4961cb4922e763d4e081b9158905ba4966730",
      fields: {
        ruleType: "Y",
        identityCounts: {
          主谋: "①",
          邪教徒: "①"
        },
        effect: "【失败条件：轮回结束时】神社有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "f5311165dde3b452",
      name: "和我签订契约吧！",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/f5311165dde3b452.json",
      sha256: "7a66d727a186c72f099646dd21b8e90a4d4738c2dd3b237232ab2bd61fd1e0e7",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①"
        },
        effect: "【强制：剧本制作时】关键人物必须有少女属性\n【失败条件：轮回结束时】关键人物有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "2771159334630d3b",
      name: "改变未来",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/2771159334630d3b.json",
      sha256: "53033ca72cde0a90aa2f5754ef2e4af340ea6dae071294dcf185ecb9a2e70b66",
      fields: {
        ruleType: "Y",
        identityCounts: {
          邪教徒: "①",
          时间旅者: "①"
        },
        effect: "【失败条件：轮回结束时】本轮轮回中引发过蝴蝶效应事件"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "6f8edd5a6f96688b",
      name: "巨大定时炸弹X",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/6f8edd5a6f96688b.json",
      sha256: "caa0d69661d8ffa0526d7f0f358f60f059dd20b7248af29eecf6bd43c46123fe",
      fields: {
        ruleType: "Y",
        identityCounts: {
          魔女: "①"
        },
        effect: "【失败条件：轮回结束时】魔女的初始区域有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "cdf29a749f513669",
      name: "好友圈",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/cdf29a749f513669.json",
      sha256: "ced6c14ad07dbc47f3dfca5e6c7752771cf80ab9120a52c2aa5ddc99029290f0",
      fields: {
        ruleType: "X",
        identityCounts: {
          亲友: "②",
          传谣人: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "2ec6053237385cf9",
      name: "恋爱风景线",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/2ec6053237385cf9.json",
      sha256: "e1f5a974a084585f52b97131d59849c4994d28555cd86cb1a00c4fa61c70c1cb",
      fields: {
        ruleType: "X",
        identityCounts: {
          心上人: "①",
          求爱者: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "6024eb416ca1ad89",
      name: "潜伏的杀人狂",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/6024eb416ca1ad89.json",
      sha256: "51e088b3c54c632d1eb8ddc435fa1c7a849a41e44c316beae535df87101a18aa",
      fields: {
        ruleType: "X",
        identityCounts: {
          亲友: "①",
          杀人狂: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "5dfad689bca7fed4",
      name: "流言四起",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/5dfad689bca7fed4.json",
      sha256: "ab5648cc700420c2d41970255b0cd1e6cb2177ca3925f536785a97a2ed18a690",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【任意能力：剧作家能力阶段】往任意1块版图上放置1枚[密谋]（每轮限1次）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "081aa327f8b5d970",
      name: "妄想扩大病毒",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/081aa327f8b5d970.json",
      sha256: "045530f97202908dc1ddc2a41dd018208dc1ad1d8970b66843ad62a29eca2df1",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【强制：常驻】某1名平民角色有3枚或以上[不安]时，那名平民身份变为杀人狂"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "9d51f3526f0e04db",
      name: "因果线",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/9d51f3526f0e04db.json",
      sha256: "7b70ea561e696fe4f31586c575c290d0e18f34ff06bbce8b9366b943e1273f14",
      fields: {
        ruleType: "X",
        identityCounts: {},
        effect: "【强制：轮回开始时】上轮轮回结束时所有带有[友好]的角色，全部放置2枚[不安]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "e8b229f97a02039a",
      name: "未知因子Χ",
      kind: "rules",
      module: "BTX",
      source: "facts/data/rules/e8b229f97a02039a.json",
      sha256: "e977e9d91dafa17c5387ecfe1f8f2ef5a310081f60ea0cc8b945b3b202440e1a",
      fields: {
        ruleType: "X",
        identityCounts: {
          不安定因子: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "f1c5656abe730cbb",
      name: "关键人物",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/f1c5656abe730cbb.json",
      sha256: "0ac37122fe6d7067dea1e9eb55e9e0d81e2d3af11c25a0adbc4dfbb3e0af0e8a",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "b942a9c5a836090e",
      name: "杀手",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/b942a9c5a836090e.json",
      sha256: "9a829888558cbe248a8eec40ae687c73626b020d8a76f4e95c6edd8d23c8ba72",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：回合结束阶段】同一区域1名关键人物身上有2枚或以上[密谋]→那名关键人物死亡",
          "【任意能力：回合结束阶段】该角色身上有4枚或以上[密谋]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "9476024c27bf57f6",
      name: "主谋",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/9476024c27bf57f6.json",
      sha256: "087b9f90213cc6b7d76d68ee67d0137e19509848322cca8587aeaee591fa1d53",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域任意一名角色身上，或该角色所在的版图上放置1枚[密谋]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "d68399117069fd1c",
      name: "邪教徒",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/d68399117069fd1c.json",
      sha256: "676b724fd3bf8024852b5f8fa619ccc2856aaf335589c50cae56a66cd3718894",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【任意能力：行动结算阶段】可以无效化同一区域中任意角色身上和该角色所在版图上放置的禁止密谋"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "e5a629e8624e1bb4",
      name: "魔女",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/e5a629e8624e1bb4.json",
      sha256: "4443b249d40325e887acc6aa805b5c1a9a0ee18ab779b86820895af7aa70344a",
      fields: {
        max: "",
        traits: "必定无视友好"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "34ab981ff12c746a",
      name: "时间旅者",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/34ab981ff12c746a.json",
      sha256: "5db878c0f0ca71b95f28db5a1607cb0a8a9f17ae495681580efaec1f21ceb876",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【强制：行动结算阶段】无视该角色身上放置的禁止友好",
          "【任意能力：最终日的回合结束阶段】该角色身上的[友好]为2枚或以下→主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "cf76a8767153fd13",
      name: "亲友",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/cf76a8767153fd13.json",
      sha256: "cd2bf8a5433e18272c56a38839f57b0b986e9319e5c67091160cce2f96598696",
      fields: {
        max: "②",
        traits: "",
        abilities: [
          "【失败条件：轮回结束时】该卡牌为死亡状态，此时，需要告知主人公该卡牌的身份",
          "【强制：轮回开始时】该角色身份曾被公开→往该角色身上放置1枚[友好]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "074458611582a4ff",
      name: "心上人",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/074458611582a4ff.json",
      sha256: "47346c6d8f7262277229d984f07177449418b1f8e590f7756653e1d4b0aeb38c",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：求爱者死亡时】往该角色身上放置6枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "1337573434379ef9",
      name: "求爱者",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/1337573434379ef9.json",
      sha256: "ad04ec8b4b27c9e139eb613393a6368c41795e35e1b406e661d3f74e58ff8d5f",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：心上人死亡时】往该角色身上放置6枚[不安]",
          "【任意能力：回合结束阶段】该角色身上有1枚或以上[密谋]且有3枚或以上[不安]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "fb09f2ef11754876",
      name: "杀人狂",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/fb09f2ef11754876.json",
      sha256: "883cfda1165d380f073fa4038d71f2c2ff6085a28a8436428e2722061d14dcbd",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "f3453478ef863e73",
      name: "不安定因子",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/f3453478ef863e73.json",
      sha256: "6491be11520bbdc463f7288b71569e912bffbcc71800fe3093830ad8f48e307c",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【强制：常驻】学校有2枚或以上[密谋]→该角色获得传谣人的能力（身份依然为[不安定因子]）",
          "【强制：常驻】都市有2枚或以上[密谋]→该角色获得关键人物的能力（身份依然为[不安定因子]）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "27cc906490dd3178",
      name: "传谣人",
      kind: "identities",
      module: "BTX",
      source: "facts/data/identities/27cc906490dd3178.json",
      sha256: "9f169bf22b0f427362254b0b6bae2c5e94198841489e8bd931c8cc8fc3f96878",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "72ab7658e70f3652",
      name: "不安扩散",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/72ab7658e70f3652.json",
      sha256: "1392e496cb2aacc552fc46344140fb4da0f92f7c1105d399ef01a8a849299b2b",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "d8b502473732b504",
      name: "谋杀",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/d8b502473732b504.json",
      sha256: "cf81941cb6d894520db907068c5b24d1e2109cf3ad69705cd7ed909c357fbc25",
      fields: {
        effect: "与当事人位于同一区域的另外1名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "ecc3824a2e25ff40",
      name: "邪气污染",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/ecc3824a2e25ff40.json",
      sha256: "ab349d37ebd61fdbdf80fb810e043ca9f8abd0d6c1a2c1696c829df73d71522e",
      fields: {
        effect: "往神社放置2枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "62be423c7130d75f",
      name: "医院事故",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/62be423c7130d75f.json",
      sha256: "c7a0d08be4d43cc51c3afe2ee139d96e6d2b5c7a02536aaa8ef04ed6e2d038c1",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "2c8e02c971cdc513",
      name: "自杀",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/2c8e02c971cdc513.json",
      sha256: "249998c70eee87a259fdaff570a8a552ae2bd22944c9d0e7fd43afd169a95696",
      fields: {
        effect: "当事人死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "831c2100a39d727b",
      name: "散播",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/831c2100a39d727b.json",
      sha256: "30bac8144e4ffd48b5ba6a387f588cbcf295bed202308b9e53357765b23487da",
      fields: {
        effect: "从任意1名角色身上移除2枚[友好]，随后往另外1名角色身上放置2枚[友好]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "ff147a9704d53ca6",
      name: "蝴蝶效应",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/ff147a9704d53ca6.json",
      sha256: "447fc40949713eaf1e65341b71712001cc688674dd13363857e3edfbe3c56a62",
      fields: {
        effect: "选择与当事人位于同一区域的任意1名角色，往该角色身上放置1枚[友好]、[不安]或[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "9878a9b77a58791d",
      name: "失踪",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/9878a9b77a58791d.json",
      sha256: "4429cfbce2c2d99b0d3cc917a9a54ed5170cdc1010323fee7c559865b8a9153a",
      fields: {
        effect: "将当事人移动至任意版图，随后，往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "77c898b85bb3890a",
      name: "远距离杀人",
      kind: "incidents",
      module: "BTX",
      source: "facts/data/incidents/77c898b85bb3890a.json",
      sha256: "917ce28f830e202ac805f12939fd06fe1c4f00b12a9569098231dfb6dad4135f",
      fields: {
        effect: "任意1名身上有2枚或以上[密谋]的角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "6f0578791db17b8c",
      name: "偶像",
      kind: "characters",
      module: null,
      source: "facts/data/characters/6f0578791db17b8c.json",
      sha256: "8612c4a0d63ddf31d2c921d894f43e271ae919f5fdbc832dcdbdc6a560595a6a",
      fields: {
        角色名: "偶像",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "学生",
          "少女"
        ],
        友好能力: [
          {
            text: "（友好3）移除同一區域另1名角色身上的1枚不安指示物。",
            threshold: 3,
            limitText: ""
          },
          {
            text: "（友好4）往同一區域另1名角色身上放置1枚友好指示物。",
            threshold: 4,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%81%B6%E5%83%8F",
          snapshot: "sources/wiki/pages/133298829766fbb0.json",
          capturedAt: "2026-09-27T03:30:34.092Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%81%B6%E5%83%8F",
          snapshot: "sources/wiki/pages/133298829766fbb0.json",
          capturedAt: "2026-09-27T03:30:34.092Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%81%B6%E5%83%8F",
          snapshot: "sources/wiki/pages/133298829766fbb0.json",
          capturedAt: "2026-09-27T03:30:34.092Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%81%B6%E5%83%8F",
          snapshot: "sources/wiki/pages/133298829766fbb0.json",
          capturedAt: "2026-09-27T03:30:34.092Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%81%B6%E5%83%8F",
          snapshot: "sources/wiki/pages/133298829766fbb0.json",
          capturedAt: "2026-09-27T03:30:34.092Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%81%B6%E5%83%8F",
          snapshot: "sources/wiki/pages/133298829766fbb0.json",
          capturedAt: "2026-09-27T03:30:34.092Z"
        }
      }
    },
    {
      id: "967cc8bdcbd3f0c9",
      name: "媒体人",
      kind: "characters",
      module: null,
      source: "facts/data/characters/967cc8bdcbd3f0c9.json",
      sha256: "6723a43109edec8bef38b54dab12fb029be1566bd4ae10a8e625565ab740c85c",
      fields: {
        角色名: "媒体人",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "成人",
          "男性"
        ],
        友好能力: [
          {
            text: "（友好2）往另外1名角色身上放置1枚不安指示物。",
            threshold: 2,
            limitText: ""
          },
          {
            text: "（友好2）往同一區域任意1名角色身上，或者该角色所在版图上放置1枚密謀指示物。",
            threshold: 2,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AA%92%E9%AB%94%E4%BA%BA",
          snapshot: "sources/wiki/pages/17bd4b4afdac7dfc.json",
          capturedAt: "2026-09-27T03:31:51.261Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AA%92%E9%AB%94%E4%BA%BA",
          snapshot: "sources/wiki/pages/17bd4b4afdac7dfc.json",
          capturedAt: "2026-09-27T03:31:51.261Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AA%92%E9%AB%94%E4%BA%BA",
          snapshot: "sources/wiki/pages/17bd4b4afdac7dfc.json",
          capturedAt: "2026-09-27T03:31:51.261Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AA%92%E9%AB%94%E4%BA%BA",
          snapshot: "sources/wiki/pages/17bd4b4afdac7dfc.json",
          capturedAt: "2026-09-27T03:31:51.261Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AA%92%E9%AB%94%E4%BA%BA",
          snapshot: "sources/wiki/pages/17bd4b4afdac7dfc.json",
          capturedAt: "2026-09-27T03:31:51.261Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%AA%92%E9%AB%94%E4%BA%BA",
          snapshot: "sources/wiki/pages/17bd4b4afdac7dfc.json",
          capturedAt: "2026-09-27T03:31:51.261Z"
        }
      }
    },
    {
      id: "3f42477befd228cc",
      name: "御神木",
      kind: "characters",
      module: null,
      source: "facts/data/characters/3f42477befd228cc.json",
      sha256: "3c0b1e849ee69802a78f41d4e4a9917c59b71f61fee156b709f5971c4819bf2d",
      fields: {
        角色名: "御神木",
        初始区域: "神社",
        禁行区域: "学校 都市 医院",
        不安限度: "4",
        属性: [
          "植物"
        ],
        特性: "主人公在每个回合的主人公能力阶段，可以将该角色身上的1枚指示物移动至同一区域的另外1名角色身上。如果该角色带有无视友好的特性，剧作家必须在剧作家能力阶段使用此特性（强制）"
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%A1%E7%A5%9E%E6%9C%A8",
          snapshot: "sources/wiki/pages/18393f4b04965e9b.json",
          capturedAt: "2026-09-27T03:32:46.492Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%A1%E7%A5%9E%E6%9C%A8",
          snapshot: "sources/wiki/pages/18393f4b04965e9b.json",
          capturedAt: "2026-09-27T03:32:46.492Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%A1%E7%A5%9E%E6%9C%A8",
          snapshot: "sources/wiki/pages/18393f4b04965e9b.json",
          capturedAt: "2026-09-27T03:32:46.492Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%A1%E7%A5%9E%E6%9C%A8",
          snapshot: "sources/wiki/pages/18393f4b04965e9b.json",
          capturedAt: "2026-09-27T03:32:46.492Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%A1%E7%A5%9E%E6%9C%A8",
          snapshot: "sources/wiki/pages/18393f4b04965e9b.json",
          capturedAt: "2026-09-27T03:32:46.492Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%A1%E7%A5%9E%E6%9C%A8",
          snapshot: "sources/wiki/pages/18393f4b04965e9b.json",
          capturedAt: "2026-09-27T03:32:46.492Z"
        }
      }
    },
    {
      id: "9a94e2aba290319f",
      name: "军人",
      kind: "characters",
      module: null,
      source: "facts/data/characters/9a94e2aba290319f.json",
      sha256: "e582dd0913e938892aeb411945164ffd872a9978d4d844ea175cfa5328ac9a6e",
      fields: {
        角色名: "军人",
        初始区域: "医院",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "男性",
          "成人"
        ],
        友好能力: [
          {
            text: "（友好2 1L1）往同一區域任意1名角色身上放置2枚不安指示物。",
            threshold: 2,
            limitText: "1L1",
            oncePerLoop: true
          },
          {
            text: "（友好5 1L1）本輪輪迴中，主人公不會死亡。",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BB%8D%E4%BA%BA",
          snapshot: "sources/wiki/pages/1f04cee2d52c126f.json",
          capturedAt: "2026-09-27T03:34:28.771Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BB%8D%E4%BA%BA",
          snapshot: "sources/wiki/pages/1f04cee2d52c126f.json",
          capturedAt: "2026-09-27T03:34:28.771Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BB%8D%E4%BA%BA",
          snapshot: "sources/wiki/pages/1f04cee2d52c126f.json",
          capturedAt: "2026-09-27T03:34:28.771Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BB%8D%E4%BA%BA",
          snapshot: "sources/wiki/pages/1f04cee2d52c126f.json",
          capturedAt: "2026-09-27T03:34:28.771Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BB%8D%E4%BA%BA",
          snapshot: "sources/wiki/pages/1f04cee2d52c126f.json",
          capturedAt: "2026-09-27T03:34:28.771Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BB%8D%E4%BA%BA",
          snapshot: "sources/wiki/pages/1f04cee2d52c126f.json",
          capturedAt: "2026-09-27T03:34:28.771Z"
        }
      }
    },
    {
      id: "6bcb295b44e53184",
      name: "AI",
      kind: "characters",
      module: null,
      source: "facts/data/characters/6bcb295b44e53184.json",
      sha256: "6a981657e1189c510e79db242a5d49fb586814a0ba827c90fd483b74dcbdd5fc",
      fields: {
        角色名: "A.I.",
        初始区域: "都市",
        禁行区域: "神社 医院 学校",
        不安限度: "4",
        属性: [
          "造物"
        ],
        特性: "剧本制作时，该角色不能为“平民”。\n\n判定该角色为当事人的事件是否发生时，该角色身上的所有指示物都视作不安指示物。",
        友好能力: [
          {
            text: "（友好3 1L1）选择公开信息表中记述的1个事件，处理该事件的效果。处理时，当事人默认为A.I.，且一切需要剧作家决定的内容由队长代为决定（所选事件本身不视作已发生）。",
            threshold: 3,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/A.I.",
          snapshot: "sources/wiki/pages/2f5700a082215a9b.json",
          capturedAt: "2026-09-27T03:28:18.256Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/A.I.",
          snapshot: "sources/wiki/pages/2f5700a082215a9b.json",
          capturedAt: "2026-09-27T03:28:18.256Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/A.I.",
          snapshot: "sources/wiki/pages/2f5700a082215a9b.json",
          capturedAt: "2026-09-27T03:28:18.256Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/A.I.",
          snapshot: "sources/wiki/pages/2f5700a082215a9b.json",
          capturedAt: "2026-09-27T03:28:18.256Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/A.I.",
          snapshot: "sources/wiki/pages/2f5700a082215a9b.json",
          capturedAt: "2026-09-27T03:28:18.256Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/A.I.",
          snapshot: "sources/wiki/pages/2f5700a082215a9b.json",
          capturedAt: "2026-09-27T03:28:18.256Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/A.I.",
          snapshot: "sources/wiki/pages/2f5700a082215a9b.json",
          capturedAt: "2026-09-27T03:28:18.256Z"
        }
      }
    },
    {
      id: "ff7a5b572d8e564f",
      name: "从者",
      kind: "characters",
      module: null,
      source: "facts/data/characters/ff7a5b572d8e564f.json",
      sha256: "a763396d33c5639ef6f355f797be1944d5616d039984de9ed387a0523cda424f",
      fields: {
        角色名: "从者",
        初始区域: "学校/都市（由剧本规定）",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "成人",
          "女性"
        ],
        特性: "同一區域的大人物或大小姐移動時，无视自身移动并跟隨那名角色移動（如果多名角色同時移動，由主人公選擇跟隨哪名角色）。同一區域的大人物或大小姐死亡時，代替那名角色死亡",
        友好能力: [
          {
            text: "（友好4 1L1）选择场上的另外1名角色，本轮轮回中，将那名角色追加至特性适用对象中。",
            threshold: 4,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%9E%E8%80%85",
          snapshot: "sources/wiki/pages/3021eeaa7071de48.json",
          capturedAt: "2026-09-27T03:32:43.741Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%9E%E8%80%85",
          snapshot: "sources/wiki/pages/3021eeaa7071de48.json",
          capturedAt: "2026-09-27T03:32:43.741Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%9E%E8%80%85",
          snapshot: "sources/wiki/pages/3021eeaa7071de48.json",
          capturedAt: "2026-09-27T03:32:43.741Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%9E%E8%80%85",
          snapshot: "sources/wiki/pages/3021eeaa7071de48.json",
          capturedAt: "2026-09-27T03:32:43.741Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%9E%E8%80%85",
          snapshot: "sources/wiki/pages/3021eeaa7071de48.json",
          capturedAt: "2026-09-27T03:32:43.741Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%9E%E8%80%85",
          snapshot: "sources/wiki/pages/3021eeaa7071de48.json",
          capturedAt: "2026-09-27T03:32:43.741Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%BE%9E%E8%80%85",
          snapshot: "sources/wiki/pages/3021eeaa7071de48.json",
          capturedAt: "2026-09-27T03:32:43.741Z"
        }
      }
    },
    {
      id: "41c9f4988cb593f5",
      name: "情报商",
      kind: "characters",
      module: null,
      source: "facts/data/characters/41c9f4988cb593f5.json",
      sha256: "b7e7bc3e79c54908e63840c5ba8ce0ec709105c1fa8ee562fb33289a64c8becc",
      fields: {
        角色名: "情报商",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "女性",
          "成人"
        ],
        友好能力: [
          {
            text: "（友好5 1L1）聲明1條規則X的名稱。劇作家從當前剧本所选用的規則X中，公開1条主人公未聲明的規則X。",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%83%85%E5%A0%B1%E5%95%86",
          snapshot: "sources/wiki/pages/31f316c77f6c5900.json",
          capturedAt: "2026-09-27T03:32:49.676Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%83%85%E5%A0%B1%E5%95%86",
          snapshot: "sources/wiki/pages/31f316c77f6c5900.json",
          capturedAt: "2026-09-27T03:32:49.676Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%83%85%E5%A0%B1%E5%95%86",
          snapshot: "sources/wiki/pages/31f316c77f6c5900.json",
          capturedAt: "2026-09-27T03:32:49.676Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%83%85%E5%A0%B1%E5%95%86",
          snapshot: "sources/wiki/pages/31f316c77f6c5900.json",
          capturedAt: "2026-09-27T03:32:49.676Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%83%85%E5%A0%B1%E5%95%86",
          snapshot: "sources/wiki/pages/31f316c77f6c5900.json",
          capturedAt: "2026-09-27T03:32:49.676Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%83%85%E5%A0%B1%E5%95%86",
          snapshot: "sources/wiki/pages/31f316c77f6c5900.json",
          capturedAt: "2026-09-27T03:32:49.676Z"
        }
      }
    },
    {
      id: "c2f23a768f77fc42",
      name: "上位存在",
      kind: "characters",
      module: null,
      source: "facts/data/characters/c2f23a768f77fc42.json",
      sha256: "095f5cbac85eaa95d2df1220d9d7f97038cab314fb46f54bb5017553deb75542",
      fields: {
        角色名: "上位存在",
        初始区域: "神社",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "少女"
        ],
        友好能力: [
          {
            text: "（友好3 1L1）往同一区域任意1名角色身上放置1枚希望/绝望指示物。如果该角色具有無視友好的特性，並且身上已经放置了1枚或以上的友好指示物，則劇作家可以在劇作家能力階段使用該能力。",
            threshold: 3,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%B8%8A%E4%BD%8D%E5%AD%98%E5%9C%A8",
          snapshot: "sources/wiki/pages/3661704c634e55f9.json",
          capturedAt: "2026-09-27T03:30:18.830Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%B8%8A%E4%BD%8D%E5%AD%98%E5%9C%A8",
          snapshot: "sources/wiki/pages/3661704c634e55f9.json",
          capturedAt: "2026-09-27T03:30:18.830Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%B8%8A%E4%BD%8D%E5%AD%98%E5%9C%A8",
          snapshot: "sources/wiki/pages/3661704c634e55f9.json",
          capturedAt: "2026-09-27T03:30:18.830Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%B8%8A%E4%BD%8D%E5%AD%98%E5%9C%A8",
          snapshot: "sources/wiki/pages/3661704c634e55f9.json",
          capturedAt: "2026-09-27T03:30:18.830Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%B8%8A%E4%BD%8D%E5%AD%98%E5%9C%A8",
          snapshot: "sources/wiki/pages/3661704c634e55f9.json",
          capturedAt: "2026-09-27T03:30:18.830Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%B8%8A%E4%BD%8D%E5%AD%98%E5%9C%A8",
          snapshot: "sources/wiki/pages/3661704c634e55f9.json",
          capturedAt: "2026-09-27T03:30:18.830Z"
        }
      }
    },
    {
      id: "e1e208328e55db62",
      name: "男学生",
      kind: "characters",
      module: null,
      source: "facts/data/characters/e1e208328e55db62.json",
      sha256: "1a6a5f2cbcec4607fb2fef5b6e088c6e4f73f0a828cf8db72852b853a6974b91",
      fields: {
        角色名: "男學生",
        初始区域: "学校",
        禁行区域: "无",
        不安限度: "２",
        属性: [
          "学生",
          "少年"
        ],
        友好能力: [
          {
            text: "（友好２）移除同一区域另外1名学生身上的1枚不安指示物",
            threshold: 2,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%94%B7%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/3f6dbb415e68b864.json",
          capturedAt: "2026-09-27T03:33:52.966Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%94%B7%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/3f6dbb415e68b864.json",
          capturedAt: "2026-09-27T03:33:52.966Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%94%B7%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/3f6dbb415e68b864.json",
          capturedAt: "2026-09-27T03:33:52.966Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%94%B7%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/3f6dbb415e68b864.json",
          capturedAt: "2026-09-27T03:33:52.966Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%94%B7%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/3f6dbb415e68b864.json",
          capturedAt: "2026-09-27T03:33:52.966Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%94%B7%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/3f6dbb415e68b864.json",
          capturedAt: "2026-09-27T03:33:52.966Z"
        }
      }
    },
    {
      id: "91ce8e3332c20b48",
      name: "临时工",
      kind: "characters",
      module: null,
      source: "facts/data/characters/91ce8e3332c20b48.json",
      sha256: "c6192f3dca0b2a860292d7f956b5f090e4f5812de3c5b3eb5294903cea4b2d53",
      fields: {
        角色名: "临时工",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "1",
        属性: [
          "成人",
          "男性"
        ],
        特性: "该卡牌的身份为平民（无视其原本所配置的身份）。\n\n回合结束阶段，如果该角色总共有3枚或以上的任意指示物，该角色死亡。\n\n回合开始阶段，如果该卡牌为死亡状态，则将临时工？在都市配置上场"
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5",
          snapshot: "sources/wiki/pages/433ef0170b0f9d6b.json",
          capturedAt: "2026-09-27T03:34:10.697Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5",
          snapshot: "sources/wiki/pages/433ef0170b0f9d6b.json",
          capturedAt: "2026-09-27T03:34:10.697Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5",
          snapshot: "sources/wiki/pages/433ef0170b0f9d6b.json",
          capturedAt: "2026-09-27T03:34:10.697Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5",
          snapshot: "sources/wiki/pages/433ef0170b0f9d6b.json",
          capturedAt: "2026-09-27T03:34:10.697Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5",
          snapshot: "sources/wiki/pages/433ef0170b0f9d6b.json",
          capturedAt: "2026-09-27T03:34:10.697Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5",
          snapshot: "sources/wiki/pages/433ef0170b0f9d6b.json",
          capturedAt: "2026-09-27T03:34:10.697Z"
        }
      }
    },
    {
      id: "aa683412aea33245",
      name: "班长",
      kind: "characters",
      module: null,
      source: "facts/data/characters/aa683412aea33245.json",
      sha256: "f350447c072e1da0ff0fefd8fb68df9fafe6060f6f629fb610501737b2c3212c",
      fields: {
        角色名: "班长",
        初始区域: "学校",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "学生",
          "少女"
        ],
        友好能力: [
          {
            text: "（友好2）由队长选择1张属于自己、每轮限1次且已经使用完毕的行动牌，将其收回至手牌",
            threshold: 2,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%8F%AD%E9%95%B7",
          snapshot: "sources/wiki/pages/46166d54006a4691.json",
          capturedAt: "2026-09-27T03:33:50.261Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%8F%AD%E9%95%B7",
          snapshot: "sources/wiki/pages/46166d54006a4691.json",
          capturedAt: "2026-09-27T03:33:50.261Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%8F%AD%E9%95%B7",
          snapshot: "sources/wiki/pages/46166d54006a4691.json",
          capturedAt: "2026-09-27T03:33:50.261Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%8F%AD%E9%95%B7",
          snapshot: "sources/wiki/pages/46166d54006a4691.json",
          capturedAt: "2026-09-27T03:33:50.261Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%8F%AD%E9%95%B7",
          snapshot: "sources/wiki/pages/46166d54006a4691.json",
          capturedAt: "2026-09-27T03:33:50.261Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%8F%AD%E9%95%B7",
          snapshot: "sources/wiki/pages/46166d54006a4691.json",
          capturedAt: "2026-09-27T03:33:50.261Z"
        }
      }
    },
    {
      id: "2ed9391cac88f2b8",
      name: "妹妹",
      kind: "characters",
      module: null,
      source: "facts/data/characters/2ed9391cac88f2b8.json",
      sha256: "a6b9c6904445fc6343c7bbc65a9a0945408e212f7c6ef3690159f7d6a4f95b6f",
      fields: {
        角色名: "妹妹",
        初始区域: "神社",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "少女",
          "妹妹"
        ],
        特性: "剧本制作时，该角色的身份不可以为有无视友好特性的身份",
        友好能力: [
          {
            text: "（友好5）同一区域的1名成人使用1个友好能力，此时无视该成人的友好指示物数量。即使该成人带有无视友好特性，也不能拒绝使用那个能力。但能力依然受到次数限制。",
            threshold: 5,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A6%B9%E5%A6%B9",
          snapshot: "sources/wiki/pages/4a165a95a57dc529.json",
          capturedAt: "2026-09-27T03:31:47.846Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A6%B9%E5%A6%B9",
          snapshot: "sources/wiki/pages/4a165a95a57dc529.json",
          capturedAt: "2026-09-27T03:31:47.846Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A6%B9%E5%A6%B9",
          snapshot: "sources/wiki/pages/4a165a95a57dc529.json",
          capturedAt: "2026-09-27T03:31:47.846Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A6%B9%E5%A6%B9",
          snapshot: "sources/wiki/pages/4a165a95a57dc529.json",
          capturedAt: "2026-09-27T03:31:47.846Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A6%B9%E5%A6%B9",
          snapshot: "sources/wiki/pages/4a165a95a57dc529.json",
          capturedAt: "2026-09-27T03:31:47.846Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A6%B9%E5%A6%B9",
          snapshot: "sources/wiki/pages/4a165a95a57dc529.json",
          capturedAt: "2026-09-27T03:31:47.846Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A6%B9%E5%A6%B9",
          snapshot: "sources/wiki/pages/4a165a95a57dc529.json",
          capturedAt: "2026-09-27T03:31:47.846Z"
        }
      }
    },
    {
      id: "f7c96b28229536d3",
      name: "Weird Mythology",
      kind: "modules",
      module: "WM",
      source: "facts/data/modules/f7c96b28229536d3.json",
      sha256: "d2ef5182801133bde29bf0ac8e9b35324c4b0a09625138be2d956d8484f5267d",
      fields: {
        special: "Weird Mythology 的特殊规则如下\n  每当主人公声明的友好能力被拒绝时，EX槽上升1，EX槽在每轮轮回开始时不清零\n  旧日魔术\n  根据当前的EX槽数值获得效果\n  EX1+：感应咒文\n  在第一天的回合开始阶段，如果Ex槽为1或以上，队长可以选择任意1名角色，并在该角色身上放置2枚友好指示物\n  EX2+：先祖记忆\n  轮回结束时，如果Ex槽为2或以上，可以得知规则X1的规则名\n  EX3+：旧印\n  如果Ex槽为3或以上，同时放置2张或以上[禁止密谋]时，不会无效化\n  此能力在Ex槽达到3时立即生效\n  EX4+：发狂\n  回合结束阶段时，若Ex槽为4或以上，主人公死亡。\n  轮回结束时，若Ex槽为4或以上，失去所有剩余轮回，直接进入最终决战。\n  重重的亵渎知识终于导致主人公们坠入疯狂的深渊"
      },
      provenance: {
        special: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "825f19cc6864b5ce",
      name: "外神合唱曲",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/825f19cc6864b5ce.json",
      sha256: "5d3b27e2b99cec4035240ad4713eb1ee51277ea98b564c1a54c7e4731e1055ef",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          祭品: "①",
          永生者: "①"
        },
        effect: "【失败条件：轮回结束时】5名或以上的生存角色身上均有1枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "81a6fafff333cd2a",
      name: "达贡的福音书",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/81a6fafff333cd2a.json",
      sha256: "3c55407e63b86ee1d73a9c1acff2a9bbcb60f63bd8d1b719299ea868bfec6e59",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          邪教徒: "①",
          深潜者: "①"
        },
        effect: "【失败条件：轮回结束时】神社有X枚或以上[密谋]（X=Ex槽的值）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "1dd60cb9e3c7cbf7",
      name: "黄衣之王",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/1dd60cb9e3c7cbf7.json",
      sha256: "7fecdfd03e4fdec5b1b1ab53271a685b24969d2382c54f5aa104b13430e57e29",
      fields: {
        ruleType: "Y",
        identityCounts: {
          祭品: "①",
          邪教徒: "①"
        },
        effect: "【失败条件：轮回结束时】本轮轮回中Ex槽增加过"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "5037d68864bcaee3",
      name: "巨大定时炸弹Y",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/5037d68864bcaee3.json",
      sha256: "84530de3024dda8245cd72743547d71705fd3178c9171ca17b01fe30ccc20b17",
      fields: {
        ruleType: "Y",
        identityCounts: {
          魔女: "①",
          深潜者: "①"
        },
        effect: "【失败条件：轮回结束时】魔女的初始区域有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "855013a62c19069c",
      name: "染血的仪式",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/855013a62c19069c.json",
      sha256: "625c13da08b98c943f432d3aa9e808f2fe79f1c2453f86ad4518e42b7f211bcc",
      fields: {
        ruleType: "Y",
        identityCounts: {
          魔女: "①",
          永生者: "①"
        },
        effect: "【失败条件：轮回结束时】有X具或以上尸体（X=Ex槽的值）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "9089efdca22fc819",
      name: "流言四起",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/9089efdca22fc819.json",
      sha256: "03596333934ac54d1c80c3a2861b8af06da1fb5741174733739144bcb0c50665",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【任意能力：剧作家能力阶段】往任意1块版图上放置1枚[密谋]（每轮限1次）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "3d3febd49294f432",
      name: "抗争者",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/3d3febd49294f432.json",
      sha256: "0fca70ac5430e8b535981410f79e9fa06f58710f8ed8d4419ed6041afb8a5e07",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          巫师: "①",
          杀人狂: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "e72e87614b0af55a",
      name: "见证恐惧",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/e72e87614b0af55a.json",
      sha256: "2081fbc91e54702c756ca367373a88829dc2e7f60cb6cbf74310b6f8a60772bc",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          目击者: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "d1548125354c6074",
      name: "伊斯之伟大种族",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/d1548125354c6074.json",
      sha256: "ffd4bc20c46fb765651a2bb3f29269c0225c8b4baf41761b2dae03a3b2b7de61",
      fields: {
        ruleType: "X",
        identityCounts: {
          杀人狂: "①",
          时间旅者: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "e6050d8d62682379",
      name: "深渊之都的私语",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/e6050d8d62682379.json",
      sha256: "eb699c359d6525374858864ace6bbd7838621b47c173c9672a9f33afd4dbab3d",
      fields: {
        ruleType: "X",
        identityCounts: {
          深潜者: "①",
          偏执狂: "①"
        },
        effect: "【强制：常驻】偏执狂获得关键人物的能力（身份不发生变化）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "489d65c951a22237",
      name: "无貌之神",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/489d65c951a22237.json",
      sha256: "e7b316655fba7b04bcef8ee9fa90acaa225dc935848e8ea1d9c034d846276f32",
      fields: {
        ruleType: "X",
        identityCounts: {
          巫师: "①",
          无面者: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "82a2aaf3c6d55784",
      name: "疯狂的真相",
      kind: "rules",
      module: "WM",
      source: "facts/data/rules/82a2aaf3c6d55784.json",
      sha256: "ad72e373af9b55b696f99e68db96ce16d18dc6f78e9eaceace7901cb93c05b26",
      fields: {
        ruleType: "X",
        identityCounts: {
          偏执狂: "①"
        },
        effect: "【强制：轮回开始时】Ex槽为2或以上→本轮轮回中，规则Y指定的失败条件变更为（剧本事先设定的）另一条规则Y的失败条件\n【强制：剧本制作时】情报商必须登场"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "598b034586fe404d",
      name: "关键人物",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/598b034586fe404d.json",
      sha256: "4eed923dc2ae794f94870a84a986a6d011cec3462d7cf761d4dd3105c1d2711a",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "a757930d06d97350",
      name: "祭品",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/a757930d06d97350.json",
      sha256: "0fbb21e104421c677d807cb5bd5dc2b6e4b10094f438d8074164f1fccab00230",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【任意能力：回合结束阶段】该角色身上有2枚或以上[密谋]且有2枚或以上[不安]→所有角色和主人公死亡",
          "【强制：事件阶段】判定该角色为当事人的事件是否触发时，[密谋]视为[不安]处理",
          "【强制：剧本制作时】必须成为某1个事件的当事人"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "1c923de7300e8655",
      name: "邪教徒",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/1c923de7300e8655.json",
      sha256: "9d78a91552f0d4c5a420094eaab332f6045a07038d39dc1bdb9895ab7c0b3aa5",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【任意能力：行动结算阶段】可以无效化同一区域中任意角色身上和该角色所在版图上放置的禁止密谋"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "5f47026667c7a802",
      name: "魔女",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/5f47026667c7a802.json",
      sha256: "dd4f4e6eb451ad06f454869a0e10b48e23df4026171dc7fd1b053c7f465b85d1",
      fields: {
        max: "",
        traits: "必定无视友好"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "a88159f182a6befc",
      name: "永生者",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/a88159f182a6befc.json",
      sha256: "4cc9f3ae94c315c523d2a251014aafe735fbf764c32d0ae6025a14a65ff7bac8",
      fields: {
        max: "",
        traits: "不死"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "bafb13e517e76c77",
      name: "深潜者",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/bafb13e517e76c77.json",
      sha256: "32b9ef9c728ea96f3a3a56f79ae517f80cf84742b4e55261acec6149bf44569f",
      fields: {
        max: "①",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域任意一名角色身上，或该角色所在的版图上放置1枚[密谋]",
          "【强制：该角色死亡时】公开该角色身份，Ex槽增加1"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "87ddbe3d1a86cb5c",
      name: "传谣人",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/87ddbe3d1a86cb5c.json",
      sha256: "326214043126f03498ab40bff3b65b0cc613e62230366642ff2cddd0f8d73883",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "7e7d3d495f6a9e39",
      name: "偏执狂",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/7e7d3d495f6a9e39.json",
      sha256: "48588843523d101fe25e7311f5397790ab7da5cf8a5b48e7f7498128a6c37024",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往该角色身上放置1枚[密谋]或[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "d076d32c50552474",
      name: "巫师",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/d076d32c50552474.json",
      sha256: "2f0b057807f2a209cc1523054a93af63180f6dbab2edcdc1a4f4c567c3e3cd06",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【失败条件：轮回结束时】该卡牌为死亡状态",
          "【强制：结算该角色友好能力后】公开该角色身份，之后，队长可以使Ex槽增加1"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "9124f417c3ea7fed",
      name: "杀人狂",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/9124f417c3ea7fed.json",
      sha256: "0b8e7407f3440a8aac946841f4d452016e92223a6a9a7069bf2a3b6046acdfaf",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "0fdf37f6d533f768",
      name: "时间旅者",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/0fdf37f6d533f768.json",
      sha256: "b3657f5577609d2d533404252fa99247bdd916905902ef5b879e21625f1a5602",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【强制：行动结算阶段】无视该角色身上放置的禁止友好",
          "【任意能力：最终日的回合结束阶段】该角色身上的[友好]为2枚或以下→主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "b1f8d99a9e64bd59",
      name: "目击者",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/b1f8d99a9e64bd59.json",
      sha256: "95fe44ab5ebe99c3ff5f0332f09c30f8bcacf3e716277abcc19f547f181d2472",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】该角色有4枚或以上[不安]→该角色死亡，Ex槽增加1"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "712479caa1fe8f93",
      name: "无面者",
      kind: "identities",
      module: "WM",
      source: "facts/data/identities/712479caa1fe8f93.json",
      sha256: "2b9e88500aa595e385b5376464b29e31ad4cc47707ec5bb08aaa6228ecdc5d3a",
      fields: {
        max: "",
        traits: "不死\n\n无视友好",
        abilities: [
          "【强制：常驻】Ex槽为1或以下→该角色获得传谣人的能力（身份不发生变化）",
          "【强制：常驻】Ex槽为2或以上→该角色获得深潜者的能力（身份不发生变化）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "b3f917e458adf5c1",
      name: "疯狂杀人",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/b3f917e458adf5c1.json",
      sha256: "f823ee704df1c8af9dbd0a4a6ac3e7badca31410904e4c3fcb031e8d4d2e2c26",
      fields: {
        effect: "与当事人位于同一区域的1名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "ac9a42d05391d1f6",
      name: "集体自杀",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/ac9a42d05391d1f6.json",
      sha256: "8fa4a0a30fbb2021047b44e205c10468e453b0fc5b6f7674bc3a3c9ff625b6ea",
      fields: {
        effect: "当事人有1枚或以上[密谋]→当事人所在区域的所有角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "6e0f6f239a2c2f3c",
      name: "不安扩散",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/6e0f6f239a2c2f3c.json",
      sha256: "62fd5db31cfec9a78b44385c01fd9df0cad20e04e36661e5f9cad493722df7a7",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "3190cef688901264",
      name: "失踪",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/3190cef688901264.json",
      sha256: "43902ff5a058e475353aa026da8ae94f1f2d2b70b59a8bab451016e5c6040ab0",
      fields: {
        effect: "将当事人移动至任意版图，随后，往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "86b44b4131f32f5a",
      name: "邪气污染",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/86b44b4131f32f5a.json",
      sha256: "e2ff6d6947a299559e51b7995e8953d3d005227c6d49069f3767f198dcd69cc3",
      fields: {
        effect: "往神社放置2枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "f2cad97689a31015",
      name: "医院事故",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/f2cad97689a31015.json",
      sha256: "3421b540ce002c0e9bbd4f78cd86d6e18ca76803e7a97ab3bffc157e11d659db",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "38189941423ae337",
      name: "暴乱",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/38189941423ae337.json",
      sha256: "c554cab98694ba7989cc245536fbb13576df38009c7dba4f79ee39246d3d429b",
      fields: {
        effect: "都市有1枚或以上[密谋]→位于都市的所有角色死亡\n学校有1枚或以上[密谋]→位于学校的所有角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "2f52abbc953fd963",
      name: "灭绝之火",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/2f52abbc953fd963.json",
      sha256: "8147ad5dab9c252083139eb03e91885b6919b26d4aa61af55cf34f08ce68d0dc",
      fields: {
        effect: "本局游戏中若本事件首次发生→所有角色和主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "a53a44f99a6e5e82",
      name: "廷达罗斯之嗅",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/a53a44f99a6e5e82.json",
      sha256: "22a137b51fb4f1da892208cd4597959b3a1c86a3fd1e10d84c1ffd45c0700ac6",
      fields: {
        effect: "<通过密谋指示物数量判定是否发生>本轮轮回剩余时间，如果发生其他事件，则在那个事件阶段结束时，主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "55291c34be17e47a",
      name: "发现",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/55291c34be17e47a.json",
      sha256: "11e0b0a5cd64cf83a1ac69dbbd1a0328026500969ce98283e1bdda8b8e9a453b",
      fields: {
        effect: "Ex槽增加1"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "b3e0d8a13767573f",
      name: "送葬",
      kind: "incidents",
      module: "WM",
      source: "facts/data/incidents/b3e0d8a13767573f.json",
      sha256: "59c7bbba457133cdb46c1cfb12c969341d18c6aa189f9cffb0db3d13230184fb",
      fields: {
        effect: "<当事人不安限度-1>队长选择1名角色，那名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Weird_Mythology",
          snapshot: "sources/wiki/pages/4d608cef3c4485cd.json",
          capturedAt: "2026-09-27T03:30:15.425Z"
        }
      }
    },
    {
      id: "1a4ec21b9d7bb05f",
      name: "大人物",
      kind: "characters",
      module: null,
      source: "facts/data/characters/1a4ec21b9d7bb05f.json",
      sha256: "1d2fb83f47aa170b475eb808e31b7e3fda03fa9ee30c6ae2a4970d0a34cf81a4",
      fields: {
        角色名: "大人物",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "4",
        属性: [
          "成人",
          "男性"
        ],
        特性: "劇本製作時，指定1块版图，將領地標誌放置在該版图。本局遊戲中，所選定的版图視作大人物的領地。劇作家在使用該角色的能力時，可以將領地視作該角色所在區域。",
        友好能力: [
          {
            text: "（友好5 1L1）公開領地中另外1名角色的身份。",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E4%BA%BA%E7%89%A9",
          snapshot: "sources/wiki/pages/552f01a9ed48e3a3.json",
          capturedAt: "2026-09-27T03:31:39.560Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E4%BA%BA%E7%89%A9",
          snapshot: "sources/wiki/pages/552f01a9ed48e3a3.json",
          capturedAt: "2026-09-27T03:31:39.560Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E4%BA%BA%E7%89%A9",
          snapshot: "sources/wiki/pages/552f01a9ed48e3a3.json",
          capturedAt: "2026-09-27T03:31:39.560Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E4%BA%BA%E7%89%A9",
          snapshot: "sources/wiki/pages/552f01a9ed48e3a3.json",
          capturedAt: "2026-09-27T03:31:39.560Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E4%BA%BA%E7%89%A9",
          snapshot: "sources/wiki/pages/552f01a9ed48e3a3.json",
          capturedAt: "2026-09-27T03:31:39.560Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E4%BA%BA%E7%89%A9",
          snapshot: "sources/wiki/pages/552f01a9ed48e3a3.json",
          capturedAt: "2026-09-27T03:31:39.560Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E4%BA%BA%E7%89%A9",
          snapshot: "sources/wiki/pages/552f01a9ed48e3a3.json",
          capturedAt: "2026-09-27T03:31:39.560Z"
        }
      }
    },
    {
      id: "7580de694ee21043",
      name: "Another Horizon Revised",
      kind: "modules",
      module: "AHR",
      source: "facts/data/modules/7580de694ee21043.json",
      sha256: "85d2f424fe1bf49923cc023ba9a7cdb67f49c7c314bb2a42e2097de4550ef247",
      fields: {
        special: "Another Horizon Revised 的特殊规则如下\n  表世界与里世界\n  每轮轮回开始时EX槽为0。根据目前ex槽的奇偶性判定世界线，偶数代表当前位于表世界，奇数代表位于里世界。\n  如果当天进行过世界移动（无论几次），则在当天的回合结束阶段开始时，提升1点ex槽。（优先于杀人狂等强制判定）\n  除了模组中提到的世界移动之外，每轮限1次的友好能力正常处理完毕之后，也会进行世界移动。\n  心境反转\n  在里世界时，不安指示物与友好指示物效果按如下替换：\n  通过友好指示物数量判定事件是否发生，通过不安指示物数量判定是否能够使用友好能力。\n  傀儡无视友好\n  傀儡无视友好是无视友好特性的一种\n  在无视友好特性的基础上，剧作家可以在剧作家能力阶段使用带有该特性的角色的友好能力（需满足对应的指示物数量条件）。此时，剧作家必须明确声明使用能力的角色和目标。\n  可变身份\n  在规则与身份一览表中，如果某条规则中带有表/里字样，则代表在同1名角色上分配了诸如强迫症/关键人物这样的身份\n  该卡牌在表世界为强迫症，里世界为关键人物，最终决战时需要明确指出该角色表里两个世界的身份。\n  初始手牌变更\n  在AHR模组中，主人公在轮回开始时会额外获得不安+2，剧作家会在轮回开始时额外获得友好+1，并且在第一轮轮回开始时额外获得绝望+1"
      },
      provenance: {
        special: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "764b0651c9eaeda9",
      name: "闭锁的未来",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/764b0651c9eaeda9.json",
      sha256: "a1da75bae98d5a1faea47c202310b2f5fadea12f6d6420197f71a6d4cc3befc4",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "里",
          强迫症: "表",
          提线木偶: "①",
          叙述者: "①"
        },
        effect: "【失败条件：轮回结束时】当前为表世界"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "3bdf5ff75d68adde",
      name: "童话里的杀人鬼",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/3bdf5ff75d68adde.json",
      sha256: "73673791282afbafd0b965a08a4480bc5db966391b4697170a4442646df89498",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          童谣: "①",
          主谋: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "c7ab9c76937efffa",
      name: "鹅妈妈神秘故事",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/c7ab9c76937efffa.json",
      sha256: "dfffc40f354cedb3e2eb841b22f5440676b8cbd50a5c0ca0c3edb003f356f11f",
      fields: {
        ruleType: "Y",
        identityCounts: {
          提线木偶: "①",
          叙述者: "①"
        },
        effect: "【失败条件：轮回结束时】有X具或以上尸体（X为当前轮回数，且最大为3）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "78449d7217e9ec90",
      name: "次元融合计划",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/78449d7217e9ec90.json",
      sha256: "a83e57b161ced8a13c3eabbe016a0ec45c1fccbd683df33f1bcb4a3912d4db93",
      fields: {
        ruleType: "Y",
        identityCounts: {
          叙述者: "①",
          次元旅者: "①",
          因果残片: "①"
        },
        effect: "【失败条件：轮回结束时】本轮轮回中引发过遗言或遗失物事件"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "f4737937e92bc993",
      name: "虚幻世界",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/f4737937e92bc993.json",
      sha256: "12e3d12855e67d870f8e5da0da8d652109df855ad22cd001198cbccf47012ef1",
      fields: {
        ruleType: "Y",
        identityCounts: {
          强迫症: "①",
          提线木偶: "①",
          主谋: "①"
        },
        effect: "【失败条件：轮回结束时】追加自该规则的强迫症（或尸体）身上的[密谋]与当前Ex槽的数值合计为3或以上"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "91680c1cf0f5c52e",
      name: "化身博士",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/91680c1cf0f5c52e.json",
      sha256: "d81466a425ab86f06bdf4d2ff609f66a71fb3d58a1e11807f1bf68fbd480691e",
      fields: {
        ruleType: "X",
        identityCounts: {
          关键人物: "表",
          提线木偶: "①",
          主谋: "里"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "6bd74f2965eb790b",
      name: "恶魔吹着笛子来",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/6bd74f2965eb790b.json",
      sha256: "0227a6ffe2af7f1a6f6213f525fd2aff2b7e83ca6f8671417817b9359bf19719",
      fields: {
        ruleType: "X",
        identityCounts: {
          魔笛手: "表",
          布道者: "里"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "f5875ee60194c009",
      name: "傀儡之线",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/f5875ee60194c009.json",
      sha256: "1169ccf6a1910168ea9c1c982c9040854a98edcf3afecb6659dc26d23da9498a",
      fields: {
        ruleType: "X",
        identityCounts: {
          因果残片: "①",
          杀人狂: "里",
          布道者: "①"
        },
        effect: "【强制：常驻】所有无视友好变为傀儡无视友好（包括绝望附加的）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "02b7be6d3d1584ba",
      name: "爱丽丝梦游仙境",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/02b7be6d3d1584ba.json",
      sha256: "3b290b4c1fe5abfef07f650a756b8d30226341251faf15f0a050c86e55b2772a",
      fields: {
        ruleType: "X",
        identityCounts: {
          杀人狂: "里",
          传谣人: "表",
          爱丽丝: "①"
        },
        effect: "【强制：剧本创作时】爱丽丝必须有少女属性"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "e3142a41fc69414c",
      name: "超越世界线",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/e3142a41fc69414c.json",
      sha256: "755d21019d041b98dc9d2459ea06a94b1a66d3589a397639b1b6ac197dcfe2fa",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【强制：轮回开始时】偶数轮轮回开始时，剧作家获得[绝望+1]，最终轮轮回开始时，主人公获得[希望+1]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "005bc9ff95862402",
      name: "难以言喻的怪物",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/005bc9ff95862402.json",
      sha256: "10c346c770698d54badca14cb3a59b0f76b94e26c6e8bf568a9971c7d7eb2fdc",
      fields: {
        ruleType: "X",
        identityCounts: {
          强迫症: "里",
          传谣人: "表",
          布道者: "①"
        },
        effect: "【任意能力：回合结束阶段】Ex槽为3或以上→主人公死亡"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "a7a39340423bba4d",
      name: "空想扩大病毒",
      kind: "rules",
      module: "AHR",
      source: "facts/data/rules/a7a39340423bba4d.json",
      sha256: "de0f60e3ca1ca7ce3bb79e8f267abcb22b3e9e0510f143d02f59f1c87e5d863b",
      fields: {
        ruleType: "X",
        identityCounts: {
          因果残片: "①",
          传谣人: "①",
          布道者: "①"
        },
        effect: "【强制：常驻】当前为里世界→身上有2种或以上不同指示物的平民或因果残片的角色身份变为杀人狂"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "1c7e6d8d7dcc642d",
      name: "关键人物",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/1c7e6d8d7dcc642d.json",
      sha256: "24bf85c98d08512a83b8564c4e120fe5c714ea48bb3cc68247e1803cd4aef9ed",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "3c80be81f17d7daf",
      name: "强迫症",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/3c80be81f17d7daf.json",
      sha256: "ecaadb88e088789bc3a9da0a0effacd800da05a85e655bda973d948b36f833e3",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【强制：剧本制作时】必须成为某1个事件的当事人",
          "【强制：事件阶段】当事人为该角色的事件必定会发生"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "cf7981e4727d9660",
      name: "提线木偶",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/cf7981e4727d9660.json",
      sha256: "1458d814a0aee9e953928cf595b4016795831c0d140aabf56939416e2af0977b",
      fields: {
        max: "",
        traits: "傀儡无视友好",
        abilities: [
          "【强制：结算该角色友好能力后】该角色身上有2种或以上不同指示物→该角色死亡，进行世界移动"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "bd11f022af1d7ac7",
      name: "叙述者",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/bd11f022af1d7ac7.json",
      sha256: "e168fe32fda056acc82f0db693e8721291ac0a44d13951864abbba320f642234",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【任意能力：剧作家能力阶段】Ex槽为1或以上→选择与该角色位于同一区域的另外2名角色，移动两者之间的一个标记。",
          "【强制：轮回开始时】若上轮轮回结束时Ex槽为3或以上→主人公获得[希望+1]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "1e1ed1a606914cc0",
      name: "童谣",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/1e1ed1a606914cc0.json",
      sha256: "a515df106a062da59dc4aafd57617fa3a2c6d5995831ecce45bf79e6bb5c5288",
      fields: {
        max: "",
        traits: "傀儡无视友好",
        abilities: [
          "【强制：结算该角色友好能力后】若该角色的友好能力指定了对象，那些被指定为对象的角色死亡",
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]或[友好]（每轮限1次）",
          "【任意能力：回合结束阶段】该角色身上有4种或以上不同指示物→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "e5d3dcfefe70f5ac",
      name: "次元旅者",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/e5d3dcfefe70f5ac.json",
      sha256: "3196f69ac6712c4348b22ec525ce56c7f00320ad314782099ab7c304a1885535",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【强制：行动结算阶段】无视该角色身上放置的禁止友好",
          "【任意能力：最终日的回合结束阶段】该角色身上有2种或以下不同指示物→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "686b776e75b2919a",
      name: "主谋",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/686b776e75b2919a.json",
      sha256: "f48930c0fe0d462e9c5bd3d8fcf44ec00219f576291f42fb287655bb38a0daf3",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意一名角色身上，或该角色所在的版图上放置1枚[密谋]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "849f2ee0fb16a45d",
      name: "因果残片",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/849f2ee0fb16a45d.json",
      sha256: "e9be6be32037b262e76b65022561db05370015680d5973dd351ce3b370d3422d",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：轮回开始时】若该角色在上轮轮回结束时处于死亡状态→剧作家获得[绝望+1]",
          "【强制：轮回开始时】若该角色在上轮轮回结束时存活并且身上有2枚或以上的[友好]，主人公获得[希望+1]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "2017e17baca3519c",
      name: "杀人狂",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/2017e17baca3519c.json",
      sha256: "2b4a258bb18d176efaffcd705e65df90a4199339b575c0b779b06d04a25ef8c0",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "9b0007c5b2f0f01d",
      name: "魔笛手",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/9b0007c5b2f0f01d.json",
      sha256: "77c7f1f62bd1f643ac8fb66f7eb5d17c670d3027a8e646758f714602c9f359d0",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【强制：回合结束阶段】Ex槽为2或以上→使同一区域任意1名角色死亡（每轮限1次）",
          "【任意能力：回合结束阶段】可以往同一区域任意1具尸体上放置1枚[密谋]，随后，如果所有尸体上的[密谋]合计有3枚或以上，则主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "336c9402b6a887b1",
      name: "传谣人",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/336c9402b6a887b1.json",
      sha256: "c50470940fc8b701490cb1aa8276f108d30cfe6f6526d40265602efb4c1725c9",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "88d16a6c705994a3",
      name: "布道者",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/88d16a6c705994a3.json",
      sha256: "202f7b221f41af68a0d404dcb5513a5aa9cc5b8b667e329f1aec89db162d02aa",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[友好]",
          "【强制：该角色死亡时】往同区域中任意1名角色身上放置1枚[绝望]，随后，可以进行世界移动"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "c543bf71c343528d",
      name: "爱丽丝",
      kind: "identities",
      module: "AHR",
      source: "facts/data/identities/c543bf71c343528d.json",
      sha256: "fda043fda2933699a621fb7aab383dd7c62b38d28cac74f279a77c0094ad0100",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【失败条件：轮回结束时】该卡牌为死亡状态",
          "【强制：结算该角色友好能力后】Ex槽为1或以上→往同一区域的所有其他角色身上放置1枚[希望]（每轮限1次）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "968001edee2005de",
      name: "冲动杀人",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/968001edee2005de.json",
      sha256: "a8c944afd9f84dcbde81c7890326c04d2482e59010dce3576777ac64f09b12b0",
      fields: {
        effect: "<当事人不安限度-1>与当事人位于同一区域的另外1名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "54dc3a7b79390c8f",
      name: "次元转换",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/54dc3a7b79390c8f.json",
      sha256: "6fb10d71673a3bb5ae24c4c7fcdbc50ab18f4721f233232377b38a6dd59242b9",
      fields: {
        effect: "<当事人存活时必定发生>进行世界移动"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "90032f434a8a48a1",
      name: "次元歪曲",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/90032f434a8a48a1.json",
      sha256: "938b6165fc639930bc680b369dcb3283735e906e7abe2b323ed9c00b9ae7b1a4",
      fields: {
        effect: "可以进行世界移动，往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置2枚[友好]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "641152a34f97e014",
      name: "次元断层",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/641152a34f97e014.json",
      sha256: "65643b35325ba39d20ecc91e3301bfc744872f7ec759f572949e0ea4231ee34d",
      fields: {
        effect: "可以进行世界移动，随后，若当事人身上有3种或以上不同种类的指示物→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "e039b22845e91187",
      name: "遗失物",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/e039b22845e91187.json",
      sha256: "a77a9e2513057726be892d8af750fb5ac93f59b3d6bc0a55fab02888314b0dc2",
      fields: {
        effect: "往和当事人位于同一区域的1名角色身上放置1枚[密谋]，然后，将当事人移动至任意版图"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "3bcbc2828aa94719",
      name: "空想事件",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/3bcbc2828aa94719.json",
      sha256: "a2e2b6122a9ba6707380f7e7ab7c56bce7feefaa8d34a8c255583ce5edad81eb",
      fields: {
        effect: "<通过密谋指示物数量判定是否发生>从冲动杀人、次元歪曲或遗失事件中，选择1个事件进行结算"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "261b1bc2ac9f275a",
      name: "遗言",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/261b1bc2ac9f275a.json",
      sha256: "46397b66e06ac97a6d8a426e58d0ad252ba478373f043bcdeacfe0a32f3d73fa",
      fields: {
        effect: "当事人死亡，下轮轮回开始时，主人公获得[希望+1]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "3b0ea24b3b278e58",
      name: "医院事故",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/3b0ea24b3b278e58.json",
      sha256: "56c7bb12bb3696e5ea6380b30fc865e628649095c8605fd6d107d20c64aad964",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "252c5b08a83132d0",
      name: "奇点",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/252c5b08a83132d0.json",
      sha256: "a373dcdc38090afe773687a9e5a0845512bdde65a586ffa915eee8d00038cf70",
      fields: {
        effect: "当前为表世界，并且本局游戏中本事件首次发生，主人公死亡。否则进行世界移动\n当前为里世界，并且当事人初始区域有1枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "12475e9d03341f4f",
      name: "隙间的阳光",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/12475e9d03341f4f.json",
      sha256: "0a709e8918dc833ff8e89fdebd15b2ba9740eef976fb6e9d16c2250d5196c6a1",
      fields: {
        effect: "队长选择一名角色，往那名角色身上放置1枚[希望]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "dfa3cb175546fa64",
      name: "绝望之暗",
      kind: "incidents",
      module: "AHR",
      source: "facts/data/incidents/dfa3cb175546fa64.json",
      sha256: "8e72ad9aadd27a6812fa95fdd6bb4942ce4a3c1b5b8b087a369d8dc389020e47",
      fields: {
        effect: "往任意1名角色身上放置1枚[绝望]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Another_Horizon_Revised",
          snapshot: "sources/wiki/pages/5a4c2d8594c08b1e.json",
          capturedAt: "2026-09-27T03:28:24.166Z"
        }
      }
    },
    {
      id: "77b779d8ce1c4d20",
      name: "鉴别员",
      kind: "characters",
      module: null,
      source: "facts/data/characters/77b779d8ce1c4d20.json",
      sha256: "4e5b6862d120540cb1ddb56e6e368f9e39b8175467a48431ab00ea99333fbe93",
      fields: {
        角色名: "鉴别员",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "成人",
          "男性"
        ],
        友好能力: [
          {
            text: "（友好2 1L1）选择同一区域另外2名角色，将1枚任意指示物在两者之间移动",
            threshold: 2,
            limitText: "1L1",
            oncePerLoop: true
          },
          {
            text: "（友好5 1L1）公开1具尸体的身份",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%91%91%E5%88%A5%E5%93%A1",
          snapshot: "sources/wiki/pages/6d479b6b2fec45cd.json",
          capturedAt: "2026-09-27T03:38:08.216Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%91%91%E5%88%A5%E5%93%A1",
          snapshot: "sources/wiki/pages/6d479b6b2fec45cd.json",
          capturedAt: "2026-09-27T03:38:08.216Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%91%91%E5%88%A5%E5%93%A1",
          snapshot: "sources/wiki/pages/6d479b6b2fec45cd.json",
          capturedAt: "2026-09-27T03:38:08.216Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%91%91%E5%88%A5%E5%93%A1",
          snapshot: "sources/wiki/pages/6d479b6b2fec45cd.json",
          capturedAt: "2026-09-27T03:38:08.216Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%91%91%E5%88%A5%E5%93%A1",
          snapshot: "sources/wiki/pages/6d479b6b2fec45cd.json",
          capturedAt: "2026-09-27T03:38:08.216Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%91%91%E5%88%A5%E5%93%A1",
          snapshot: "sources/wiki/pages/6d479b6b2fec45cd.json",
          capturedAt: "2026-09-27T03:38:08.216Z"
        }
      }
    },
    {
      id: "04ec0d810cd9675c",
      name: "教主",
      kind: "characters",
      module: null,
      source: "facts/data/characters/04ec0d810cd9675c.json",
      sha256: "00d4f5a1068b6bb6ec99459389c65ec32c3841928e502461fe0b984139dee162",
      fields: {
        角色名: "教主",
        初始区域: "神社",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "成人",
          "女性"
        ],
        特性: "该角色为当事人的事件，按事件文字表述结算2次",
        友好能力: [
          {
            text: "（友好3）往另外1名不安达到或超出不安限度的角色身上放置1枚友好指示物",
            threshold: 3,
            limitText: ""
          },
          {
            text: "（友好4 1L1）公开同一区域另外1名不安达到或超出不安限度的角色的身份",
            threshold: 4,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E4%B8%BB",
          snapshot: "sources/wiki/pages/6df2812bb02f6f14.json",
          capturedAt: "2026-09-27T03:33:00.704Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E4%B8%BB",
          snapshot: "sources/wiki/pages/6df2812bb02f6f14.json",
          capturedAt: "2026-09-27T03:33:00.704Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E4%B8%BB",
          snapshot: "sources/wiki/pages/6df2812bb02f6f14.json",
          capturedAt: "2026-09-27T03:33:00.704Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E4%B8%BB",
          snapshot: "sources/wiki/pages/6df2812bb02f6f14.json",
          capturedAt: "2026-09-27T03:33:00.704Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E4%B8%BB",
          snapshot: "sources/wiki/pages/6df2812bb02f6f14.json",
          capturedAt: "2026-09-27T03:33:00.704Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E4%B8%BB",
          snapshot: "sources/wiki/pages/6df2812bb02f6f14.json",
          capturedAt: "2026-09-27T03:33:00.704Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E4%B8%BB",
          snapshot: "sources/wiki/pages/6df2812bb02f6f14.json",
          capturedAt: "2026-09-27T03:33:00.704Z"
        }
      }
    },
    {
      id: "3d351a51a30289ee",
      name: "护士",
      kind: "characters",
      module: null,
      source: "facts/data/characters/3d351a51a30289ee.json",
      sha256: "568e6a0fe319eb6ba944466a9ab0a7c824fa85a0788db71b7c1cc3a953608a7d",
      fields: {
        角色名: "护士",
        初始区域: "医院",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "成人",
          "女性"
        ],
        友好能力: [
          {
            text: "（友好2）移除同一區域不安達到或超出限度的另外1名角色身上的1枚不安指示物。即使帶有無視友好特性也不能拒絕使用該能力。",
            threshold: 2,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%AD%B7%E5%A3%AB",
          snapshot: "sources/wiki/pages/73293a9147804a1d.json",
          capturedAt: "2026-09-27T03:34:26.116Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%AD%B7%E5%A3%AB",
          snapshot: "sources/wiki/pages/73293a9147804a1d.json",
          capturedAt: "2026-09-27T03:34:26.116Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%AD%B7%E5%A3%AB",
          snapshot: "sources/wiki/pages/73293a9147804a1d.json",
          capturedAt: "2026-09-27T03:34:26.116Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%AD%B7%E5%A3%AB",
          snapshot: "sources/wiki/pages/73293a9147804a1d.json",
          capturedAt: "2026-09-27T03:34:26.116Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%AD%B7%E5%A3%AB",
          snapshot: "sources/wiki/pages/73293a9147804a1d.json",
          capturedAt: "2026-09-27T03:34:26.116Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%AD%B7%E5%A3%AB",
          snapshot: "sources/wiki/pages/73293a9147804a1d.json",
          capturedAt: "2026-09-27T03:34:26.116Z"
        }
      }
    },
    {
      id: "6ede728967268773",
      name: "UP主",
      kind: "characters",
      module: null,
      source: "facts/data/characters/6ede728967268773.json",
      sha256: "c09be4a42059840da863d405c8eed6e717f6a3c1a50f1be3f27b72e64f210224",
      fields: {
        角色名: "UP主",
        初始区域: "远方",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "男性",
          "学生"
        ],
        特性: "在每輪輪回第一次事件發生當天的回合結束階段，往1名少年或少女身上設置1張Ex牌。在使用該角色的能力（包括友好能力）時，可以將放置有Ex牌的角色所在區域視為該角色所在區域。",
        友好能力: [
          {
            text: "（友好3）往同一區域另外一名角色身上放置1枚友好指示物，並移除1枚不安指示物。隨後，可以將那名角色身上的Ex牌轉移到與那名角色位於同一區域、且非UP主的1名角色身上。",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/UP%E4%B8%BB",
          snapshot: "sources/wiki/pages/7419e90475bddf2e.json",
          capturedAt: "2026-09-27T03:30:09.160Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/UP%E4%B8%BB",
          snapshot: "sources/wiki/pages/7419e90475bddf2e.json",
          capturedAt: "2026-09-27T03:30:09.160Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/UP%E4%B8%BB",
          snapshot: "sources/wiki/pages/7419e90475bddf2e.json",
          capturedAt: "2026-09-27T03:30:09.160Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/UP%E4%B8%BB",
          snapshot: "sources/wiki/pages/7419e90475bddf2e.json",
          capturedAt: "2026-09-27T03:30:09.160Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/UP%E4%B8%BB",
          snapshot: "sources/wiki/pages/7419e90475bddf2e.json",
          capturedAt: "2026-09-27T03:30:09.160Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/UP%E4%B8%BB",
          snapshot: "sources/wiki/pages/7419e90475bddf2e.json",
          capturedAt: "2026-09-27T03:30:09.160Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/UP%E4%B8%BB",
          snapshot: "sources/wiki/pages/7419e90475bddf2e.json",
          capturedAt: "2026-09-27T03:30:09.160Z"
        }
      }
    },
    {
      id: "13222d412f58d5ab",
      name: "First Steps",
      kind: "modules",
      module: "FS",
      source: "facts/data/modules/13222d412f58d5ab.json",
      sha256: "e68f98a585bd6c6cc0a764f0ff96a3076d7c1a670b48b7e5a94c887512d51f44",
      fields: {
        special: "First Steps 的特殊规则如下\n  1 剧本只有1条规则X\n  2 没有最终决战",
        mastermind_hand: {
          source_refs: [
            "P07-02"
          ],
          cards: [
            {
              id: "move_vertical",
              count: 1
            },
            {
              id: "move_horizontal",
              count: 1
            },
            {
              id: "move_diagonal",
              count: 1,
              once_per_loop: true
            },
            {
              id: "paranoia_plus_1",
              count: 2
            },
            {
              id: "paranoia_minus_1",
              count: 1
            },
            {
              id: "forbid_paranoia",
              count: 1
            },
            {
              id: "forbid_goodwill",
              count: 1
            },
            {
              id: "intrigue_plus_1",
              count: 1
            },
            {
              id: "intrigue_plus_2",
              count: 1,
              once_per_loop: true
            }
          ]
        }
      },
      provenance: {
        special: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        mastermind_hand: {
          provider: "ricardo",
          path: "working/ricardo/modules/first-steps.json",
          status: "draft_needs_human_review"
        }
      }
    },
    {
      id: "4ccfefbd4e7a33e6",
      name: "谋杀计划",
      kind: "rules",
      module: "FS",
      source: "facts/data/rules/4ccfefbd4e7a33e6.json",
      sha256: "ab4d1c22d0e5d632e4d14f5537ec01c6fdb97183f30d987b0c10acc934ecaf6d",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          杀手: "①",
          主谋: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "1f8cc331344933ed",
      name: "复仇的火种",
      kind: "rules",
      module: "FS",
      source: "facts/data/rules/1f8cc331344933ed.json",
      sha256: "94a24a402e9105dbe6b27ecbb3bfa0cc587b1941290dde0a0e744ea2b54ad971",
      fields: {
        ruleType: "Y",
        identityCounts: {
          主谋: "①"
        },
        effect: "【失败条件：轮回结束时】主谋的初始区域有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "4cc469da25752c53",
      name: "守护此地",
      kind: "rules",
      module: "FS",
      source: "facts/data/rules/4cc469da25752c53.json",
      sha256: "460c3ff70b03ce451575f4200bd80e5ac9eb31a57b8a2b182df74a1ef48a8cd8",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          邪教徒: "①"
        },
        effect: "【失败条件：轮回结束时】学校有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "0b496a30dc97c633",
      name: "开膛者的魔影",
      kind: "rules",
      module: "FS",
      source: "facts/data/rules/0b496a30dc97c633.json",
      sha256: "c4918c173f48c0787430d6a4acc2d7a41d0a81bcb9d6aa9cef24cc35e44002cc",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          杀人狂: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "8ff617a0561ece90",
      name: "流言四起",
      kind: "rules",
      module: "FS",
      source: "facts/data/rules/8ff617a0561ece90.json",
      sha256: "e777714b3c9f75a26093c8a4e2a3043df76f4a2f66d3a1338bea2c12a0af790e",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【任意能力：剧作家能力阶段】往任意1块版图上放置1枚[密谋]（每轮限1次）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "4c4962bd490123e1",
      name: "最黑暗的剧本",
      kind: "rules",
      module: "FS",
      source: "facts/data/rules/4c4962bd490123e1.json",
      sha256: "1d53cbf224e091034405bb69f5348f733f322eb8d45afe7f25cd742145931a88",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          暴徒: "②",
          亲友: "①"
        },
        effect: "【任意能力：剧本制作时】剧本制作时，暴徒的人数可以为0-2人"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "6c08652dd90fb178",
      name: "关键人物",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/6c08652dd90fb178.json",
      sha256: "3dd9a1f6b289bacd999442de72a8f338bb6795a2d579384a19a71abb598a3fb6",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "296d30313dbefc81",
      name: "杀手",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/296d30313dbefc81.json",
      sha256: "cc30a2d6e3a967a30682de1703473bbf61c45d2402fc0b4c92607dbe70594214",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：回合结束阶段】同一区域1名关键人物身上有2枚或以上[密谋]→那名关键人物死亡",
          "【任意能力：回合结束阶段】该角色身上有4枚或以上[密谋]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "c6319a0ee0d7bd24",
      name: "主谋",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/c6319a0ee0d7bd24.json",
      sha256: "c8d0d7cfce69b064df1a334bf549b3c0432a44adafe680b75257c5862dc00835",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域任意一名角色身上，或该角色所在的版图上放置1枚[密谋]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "3bf992a5c24af1cf",
      name: "邪教徒",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/3bf992a5c24af1cf.json",
      sha256: "cb20babe116f6bb7fc8f7e68a4edab6e1bc344cbe56fabd4627db1d231fbdd86",
      fields: {
        max: "",
        traits: "必定无视\n\n友好",
        abilities: [
          "【任意能力：行动结算阶段】可以无效化同一区域中任意角色身上和该角色所在版图上放置的禁止密谋"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "9ecec918665d0a52",
      name: "亲友",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/9ecec918665d0a52.json",
      sha256: "67caf88c9df2b8068f2af10019d08baea1510a46bd59e78941a91825b5e0b65c",
      fields: {
        max: "②",
        traits: "",
        abilities: [
          "【失败条件：轮回结束时】该卡牌为死亡状态，此时，需要告知主人公该卡牌的身份",
          "【强制：轮回开始时】该角色身份曾被公开→往该角色身上放置1枚[友好]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "7024076fc96e0d67",
      name: "暴徒",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/7024076fc96e0d67.json",
      sha256: "6bb77d724cb1bc9832542849a5f38c71fd0f9acc4f0e50d6198ee3f70adcde57",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "待校对。"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "ricardo",
          path: "sources/ricardo/reference/module/modules/first-steps.md",
          status: "draft_needs_human_review"
        }
      }
    },
    {
      id: "d19696a77038945c",
      name: "杀人狂",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/d19696a77038945c.json",
      sha256: "20dafbdef14ce7c31ff15a138a89cd6ae3113c9e0792ff57100aafac0d042e71",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "f16898d92f630937",
      name: "传谣人",
      kind: "identities",
      module: "FS",
      source: "facts/data/identities/f16898d92f630937.json",
      sha256: "1a0ce459f7dc64892b7bc2e3376fb9cbd15f8f82e95c4b35b678eaba928eb8b2",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "1473b245cbff67ed",
      name: "不安扩散",
      kind: "incidents",
      module: "FS",
      source: "facts/data/incidents/1473b245cbff67ed.json",
      sha256: "f940ff5b77bc10ca5d8ff8ab2a803f5f62046f82538c17a3fcc9d7048623396a",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "f8137730190bf2bb",
      name: "谋杀",
      kind: "incidents",
      module: "FS",
      source: "facts/data/incidents/f8137730190bf2bb.json",
      sha256: "457e6357f2eb6ec58d9bd1d64862eb3cbdba3d731ebd565a0f65ea4d0eb27908",
      fields: {
        effect: "与当事人位于同一区域的另外1名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "af069c3bf2314730",
      name: "医院事故",
      kind: "incidents",
      module: "FS",
      source: "facts/data/incidents/af069c3bf2314730.json",
      sha256: "dec755c157cf31d7bd5ad4e125657b4a139fb28982124ba181f578033e8231e0",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "6853b746c3aeac18",
      name: "自杀",
      kind: "incidents",
      module: "FS",
      source: "facts/data/incidents/6853b746c3aeac18.json",
      sha256: "056133bd7a8bb58dd544292eba1fd5cec1b136227b9138ba7a037148661d984b",
      fields: {
        effect: "当事人死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "4cfb82cf5d3cab39",
      name: "散播",
      kind: "incidents",
      module: "FS",
      source: "facts/data/incidents/4cfb82cf5d3cab39.json",
      sha256: "df1a0aa87058e2a0b78463a09af62515be068ae191a6d0bbb357f5502d06b621",
      fields: {
        effect: "从任意1名角色身上移除2枚[友好]，随后，往另外1名角色身上放置2枚[友好]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "70aa0732e00330dc",
      name: "失踪",
      kind: "incidents",
      module: "FS",
      source: "facts/data/incidents/70aa0732e00330dc.json",
      sha256: "539b7b3bcc2fc24ace1675eac30008f17140664f66122e9048c469b67c06acb9",
      fields: {
        effect: "将当事人移动至任意版图，随后，往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "d4a0549ba1902ffe",
      name: "远距离杀人",
      kind: "incidents",
      module: "FS",
      source: "facts/data/incidents/d4a0549ba1902ffe.json",
      sha256: "0063453cdbd49167b8b8ace34d7f135accbbec141ccbc6c34d5e26cc51989778",
      fields: {
        effect: "任意1名身上有2枚或以上[密谋]的角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/First_Steps",
          snapshot: "sources/wiki/pages/7bcd897f011ed91f.json",
          capturedAt: "2026-09-27T03:29:36.530Z"
        }
      }
    },
    {
      id: "7b1d70acbf4521da",
      name: "Midnight Zone",
      kind: "modules",
      module: "MZ",
      source: "facts/data/modules/7b1d70acbf4521da.json",
      sha256: "d56af7ea63f1ce015087beee96581317c578607e758c5482ae46f247dae601fc",
      fields: {
        special: [
          "谎言与情报主题。新增Ex牌机制"
        ]
      },
      provenance: {
        special: {
          provider: "lloyd",
          path: "sources/lunhui/tragedy_loop_appendix(3)(1).md"
        }
      }
    },
    {
      id: "661137ca12ebb1cd",
      name: "被封印的邪灵",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/661137ca12ebb1cd.json",
      sha256: "2c476400180b357751cac24d0514d33542dc07e2112e71e893a377ebb96f3a0d",
      fields: {
        ruleType: "Y",
        identityCounts: {
          主谋: "①",
          邪教徒: "①"
        },
        effect: "【失败条件：轮回结束时】神社有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "3be1e81e541b5b1b",
      name: "绝密报告",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/3be1e81e541b5b1b.json",
      sha256: "e566154ce1ed0a28809ec97ae2d066a78dfd06a7e7b65fa5a94fb7118670a207",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          主谋: "①",
          传谣人: "①"
        },
        effect: "【失败条件：轮回结束时】本轮轮回中公开过主谋、不安定因子或魔术师中任意身份的名称"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "23681dbbc0d74bd0",
      name: "男子汉的战争",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/23681dbbc0d74bd0.json",
      sha256: "d4e2bfacdd99c07c4f6ec280c40b02c6c9736490be00dd0ed74345f2f512a378",
      fields: {
        ruleType: "Y",
        identityCounts: {
          忍者: "①"
        },
        effect: "【强制：剧本制作时】忍者必须有男性属性（不可以是少年）\n【失败条件：轮回结束时】忍者或其尸体有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "703a9895df30f6ad",
      name: "魔爪渐进",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/703a9895df30f6ad.json",
      sha256: "b98bded605beef86fa4ecaad728f1335c1ae81ff94d2e41dde6e70819b45318b",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          邪教徒: "①",
          忍者: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "85cd4ae0cb50a43c",
      name: "因果之绊",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/85cd4ae0cb50a43c.json",
      sha256: "736cda20ca69590e1072310dba288b3657edf269a6b2f5df0e0efd58940ca64d",
      fields: {
        ruleType: "Y",
        identityCounts: {
          亲友: "①",
          杀人狂: "①",
          传谣人: "①"
        },
        effect: "【强制：轮回开始时】选择一名上轮轮回结束时处于死亡状态的角色，放置一张Ex牌（不可以与[诸神之骰]重复发动）\n【强制：常驻】放置了Ex牌的角色，其身份变为关键人物（该角色失去原本的身份）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "e3393d15260b35a7",
      name: "爱与恨的螺旋",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/e3393d15260b35a7.json",
      sha256: "083d161ccd79c98ca9ce597a78bb6e8d6ada59be66eb58ac69e4cba1b2f73d6d",
      fields: {
        ruleType: "X",
        identityCounts: {
          亲友: "①",
          强迫症: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "237a82081dc7f5f1",
      name: "魔女的茶会",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/237a82081dc7f5f1.json",
      sha256: "e7a828208ac636c99da062e9fb1dc26ebd32881911ad7a78a77852537c325b73",
      fields: {
        ruleType: "X",
        identityCounts: {
          亲友: "①",
          传谣人: "①",
          魔女: "②"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "0e3ba4b6e83f9b3d",
      name: "诸神之骰",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/0e3ba4b6e83f9b3d.json",
      sha256: "764546219b405cd9d616a802cddd760f5489e9aa776df956818a3af803ec8801",
      fields: {
        ruleType: "X",
        identityCounts: {
          杀人狂: "①",
          强迫症: "①"
        },
        effect: "【强制：轮回开始时】选择一名上轮轮回结束时处于死亡状态的角色，放置一张Ex牌（不可以与[因果之绊]重复发动）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "a12a1f7465e825a4",
      name: "X异因子",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/a12a1f7465e825a4.json",
      sha256: "53d0821bfdb60ba43b2e2960230cda672d9c2a8553bc699975b5f47cddc1ce06",
      fields: {
        ruleType: "X",
        identityCounts: {
          不安定因子: "①"
        },
        effect: "【任意能力：剧作家能力阶段】往存活的不安定因子所在版图放置1枚[密谋]（每轮限1次）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "6de4ab965e4cb4e8",
      name: "死亡真人秀",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/6de4ab965e4cb4e8.json",
      sha256: "3b308a9572fcfdfa0c3669f8f429e69faaefafd317e82d5b6bf095556b6d0f12",
      fields: {
        ruleType: "X",
        identityCounts: {
          魔术师: "①",
          永生者: "①"
        },
        effect: "【失败条件：轮回结束时】生存角色数量为6名或以下"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "b201907adcd47321",
      name: "心无灵犀",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/b201907adcd47321.json",
      sha256: "f8e1160348b5f5e11a370b5ab830e57742a722fbe30643aa0929ec04c166b652",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          魔术师: "①"
        },
        effect: "【强制：行动结算阶段】禁止友好同时具备禁止移动的效果"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "ec0c0533bdb22562",
      name: "灭亡讴歌",
      kind: "rules",
      module: "MZ",
      source: "facts/data/rules/ec0c0533bdb22562.json",
      sha256: "de18b2cba8387159f05b1ecf6ef3a02ea270d5cd91b203c6c842673dd464596b",
      fields: {
        ruleType: "X",
        identityCounts: {
          预言家: "①"
        },
        effect: "【强制：剧本制作时】必须引入1个或以上的自杀事件\n【强制：事件阶段】当事人为平民的事件在判定是否发生时，如果预言家存活，该当事人的不安限度-1"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "15d9a431cc0f9f8d",
      name: "关键人物",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/15d9a431cc0f9f8d.json",
      sha256: "c0a47a882d4d90308c7d8020c26c23b84b00b8dbc6f1ab7c4aedf4851382a7c5",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "1f8f91e561eb9c40",
      name: "主谋",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/1f8f91e561eb9c40.json",
      sha256: "68a9dc5c01a732b6de926e1a92afacb059ab171e128c140a3911c1de293f6656",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域任意一名角色身上，或该角色所在的版图上放置1枚[密谋]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "37c888fa1091c6f1",
      name: "邪教徒",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/37c888fa1091c6f1.json",
      sha256: "4807db5df1258f91bdc680844bdfc833ca4f2fe4f947672a5b7018d4d5c222d5",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【任意能力：行动结算阶段】可以无效化同一区域中任意角色身上和该角色所在版图上放置的禁止密谋"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "5d99af9d402eb707",
      name: "忍者",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/5d99af9d402eb707.json",
      sha256: "f6e99e18fa64af78c8f7f377468cab8115eaae8fcf1ffe5d5065452e750790e7",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：回合结束阶段】同一区域1名角色身上有2枚或以上[密谋]→那名角色死亡",
          "【任意能力：常驻】需公开该角色身份时，可以宣称本局游戏非公开信息表中的任意非平民身份名"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "2bb016fc92495227",
      name: "亲友",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/2bb016fc92495227.json",
      sha256: "6a184da96dafa3017ecf0085ac07ff02181e82654c6efb5d59e7a550634019e9",
      fields: {
        max: "②",
        traits: "",
        abilities: [
          "【失败条件：轮回结束时】该卡牌为死亡状态，此时，需要告知主人公该卡牌的身份",
          "【强制：轮回开始时】该角色身份曾被公开→往该角色身上放置1枚[友好]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "ebfe2f019746c886",
      name: "杀人狂",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/ebfe2f019746c886.json",
      sha256: "50d8b7cd71d3a8296b4b4e751b8d4847e623c2004b3d2ba3d0ce686a7e90e2ad",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "bf47ab9db31f15ff",
      name: "传谣人",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/bf47ab9db31f15ff.json",
      sha256: "276d5cc7d27c8b479841c4e3d235dc8737658ec2540627712e7e3613094a57f9",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "1ebad096c49899d7",
      name: "强迫症",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/1ebad096c49899d7.json",
      sha256: "d072b46591ffd79ec97e25ec0a24d4ed03b06d5ecfe2eb847ebc3558fe5c19ff",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【强制：剧本制作时】必须成为某1个事件的当事人",
          "【强制：事件阶段】当事人为该角色的事件必定会发生"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "1e2949df8189f730",
      name: "魔术师",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/1e2949df8189f730.json",
      sha256: "c988184556feb1695fc55d0065dd69376b70fedd74782f248059bb521f8ad420",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】使同一区域中1名放置了1枚或以上不安指示物的角色移动至相邻版图（所有魔术师合计，每轮限1次）",
          "【强制：该角色死亡时】移除该角色身上的所有[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "64d1375d51cbb697",
      name: "不安定因子",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/64d1375d51cbb697.json",
      sha256: "c922b15b230745aa2926809bc5d4c43919457e9ec11761226566cfa307caf446",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【强制：常驻】学校有2枚或以上[密谋]→该角色获得传谣人的能力（身份依然为[不安定因子]）",
          "【强制：常驻】都市有2枚或以上[密谋]→该角色获得关键人物的能力（身份依然为[不安定因子]）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "c6580ef3496aa105",
      name: "魔女",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/c6580ef3496aa105.json",
      sha256: "10b1d88671906b2449fee35865a6242f0fce84c23d94e4a4e4f9af06718d06f9",
      fields: {
        max: "",
        traits: "必定无视友好"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "6659cc9fa7c65670",
      name: "永生者",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/6659cc9fa7c65670.json",
      sha256: "6f70318b49cd947e5baa381f9ee846cc920bffc01dfd2430662454755f5c7b19",
      fields: {
        max: "",
        traits: "不死"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "15bc81986082afe6",
      name: "预言家",
      kind: "identities",
      module: "MZ",
      source: "facts/data/identities/15bc81986082afe6.json",
      sha256: "abefa91d9e8cbc40406ec97167cc20e2e95fd2e47b7343a8593c4cb2bda18a90",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：常驻】剧作家不可以往该角色身上设置任何行动牌",
          "【强制：事件阶段】与该角色位于同一区域的其他角色不会触发事件"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "179eec1a5f227f3e",
      name: "连续杀人",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/179eec1a5f227f3e.json",
      sha256: "641a25124ec3aa0598de0bb91ff04847f04a733ec5434d7d3306d3cc1d230d3f",
      fields: {
        effect: "与当事人位于同一区域的另外1名角色死亡\n1名角色可以同时担任多个连续杀人事件的当事人"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "5d905dffe3efb4e4",
      name: "自杀",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/5d905dffe3efb4e4.json",
      sha256: "53fb6858c9c6855195e808b8c5f7dba0e42ed6da9ebbb74d7750dc50016433a6",
      fields: {
        effect: "当事人死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "1a35e61dc0de21c9",
      name: "不安扩散",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/1a35e61dc0de21c9.json",
      sha256: "fdc0a0da7a6bfe5594bd7a37e1751f4ef14ff7137e8004c93a7dd061858c22f3",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "e87d0f4a6ecb46d8",
      name: "失踪",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/e87d0f4a6ecb46d8.json",
      sha256: "e1fb9f9946511241ce4275f3d591f267315896ef5d23c24bb1f67cd1e5c14646",
      fields: {
        effect: "将当事人移动至任意版图，随后，往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "87585683d033f2fe",
      name: "阴谋活动",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/87585683d033f2fe.json",
      sha256: "131b57e03719d6692dcb02811c9df62241e67e58851d7fe3bb82b62d79b64207",
      fields: {
        effect: "<通过密谋指示物数量判定是否发生>结算连续杀人或失踪事件的效果"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "d74f5036f197f4ed",
      name: "医院事故",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/d74f5036f197f4ed.json",
      sha256: "d2a50545a860eed4f640424f2ee37f7119135857af1b968e1a3c6dcb38ab9f82",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "5bb8040ce316b341",
      name: "暴乱",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/5bb8040ce316b341.json",
      sha256: "f7e803751b5f9c98d315830f96afebaf776d388d6403a3844fedb98f920e7f31",
      fields: {
        effect: "都市有1枚或以上[密谋]→位于都市的所有角色死亡\n学校有1枚或以上[密谋]→位于学校的所有角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "3d6f943081f83f1c",
      name: "自白",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/3d6f943081f83f1c.json",
      sha256: "730b5ec00b9ce6cce29cfdf8846de271fdc20fb97d54a43b380365b9251c4b2c",
      fields: {
        effect: "当事人公开自己的身份"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "530d9ad9c664dfff",
      name: "破局",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/530d9ad9c664dfff.json",
      sha256: "3fa68b07c6d5612b44ade8e9a3cf44f6b79a1082d39d8094129e6cda3ddf8221",
      fields: {
        effect: "队长选择1名角色或1块版图，移除其2枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "e5081a27c6910110",
      name: "伪装自杀",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/e5081a27c6910110.json",
      sha256: "8cbf2ab81380643582e70da9d823bf2ad943f0dac272b0c2a9d4a1c3e22073b1",
      fields: {
        effect: "往当事人身上设置1张Ex牌\n本轮轮回剩余时间主人公将无法往放置了Ex牌的角色身上放置行动牌"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "5b5a4b8cdb15bad6",
      name: "伪造事件",
      kind: "incidents",
      module: "MZ",
      source: "facts/data/incidents/5b5a4b8cdb15bad6.json",
      sha256: "6241a4af407af1ce52c1aa4798dd9d1d2cd5d7a94ffc5c503f78219bd1c2d150",
      fields: {
        effect: "当事人初始区域有2枚或以上[密谋]→主人公死亡\n将伪造事件记入公开信息表时，可以自由命名事件名称（非公开信息表和游戏中依然视为伪造事件）"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Midnight_Zone",
          snapshot: "sources/wiki/pages/8373b99324f2c1ae.json",
          capturedAt: "2026-09-27T03:29:47.701Z"
        }
      }
    },
    {
      id: "07a03c94050c1185",
      name: "Last Liar",
      kind: "modules",
      module: "LL",
      source: "facts/data/modules/07a03c94050c1185.json",
      sha256: "94efe2de712f5174bf980de701ed76db980cde2d0ffc4f2321de1053f3b80baf",
      fields: {
        special: "Last Liar的特殊规则如下\n  背叛者\n  在第一轮轮回开始时将Ex牌ABC洗混，并分给三个主人公，这张牌只有获得的主人公可以确认，剧作家和其他主人公不能确认。拿到ExA的主人公称为主人公A，以此类推。\n  如果剧本选择的规则有特殊胜利条件，则对应的主人公变为背叛者，获得单独的胜利条件，如果完成胜利条件，则那个主人公单独胜利，剧作家和其他主人公失败，如果在轮回过程中主人公胜利，则背叛者失败。\n  最终决战时，如果背叛者是C，结算支线效果。\n  所有背叛者不能参与最终决战并失败。由于规则X最多有2条，所以背叛者最多有2名。\n  已沟通与已死亡\n  本模组必须使用已死亡标志和已沟通标志，并且本模组必须为4人游戏，且在轮回中不能讨论。\n  杀人狂的限制\n  杀人狂在这个模组中限制1人。"
      },
      provenance: {
        special: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "303729c5923728b8",
      name: "最终计划",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/303729c5923728b8.json",
      sha256: "d1e91586773e670c0ffc53d94c55bf13971edaa2dd9924d97e31122a43a009d0",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          杀手: "①",
          主谋: "①"
        },
        effect: "【强制：常驻】关键人物（无论生死）身上有1枚或以上[希望]→所有主人公不再是背叛者。如果当前是最终轮回，则最终决战时依然生效"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "22eecacc8074c2fe",
      name: "封印的终末",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/22eecacc8074c2fe.json",
      sha256: "a5fee47fa1a888e0d7db27af5e8c859c69e2c9c913a37eab106f6eb8d013172c",
      fields: {
        ruleType: "Y",
        identityCounts: {
          因果残片: "①",
          不安定因子: "①"
        },
        effect: "【任意能力：回合结束阶段】神社有2枚或以上[密谋]→主人公死亡\n【强制：进行判定时】计算某块版图上的[密谋]数量时，该区域角色身上的[希望]和[绝望]也视为位于版图上。"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "3688324f10c26273",
      name: "叛逆的世界",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/3688324f10c26273.json",
      sha256: "9790522536e6d801aa85a8383e16278069c5bab2ed39d375ad9162da6cd6cf69",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          因果残片: "①"
        },
        effect: "【强制：剧本制作时】关键人物和因果残片必须有少女属性\n【失败条件：轮回结束时】关键人物有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "49231f667bc39e0b",
      name: "恶魔的剧本",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/49231f667bc39e0b.json",
      sha256: "9db83794c8012d961be8bdd0e95d0a33a02e0f2f00a4c6c088a579491dcdb4eb",
      fields: {
        ruleType: "Y",
        identityCounts: {
          杀人狂: "①",
          监视者: "①"
        },
        effect: "【失败条件：轮回结束时】本轮轮回中引发过遗言或代行者事件\n【任意能力：最终日的回合结束阶段】若监视者身上的指示物仅有1枚或以下→主人公死亡"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "71774563dbc655cd",
      name: "巨大定时炸弹Z",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/71774563dbc655cd.json",
      sha256: "f3f091e9a2055253b430b99c5aff2e189a5e16286d7d5faf92b5b048223c3b7f",
      fields: {
        ruleType: "Y",
        identityCounts: {
          主谋: "①",
          魔女: "①"
        },
        effect: "【失败条件：轮回结束时】魔女的初始区域有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "2b642eddb68b91ce",
      name: "真正的怪物",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/2b642eddb68b91ce.json",
      sha256: "35ed0a478d23b29fcccac22ee6faa36453f85d62f234bcaa782bfdee6b411bc6",
      fields: {
        ruleType: "X",
        identityCounts: {
          杀人狂: "①",
          密钥: "①",
          怪杰: "①"
        },
        effect: "【特殊胜利条件A：回合结束阶段】总计放置过5枚或以上已死亡标志"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "557be7ad31dea2bb",
      name: "神话收集者",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/557be7ad31dea2bb.json",
      sha256: "af207a2d502d174e67eaabdf9dd6a4ff9e9ceeb4b373229acccf9e83de238227",
      fields: {
        ruleType: "X",
        identityCounts: {
          网络名流: "①",
          密钥: "①",
          怪杰: "①"
        },
        effect: "【特殊胜利条件B：主人公能力阶段】总计放置过6枚或以上已沟通标志"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "a01eec4af41e8652",
      name: "我才是名侦探",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/a01eec4af41e8652.json",
      sha256: "7bc1bf4f7c2fffaa29405e5ee68fe47538c75f3e78a2b58892f75459c65d9f3d",
      fields: {
        ruleType: "X",
        identityCounts: {
          监视者: "①",
          密钥: "①",
          怪杰: "①"
        },
        effect: "【特殊胜利条件C：最终决战】最终决战前主人公C获得推理机会，需要正确推理所有事件的当事人"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "fec5f0235307fb56",
      name: "超越世界线",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/fec5f0235307fb56.json",
      sha256: "36a820d766a53d955d1a9a45249b921e3f2fb344421c2aa796ce9df2161a5403",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【强制：轮回开始时】偶数轮轮回开始时，剧作家获得[绝望+1]，最终轮轮回开始时，主人公获得[希望+1]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "1b09bb639e9c8994",
      name: "X异因子",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/1b09bb639e9c8994.json",
      sha256: "2a3951e6a3994dbe60bff8fee23cd8f4501876acb72a9a479048c648e20d3900",
      fields: {
        ruleType: "X",
        identityCounts: {
          不安定因子: "①"
        },
        effect: "【任意能力：剧作家能力阶段】往存活的不安定因子所在版图放置1枚[密谋]（每轮限1次）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "fbd89382bc92fad4",
      name: "SNS恐慌",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/fbd89382bc92fad4.json",
      sha256: "8b21739d8d528f47bb3b5e78b093c5439c4de1d4dc64a0ec6500b69014947d3b",
      fields: {
        ruleType: "X",
        identityCounts: {
          杀人狂: "①",
          网络名流: "①",
          传谣人: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "d1135a0bcf0976ca",
      name: "捏造的秘密",
      kind: "rules",
      module: "LL",
      source: "facts/data/rules/d1135a0bcf0976ca.json",
      sha256: "116c8b3a014adb1967a927293a6960dc57f089e98cafba59f451e00c8899d286",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【强制：剧本制作时】秘钥获得无视友好，如果剧本中不存在秘钥，选择追加一名杀手、主谋或因果残片（不能追加剧本规则中已存在的身份）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "793f5d6a1095422f",
      name: "关键人物",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/793f5d6a1095422f.json",
      sha256: "f0fe678e57813337646fb36082f64ab9b79ab6e71ce291840009942d0d5d2f18",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "1d8571973f95a43f",
      name: "杀手",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/1d8571973f95a43f.json",
      sha256: "ffe2ed03622f147f2a676bc771d16ccd103ac4987bd93b2f5d279e795d75b84d",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：回合结束阶段】同一区域1名关键人物身上有2枚或以上[密谋]→那名关键人物死亡",
          "【任意能力：回合结束阶段】该角色身上有4枚或以上[密谋]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "a3bd0de93cbd862f",
      name: "主谋",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/a3bd0de93cbd862f.json",
      sha256: "4984743141718ac540eca65f075b051b324835f66ff05497ce47823844208618",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域任意一名角色身上，或该角色所在的版图上放置1枚[密谋]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "0686b8b237d57b47",
      name: "因果残片",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/0686b8b237d57b47.json",
      sha256: "7795195cb9c8a26ad9af662733e78bf39b02d070751cd7119eccbbc1956c9cec",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：轮回开始时】若该角色上轮轮回结束时处于死亡状态→剧作家获得[绝望+1]",
          "【强制：轮回开始时】若该角色上轮轮回结束时存活并且身上有2枚或以上的[友好]，主人公获得[希望+1]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "d5d201a2ef5ed4bd",
      name: "魔女",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/d5d201a2ef5ed4bd.json",
      sha256: "31d0e8c7342d678c56bb120d1b25ca6ca5967ae305d6291e60a6585f4c27a6f4",
      fields: {
        max: "",
        traits: "必定无视友好"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "42c8a4c346633100",
      name: "不安定因子",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/42c8a4c346633100.json",
      sha256: "78ccb4860bc59ecb5e315217e0a878d02ac9d6a74a61d8621631ab14ac00d0ad",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【强制：常驻】学校有2枚或以上[密谋]→该角色获得传谣人的能力（身份依然为[不安定因子]）",
          "【强制：常驻】都市有2枚或以上[密谋]→该角色获得关键人物的能力（身份依然为[不安定因子]）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "1d805adf8da6701d",
      name: "杀人狂",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/1d805adf8da6701d.json",
      sha256: "22a66f3de102bfb900acc2ae0f355b26c21333ee47cb05f9214d36b4aa84b6e5",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "62fe348441f11142",
      name: "监视者",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/62fe348441f11142.json",
      sha256: "d8a90bf81093f79693f41cde589281581799de3e3da252182a5f88c0c2f4c3a0",
      fields: {
        max: "①",
        traits: "不死",
        abilities: [
          "【强制：事件阶段】与该角色位于同一区域且有1枚或以上[绝望]的角色必定触发事件"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "d191f3ed7fd74790",
      name: "网络名流",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/d191f3ed7fd74790.json",
      sha256: "c37fdcbd7453aa48fdfa06c2e67dd725ecd32236f1b52280bda8f5d763bbe20d",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】往与该角色同一初始区域的其他所有角色身上放置1枚[不安]",
          "【强制：结算该角色友好能力后】往与该角色同一初始区域的其他所有角色身上放置1枚[友好]和1枚[不安]（每轮限1次）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "3cb5a5b765c1c04e",
      name: "传谣人",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/3cb5a5b765c1c04e.json",
      sha256: "ae07d8611569250e586531494c2bad7c4ded61dfff4d3b92a5a68ca725e2b771",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "54b474de212701a2",
      name: "密钥",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/54b474de212701a2.json",
      sha256: "0598951d50191c537317b462f96b95d4de4e3d3554298bb7612187195b647968",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时或结算该角色友好能力后】公开该角色身份",
          "【强制：该角色公开身份时】当前为第1或第2轮轮回→剧作家在下一天只能打出1张行动牌，在下一天或该轮回最后一天的回合结束阶段主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "be338391056d1c33",
      name: "怪杰",
      kind: "identities",
      module: "LL",
      source: "facts/data/identities/be338391056d1c33.json",
      sha256: "9e5088e353cca44f0931b3f9175aa874ccac8a03dc5548767015f613219bc077",
      fields: {
        max: "①",
        traits: "必定无视友好\n\n不死",
        abilities: [
          "【强制：常驻】当天的天数为3的倍数→该角色获得传谣人、主谋和杀人狂的能力",
          "【强制：剧本制作时】必须成为某1个事件的当事人"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "066d291502fe0a89",
      name: "不安扩散",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/066d291502fe0a89.json",
      sha256: "13dc444e50918ad2978a446d1a7aff46930e665465096261268a5d826cb08462",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "52df9adba39bdfad",
      name: "谋杀",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/52df9adba39bdfad.json",
      sha256: "13f4f9d55545c1ac65f1c31528718d9e5b2b439663eff0b5ba2ee95297a2f1f3",
      fields: {
        effect: "与当事人位于同一区域的另外1名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "82705addb1961cda",
      name: "代行者",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/82705addb1961cda.json",
      sha256: "7d0018d2a111f3138e0033859fb5d27e44c6f7b052cf187fcf540cfbab8c2498",
      fields: {
        effect: "剧作家选择1名主人公，那位主人公选择1名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "2eeebf69a95fdf59",
      name: "医院事故",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/2eeebf69a95fdf59.json",
      sha256: "539f82ce29bf80ba5a63019e705be5598db1287fc124f7598c55661a4fb82284",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "6ecf7f38c0991c79",
      name: "骤变",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/6ecf7f38c0991c79.json",
      sha256: "82b461d000d51ada7f3ce1341f9157730ec7b3024c20ba9d2a43dc267ce76634",
      fields: {
        effect: "当事人初始区域有2枚或以上[密谋]→主人公死亡\n当事人初始区域有1枚或以下[密谋]→往当事人初始区域对应的版图上放置2枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "9982335bf5a21113",
      name: "散播",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/9982335bf5a21113.json",
      sha256: "a4601f823f824e0d416ad2417fa3083617035a4594bfa1f1d4d6a8a3986a0aab",
      fields: {
        effect: "从任意1名角色身上移除2枚[友好]，随后往另外1名角色身上放置2枚[友好]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "947e43d0580442a4",
      name: "遗言",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/947e43d0580442a4.json",
      sha256: "0e5da31f0023fedf5c3e81e056209fe5fb642e98142e4f1e2fc458d4aae41195",
      fields: {
        effect: "当事人死亡，下轮轮回开始时，主人公获得[希望+1]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "ebfce947ae8ea94b",
      name: "失踪",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/ebfce947ae8ea94b.json",
      sha256: "521c0dc189be04edcd173bcf66deef4d9112ec84346cf778b33e9dda7842d96b",
      fields: {
        effect: "将当事人移动至任意版图，随后，往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "acadf1a7e80f6b0e",
      name: "自白",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/acadf1a7e80f6b0e.json",
      sha256: "f2dac73f1b5a2051ed8a1e671056e6bcbe7f0a19681dc2440d8bf1e7cfcefa51",
      fields: {
        effect: "当事人公开自己的身份"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "36a3098eea9bb903",
      name: "希望之光",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/36a3098eea9bb903.json",
      sha256: "4545621cdd78268396a1df16b05d453fb6653548769637e34e5d2f5e1c129ae2",
      fields: {
        effect: "<通过友好指示物判定是否发生>队长选择1名角色，那名角色放置1枚[希望]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "155fe04a43af8288",
      name: "绝望之暗",
      kind: "incidents",
      module: "LL",
      source: "facts/data/incidents/155fe04a43af8288.json",
      sha256: "092e95153e963d8c7635e543f648c3eaef76fc8a21cba943c78a12bed9943d3a",
      fields: {
        effect: "往任意1名角色身上放置1枚[绝望]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Last_Liar",
          snapshot: "sources/wiki/pages/844cae1ed2f5e214.json",
          capturedAt: "2026-09-27T03:29:44.914Z"
        }
      }
    },
    {
      id: "2331171e392551ca",
      name: "住院患者",
      kind: "characters",
      module: null,
      source: "facts/data/characters/2331171e392551ca.json",
      sha256: "24ca8ad9990624c8fefed07f9aedaa393c33ed67f94eef202716a964654f1a1b",
      fields: {
        角色名: "住院患者",
        初始区域: "医院",
        禁行区域: "学校 都市 神社",
        不安限度: "2",
        属性: [
          "少年"
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BD%8F%E9%99%A2%E6%82%A3%E8%80%85",
          snapshot: "sources/wiki/pages/8a8995506c994e09.json",
          capturedAt: "2026-09-27T03:30:30.818Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BD%8F%E9%99%A2%E6%82%A3%E8%80%85",
          snapshot: "sources/wiki/pages/8a8995506c994e09.json",
          capturedAt: "2026-09-27T03:30:30.818Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BD%8F%E9%99%A2%E6%82%A3%E8%80%85",
          snapshot: "sources/wiki/pages/8a8995506c994e09.json",
          capturedAt: "2026-09-27T03:30:30.818Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BD%8F%E9%99%A2%E6%82%A3%E8%80%85",
          snapshot: "sources/wiki/pages/8a8995506c994e09.json",
          capturedAt: "2026-09-27T03:30:30.818Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BD%8F%E9%99%A2%E6%82%A3%E8%80%85",
          snapshot: "sources/wiki/pages/8a8995506c994e09.json",
          capturedAt: "2026-09-27T03:30:30.818Z"
        }
      }
    },
    {
      id: "a5fca13bda0eb9d9",
      name: "刑警",
      kind: "characters",
      module: null,
      source: "facts/data/characters/a5fca13bda0eb9d9.json",
      sha256: "6ed64c4aa579dae6172c03ad9ee23d95b821b339b19a6b0083933fd8bab0d391",
      fields: {
        角色名: "刑警",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "男性",
          "成人"
        ],
        友好能力: [
          {
            text: "（友好4 1L1）公開1個本輪已發生事件的當事人。",
            threshold: 4,
            limitText: "1L1",
            oncePerLoop: true
          },
          {
            text: "（友好5 1L1）往同一區域任意1名角色身上放置1枚護衛指示物。放置護衛指示物的角色死亡時，移除護衛指示物代替其死亡處理。",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%88%91%E8%AD%A6",
          snapshot: "sources/wiki/pages/8b9928b507fad308.json",
          capturedAt: "2026-09-27T03:30:49.067Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%88%91%E8%AD%A6",
          snapshot: "sources/wiki/pages/8b9928b507fad308.json",
          capturedAt: "2026-09-27T03:30:49.067Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%88%91%E8%AD%A6",
          snapshot: "sources/wiki/pages/8b9928b507fad308.json",
          capturedAt: "2026-09-27T03:30:49.067Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%88%91%E8%AD%A6",
          snapshot: "sources/wiki/pages/8b9928b507fad308.json",
          capturedAt: "2026-09-27T03:30:49.067Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%88%91%E8%AD%A6",
          snapshot: "sources/wiki/pages/8b9928b507fad308.json",
          capturedAt: "2026-09-27T03:30:49.067Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%88%91%E8%AD%A6",
          snapshot: "sources/wiki/pages/8b9928b507fad308.json",
          capturedAt: "2026-09-27T03:30:49.067Z"
        }
      }
    },
    {
      id: "0edd1d147d165672",
      name: "局外人",
      kind: "characters",
      module: null,
      source: "facts/data/characters/0edd1d147d165672.json",
      sha256: "fce2c3e15de0e0def6ce6c7de07926bd2d8d9b02f0e2853ab0bad64f155c5e6d",
      fields: {
        角色名: "局外人",
        初始区域: "学校",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "学生",
          "少年"
        ],
        特性: "剧本制作时，该角色不参与剧本所选规则的身份分配，但不直接视作平民，而是为其分配当前模组中存在、并且剧本所选规则中未带有的某一身份",
        友好能力: [
          {
            text: "（友好3）必須在第2輪輪迴或之後才可以使用。公開該角色的身份。即使帶有無視友好特性，也不能拒絕行使該能力。",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B1%80%E5%A4%96%E4%BA%BA",
          snapshot: "sources/wiki/pages/8ecc994f3b3e8eb7.json",
          capturedAt: "2026-09-27T03:32:03.171Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B1%80%E5%A4%96%E4%BA%BA",
          snapshot: "sources/wiki/pages/8ecc994f3b3e8eb7.json",
          capturedAt: "2026-09-27T03:32:03.171Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B1%80%E5%A4%96%E4%BA%BA",
          snapshot: "sources/wiki/pages/8ecc994f3b3e8eb7.json",
          capturedAt: "2026-09-27T03:32:03.171Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B1%80%E5%A4%96%E4%BA%BA",
          snapshot: "sources/wiki/pages/8ecc994f3b3e8eb7.json",
          capturedAt: "2026-09-27T03:32:03.171Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B1%80%E5%A4%96%E4%BA%BA",
          snapshot: "sources/wiki/pages/8ecc994f3b3e8eb7.json",
          capturedAt: "2026-09-27T03:32:03.171Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B1%80%E5%A4%96%E4%BA%BA",
          snapshot: "sources/wiki/pages/8ecc994f3b3e8eb7.json",
          capturedAt: "2026-09-27T03:32:03.171Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B1%80%E5%A4%96%E4%BA%BA",
          snapshot: "sources/wiki/pages/8ecc994f3b3e8eb7.json",
          capturedAt: "2026-09-27T03:32:03.171Z"
        }
      }
    },
    {
      id: "0498327fae0d3e3b",
      name: "女学生",
      kind: "characters",
      module: null,
      source: "facts/data/characters/0498327fae0d3e3b.json",
      sha256: "2c00b52c2d9a4a533fe34a18da478bb944e567a7ae79b09f9c1c5dc550d5227b",
      fields: {
        角色名: "女學生",
        初始区域: "学校",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "学生",
          "少女"
        ],
        友好能力: [
          {
            text: "（友好２）移除同一区域另外1名学生身上的1枚不安指示物",
            threshold: 2,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A5%B3%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/a2981483fdc442ac.json",
          capturedAt: "2026-09-27T03:31:45.169Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A5%B3%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/a2981483fdc442ac.json",
          capturedAt: "2026-09-27T03:31:45.169Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A5%B3%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/a2981483fdc442ac.json",
          capturedAt: "2026-09-27T03:31:45.169Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A5%B3%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/a2981483fdc442ac.json",
          capturedAt: "2026-09-27T03:31:45.169Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A5%B3%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/a2981483fdc442ac.json",
          capturedAt: "2026-09-27T03:31:45.169Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A5%B3%E5%AD%B8%E7%94%9F",
          snapshot: "sources/wiki/pages/a2981483fdc442ac.json",
          capturedAt: "2026-09-27T03:31:45.169Z"
        }
      }
    },
    {
      id: "b48749824ce70ed9",
      name: "手下",
      kind: "characters",
      module: null,
      source: "facts/data/characters/b48749824ce70ed9.json",
      sha256: "3a3dab0f1817e87c651b7ce53b0cf13dd6747883461f7dce096d8a8a8f2e39ee",
      fields: {
        角色名: "手下",
        初始区域: "见特性",
        禁行区域: "无",
        不安限度: "1",
        属性: [
          "成人",
          "男性"
        ],
        特性: "每輪輪迴開始前，由劇作家決定該角色的初始區域。",
        友好能力: [
          {
            text: "（友好3）本輪輪迴中，該角色為當事人的事件不會發生。",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%89%8B%E4%B8%8B",
          snapshot: "sources/wiki/pages/a875ecdedef6e84b.json",
          capturedAt: "2026-09-27T03:32:55.253Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%89%8B%E4%B8%8B",
          snapshot: "sources/wiki/pages/a875ecdedef6e84b.json",
          capturedAt: "2026-09-27T03:32:55.253Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%89%8B%E4%B8%8B",
          snapshot: "sources/wiki/pages/a875ecdedef6e84b.json",
          capturedAt: "2026-09-27T03:32:55.253Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%89%8B%E4%B8%8B",
          snapshot: "sources/wiki/pages/a875ecdedef6e84b.json",
          capturedAt: "2026-09-27T03:32:55.253Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%89%8B%E4%B8%8B",
          snapshot: "sources/wiki/pages/a875ecdedef6e84b.json",
          capturedAt: "2026-09-27T03:32:55.253Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%89%8B%E4%B8%8B",
          snapshot: "sources/wiki/pages/a875ecdedef6e84b.json",
          capturedAt: "2026-09-27T03:32:55.253Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%89%8B%E4%B8%8B",
          snapshot: "sources/wiki/pages/a875ecdedef6e84b.json",
          capturedAt: "2026-09-27T03:32:55.253Z"
        }
      }
    },
    {
      id: "0f855b184b6be0c8",
      name: "小女孩",
      kind: "characters",
      module: null,
      source: "facts/data/characters/0f855b184b6be0c8.json",
      sha256: "6e7e2700410cdebf3d18cf3bf7fefbe05e968a86650c3b869d4f0818bf3dbe9a",
      fields: {
        角色名: "小女孩",
        初始区域: "学校",
        禁行区域: "神社 都市 医院",
        不安限度: "1",
        属性: [
          "学生",
          "少女"
        ],
        友好能力: [
          {
            text: "（友好1）本輪輪迴中，該角色不再擁有禁行區域，可以移動至學校之外。",
            threshold: 1,
            limitText: ""
          },
          {
            text: "（友好3 1L1）將該角色移動至相鄰的版图。",
            threshold: 3,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B0%8F%E5%A5%B3%E5%AD%A9",
          snapshot: "sources/wiki/pages/ac295bf9d4dc581b.json",
          capturedAt: "2026-09-27T03:32:00.284Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B0%8F%E5%A5%B3%E5%AD%A9",
          snapshot: "sources/wiki/pages/ac295bf9d4dc581b.json",
          capturedAt: "2026-09-27T03:32:00.284Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B0%8F%E5%A5%B3%E5%AD%A9",
          snapshot: "sources/wiki/pages/ac295bf9d4dc581b.json",
          capturedAt: "2026-09-27T03:32:00.284Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B0%8F%E5%A5%B3%E5%AD%A9",
          snapshot: "sources/wiki/pages/ac295bf9d4dc581b.json",
          capturedAt: "2026-09-27T03:32:00.284Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B0%8F%E5%A5%B3%E5%AD%A9",
          snapshot: "sources/wiki/pages/ac295bf9d4dc581b.json",
          capturedAt: "2026-09-27T03:32:00.284Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B0%8F%E5%A5%B3%E5%AD%A9",
          snapshot: "sources/wiki/pages/ac295bf9d4dc581b.json",
          capturedAt: "2026-09-27T03:32:00.284Z"
        }
      }
    },
    {
      id: "f0a4a45e50cd59c2",
      name: "教师",
      kind: "characters",
      module: null,
      source: "facts/data/characters/f0a4a45e50cd59c2.json",
      sha256: "c3f6d4100dc73669f604d765765e2e8f59f912525f8e175f812a2b14fe95069e",
      fields: {
        角色名: "教师",
        初始区域: "学校",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "女性",
          "成人"
        ],
        友好能力: [
          {
            text: "（友好3）放置/移除同一區域1名學生身上的1枚不安指示物。",
            threshold: 3,
            limitText: ""
          },
          {
            text: "（友好4 1L1）公開同一區域1名學生的身份。",
            threshold: 4,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E5%B8%AB",
          snapshot: "sources/wiki/pages/ac6e49c296a46510.json",
          capturedAt: "2026-09-27T03:33:03.392Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E5%B8%AB",
          snapshot: "sources/wiki/pages/ac6e49c296a46510.json",
          capturedAt: "2026-09-27T03:33:03.392Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E5%B8%AB",
          snapshot: "sources/wiki/pages/ac6e49c296a46510.json",
          capturedAt: "2026-09-27T03:33:03.392Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E5%B8%AB",
          snapshot: "sources/wiki/pages/ac6e49c296a46510.json",
          capturedAt: "2026-09-27T03:33:03.392Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E5%B8%AB",
          snapshot: "sources/wiki/pages/ac6e49c296a46510.json",
          capturedAt: "2026-09-27T03:33:03.392Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%95%99%E5%B8%AB",
          snapshot: "sources/wiki/pages/ac6e49c296a46510.json",
          capturedAt: "2026-09-27T03:33:03.392Z"
        }
      }
    },
    {
      id: "bd9f5e4dd428366b",
      name: "幻想",
      kind: "characters",
      module: null,
      source: "facts/data/characters/bd9f5e4dd428366b.json",
      sha256: "57a40609eaf12d2291f38853c896ce6a2e85726d75e647c0b3e091d651a36dca",
      fields: {
        角色名: "幻想",
        初始区域: "神社",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "虚构",
          "女性"
        ],
        特性: "無法在該角色身上放置行動牌。在与该角色所在区域对应的版图上放置的行动牌，同样会作用于该角色。",
        友好能力: [
          {
            text: "（友好3 1L1）將同一區域任意1名角色移動至任意版图。",
            threshold: 3,
            limitText: "1L1",
            oncePerLoop: true
          },
          {
            text: "（友好4）將該角色從版圖上移除。",
            threshold: 4,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B9%BB%E6%83%B3",
          snapshot: "sources/wiki/pages/b19619f2baa37b58.json",
          capturedAt: "2026-09-27T03:32:40.938Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B9%BB%E6%83%B3",
          snapshot: "sources/wiki/pages/b19619f2baa37b58.json",
          capturedAt: "2026-09-27T03:32:40.938Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B9%BB%E6%83%B3",
          snapshot: "sources/wiki/pages/b19619f2baa37b58.json",
          capturedAt: "2026-09-27T03:32:40.938Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B9%BB%E6%83%B3",
          snapshot: "sources/wiki/pages/b19619f2baa37b58.json",
          capturedAt: "2026-09-27T03:32:40.938Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B9%BB%E6%83%B3",
          snapshot: "sources/wiki/pages/b19619f2baa37b58.json",
          capturedAt: "2026-09-27T03:32:40.938Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B9%BB%E6%83%B3",
          snapshot: "sources/wiki/pages/b19619f2baa37b58.json",
          capturedAt: "2026-09-27T03:32:40.938Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B9%BB%E6%83%B3",
          snapshot: "sources/wiki/pages/b19619f2baa37b58.json",
          capturedAt: "2026-09-27T03:32:40.938Z"
        }
      }
    },
    {
      id: "bee371fd65b819b7",
      name: "Mystery Circle",
      kind: "modules",
      module: "MC",
      source: "facts/data/modules/bee371fd65b819b7.json",
      sha256: "ae1c74fdd263faad2006b8e17f4ed9cf558e39514d2d03e53c5148bedfb4d4f6",
      fields: {
        special: "Mystery Circle 有的模组特殊规则如下\n  每当事件发生时，EX槽上升1，在每轮轮回开始时将EX槽清零"
      },
      provenance: {
        special: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "20b58d97912e0968",
      name: "谋杀计划",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/20b58d97912e0968.json",
      sha256: "20bac3d17e96b0c9502a7b33a5776e84f566d3222e98849fbbd15facc7c3eb6c",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          杀手: "①",
          主谋: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "722a764ccc6daf5d",
      name: "事件交织的罗网",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/722a764ccc6daf5d.json",
      sha256: "7e58b4ddc9d3539e42fe249c28bc97d520ee2dc487f8d860e5c4dc307ca605f5",
      fields: {
        ruleType: "Y",
        identityCounts: {
          愚者: "①",
          传谣人: "①"
        },
        effect: "【失败条件：轮回结束时】Ex槽为3或以上"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "01f4d7846771ef33",
      name: "命悬一线的计划",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/01f4d7846771ef33.json",
      sha256: "843d9e7851eb186bd0cd490024b73adcd910eeac28029833775ffe426f91d80f",
      fields: {
        ruleType: "Y",
        identityCounts: {
          杀手: "①",
          主谋: "①"
        },
        effect: "【失败条件：轮回结束时】Ex槽为1或以下"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "0d050097fcfe40b4",
      name: "黑暗学园",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/0d050097fcfe40b4.json",
      sha256: "5c6f38742b6e9c4547845d14992c4c901361eca571fb3a36f29a4f575a2c7cc2",
      fields: {
        ruleType: "Y",
        identityCounts: {
          主谋: "①"
        },
        effect: "【失败条件：轮回结束时】学校的[密谋]为X枚或以上（X=当前轮回数-1）（第一轮轮回必定失败）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "ced481ab39b4921d",
      name: "士的宁毒液",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/ced481ab39b4921d.json",
      sha256: "9e83e2b15a499246531a6c3296f08c32bece021082c93e13379b4a8d178a8a06",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          投毒者: "①",
          愚者: "①"
        },
        effect: "【强制：常驻】判定「连续杀人」「自杀」是否发生时，[密谋]视作[不安]处理"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "014a877a1ac1217e",
      name: "潜伏的杀人狂",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/014a877a1ac1217e.json",
      sha256: "90766949a8d38ebfbd151a121a09d236705c2ef82a9a17fe660c766e4c7ca521",
      fields: {
        ruleType: "X",
        identityCounts: {
          亲友: "①",
          杀人狂: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "ece7809e263a8dd8",
      name: "隔离病房惊魂记",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/ece7809e263a8dd8.json",
      sha256: "1357606abf47779deec14f1ae1358bd06ca0f4a41f5eb79ddaf689d42e8ccfd4",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          偏执狂: "①",
          心理医生: "①"
        },
        effect: "【强制：轮回开始时】上轮轮回结束时Ex槽为2或以下→Ex槽增加1"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "700a32b3b21832f7",
      name: "火药的味道",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/700a32b3b21832f7.json",
      sha256: "d2940d606efadcc0b89cca62fcb234fe76d83af46964b0af9334ef22cc732b3d",
      fields: {
        ruleType: "X",
        identityCounts: {
          杀人狂: "①"
        },
        effect: "【失败条件：轮回结束时】所有生存角色身上的[不安]总数为12枚或以上"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "354006b3ab37f6b0",
      name: "我是名侦探",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/354006b3ab37f6b0.json",
      sha256: "b61aaf98d20e0dc19b235e52af8a4d8940d71f80b127f80e2e9ab486d3ff0844",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          亲友: "①",
          侦探: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "6bc8b8f8f8d68b6c",
      name: "愚者之舞",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/6bc8b8f8f8d68b6c.json",
      sha256: "a7beaefd8d0f3f8fecfd6f552513cc8ca4b847492112f2138d885ae922856ad0",
      fields: {
        ruleType: "X",
        identityCounts: {
          愚者: "①",
          亲友: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "f9dd150b8ea33b9d",
      name: "绝对意志",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/f9dd150b8ea33b9d.json",
      sha256: "c344281361e92d541708ab751d0ceec0a574d04da26ea3eacf2cb0d45ddbde6a",
      fields: {
        ruleType: "X",
        identityCounts: {
          强迫症: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "138d8af3ee79f9e4",
      name: "双子的诡计",
      kind: "rules",
      module: "MC",
      source: "facts/data/rules/138d8af3ee79f9e4.json",
      sha256: "24cc9e94065c3554f8dff3c2086f6239e5710ccc52684abb37a78cbbdb22c533",
      fields: {
        ruleType: "X",
        identityCounts: {
          偏执狂: "①",
          双胞胎: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "15b00563ea9ae894",
      name: "关键人物",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/15b00563ea9ae894.json",
      sha256: "26e3955361813cc60d5f590a9d9197890f865ab17521a82e85a02d5b6da5c435",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "66374b7483d4bdef",
      name: "杀手",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/66374b7483d4bdef.json",
      sha256: "4b203131b0008106cb33d2dd892efedd84c52c0712bd5ccd4629661d11d6f947",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：回合结束阶段】同一区域1名关键人物身上有2枚或以上[密谋]→那名关键人物死亡",
          "【任意能力：回合结束阶段】该角色身上有4枚或以上[密谋]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "595eafa47fe372da",
      name: "主谋",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/595eafa47fe372da.json",
      sha256: "b43899b501dc55274f1f37fa07649a6603d89ff7f7cb3205ed14866729919c62",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域任意一名角色身上，或该角色所在的版图上放置1枚[密谋]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "c5a635931e04ebaf",
      name: "投毒者",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/c5a635931e04ebaf.json",
      sha256: "142176b3da7909901bdf5b16df3023ba2c5d82ed600ab8840bedaf64e9d05d3b",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【强制：回合结束阶段】Ex槽为2或以上→使同一区域的1名角色死亡（每轮限1次）",
          "【强制：回合结束阶段】Ex槽为4或以上→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "0e9089dadbdd7c93",
      name: "愚者",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/0e9089dadbdd7c93.json",
      sha256: "245bd6cf90c1279659dad64dc142c98d3699f5ab5344cabad1dd122ab1cb1c92",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【强制：剧本制作时】必须成为某1个事件的当事人",
          "【强制：担任当事人的事件完成结算后】移除该卡牌上所有的[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "4db060551bc05f62",
      name: "传谣人",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/4db060551bc05f62.json",
      sha256: "88d1f346106c08d80b0cd0e9f95c5ee6c62a6a269d3b66d76976db7d137b337b",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "33bd6eea0ce2e53e",
      name: "亲友",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/33bd6eea0ce2e53e.json",
      sha256: "0250e25be451990c17d3f8ec308655f9b6d9968b0a3458f7dfd5fa5a73ab99e9",
      fields: {
        max: "②",
        traits: "",
        abilities: [
          "【失败条件：轮回结束时】该卡牌为死亡状态，此时，需要告知主人公该卡牌的身份",
          "【强制：轮回开始时】该角色身份曾被公开→往该角色身上放置1枚[友好]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "d2c0d777872bb9fa",
      name: "杀人狂",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/d2c0d777872bb9fa.json",
      sha256: "3cf5089079219cccf377e453665919ea393d70fa6159321a55c525c3e9fb3fc6",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "e618ff4cac7aa2ca",
      name: "偏执狂",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/e618ff4cac7aa2ca.json",
      sha256: "e9adad74b6867598fa1c0d0e1c24173bfba06410819a686bd0ecba90c6f0a848",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往该角色身上放置1枚[密谋]或[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "f3bd5f8708b97bff",
      name: "心理医生",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/f3bd5f8708b97bff.json",
      sha256: "f55d556b8a9d82ef3b78243e8fd9ae6620563f0d1ba5ca65c993c9502d228493",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：剧作家能力阶段】Ex槽为1或以上→移除同一区域中自身以外的1名角色身上的1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "bc7692b7337b7e19",
      name: "侦探",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/bc7692b7337b7e19.json",
      sha256: "146c8f64cb9a2c63b8d285d1c51ce36f12ba915e0c6b5e0f948bb533b21421de",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【强制：剧本制作时】不可以成为事件的当事人",
          "【强制：事件阶段】Ex槽为0→如果与当天事件的当事人（存活）处于同一区域，则事件必定发生"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "c1b018cb45a6b76b",
      name: "强迫症",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/c1b018cb45a6b76b.json",
      sha256: "9cbbab33a9f64513af1ec11154b14231c1ebad58e262511257112948b7d75a3c",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【强制：剧本制作时】必须成为某1个事件的当事人",
          "【强制：事件阶段】当事人为该角色的事件必定会发生"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "ab1877d31b33fa8e",
      name: "双胞胎",
      kind: "identities",
      module: "MC",
      source: "facts/data/identities/ab1877d31b33fa8e.json",
      sha256: "4eba68a03045c1535dda36a9f565f9af41c17eeb6f13f6c6c9cffa1d83c7b356",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：剧本制作时】必须成为某1个事件的当事人",
          "【强制：结算该角色担任当事人的事件时】该角色视为位于本来所在位置对角线上的版图"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "e052e00ebd4de687",
      name: "连续杀人",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/e052e00ebd4de687.json",
      sha256: "a3e5e8159d6f0e2dd4bb01506fc62d0ab9069045cb6e7279e7f31566d2304b35",
      fields: {
        effect: "与当事人位于同一区域的另外1名角色死亡\n1名角色可以同时担任多个连续杀人事件的当事人"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "93fa6a2b4addbba2",
      name: "恐怖袭击",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/93fa6a2b4addbba2.json",
      sha256: "6e523b608336e9bdc74bd65d7980625b8d1368d758c3d535b747bb4952a227b9",
      fields: {
        effect: "都市有1枚或以上[密谋]→位于都市的所有角色死亡\n都市有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "e1f440ad5c47275f",
      name: "医院事故",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/e1f440ad5c47275f.json",
      sha256: "192bff1678407e2f7bf062016d85ecfcfd31fcbc3064f08428783117327aeaed",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "449994c5aea4a055",
      name: "自杀",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/449994c5aea4a055.json",
      sha256: "f7aa7988b1486d582c3a688670de8d8af3951cdb4f8637455953a822f37a0168",
      fields: {
        effect: "当事人死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "96d7c5504747f617",
      name: "不安扩散",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/96d7c5504747f617.json",
      sha256: "0214676185ff4f2caf760e8e6220860b91ce104ac8b221d5a34b98a42a61a7d8",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "31c8a9f2f319990c",
      name: "前兆",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/31c8a9f2f319990c.json",
      sha256: "8ff68736b840fbe63342bd78b1ac7edad1d608dda8e9e4ee0756b346bf052beb",
      fields: {
        effect: "<当事人不安限度-1>往和当事人位于同一区域的1名角色身上放置1枚[不安]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "b131d70dc5ced968",
      name: "猎奇杀人",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/b131d70dc5ced968.json",
      sha256: "eb1e2b2221a514a31cbcc78e396af4191939cace4f04c122732c2e7ced918584",
      fields: {
        effect: "<当事人不安限度+1><Ex槽增加2>按照「连续杀人」「不安扩散」的顺序结算事件"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "7b851b59a0d20c82",
      name: "伪装自杀",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/7b851b59a0d20c82.json",
      sha256: "7083b3237b8250dce245f97dc68b95032fe00d6d30f70a8253d1685e13234edb",
      fields: {
        effect: "往当事人身上设置1张Ex牌\n本轮轮回剩余时间主人公将无法往放置了Ex牌的角色身上放置行动牌"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "af0d02a742d2b45b",
      name: "可疑信件",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/af0d02a742d2b45b.json",
      sha256: "bed033a0f4b47e7ed05079a35b497ffc707c8089f7b4791eb2a24372b67ad724",
      fields: {
        effect: "将和当事人位于同一区域的1名角色移动至任意版图，如果那名角色被移动至其它版图，则次日那名角色无法移动"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "078920f0c35260d2",
      name: "封锁",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/078920f0c35260d2.json",
      sha256: "63243f8e8bdf4f68c5e152722764a75a2eb48d56b6c79a198d577c7e5d261fd3",
      fields: {
        effect: "指定当事人所在版图，自事件发生日起算，3天内角色无法通过移动进入或离开该版图"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "aad4c3acbd89dc8d",
      name: "银色子弹",
      kind: "incidents",
      module: "MC",
      source: "facts/data/incidents/aad4c3acbd89dc8d.json",
      sha256: "709c77cf4cc148c14a934f2ff501dfcd03a3a0b725459ee903851ea30af8bf90",
      fields: {
        effect: "<Ex槽不增加>该阶段结束时，本轮轮回结束"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Mystery_Circle",
          snapshot: "sources/wiki/pages/b21e3f528569eced.json",
          capturedAt: "2026-09-27T03:29:50.486Z"
        }
      }
    },
    {
      id: "a7d0d9f7d8223e20",
      name: "巫女",
      kind: "characters",
      module: null,
      source: "facts/data/characters/a7d0d9f7d8223e20.json",
      sha256: "5fcd1932e15f7e6f93e7091f44376200568398093afac629fe77256077cfb6df",
      fields: {
        角色名: "巫女",
        初始区域: "神社",
        禁行区域: "都市",
        不安限度: "2",
        属性: [
          "学生",
          "少女"
        ],
        友好能力: [
          {
            text: "（友好3）必須位於神社才可以使用。移除神社的1枚密謀指示物。",
            threshold: 3,
            limitText: ""
          },
          {
            text: "（友好5 1L1）公開同一區域任意1名角色的身份。",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B7%AB%E5%A5%B3",
          snapshot: "sources/wiki/pages/b26b39d89e566451.json",
          capturedAt: "2026-09-27T03:32:06.583Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B7%AB%E5%A5%B3",
          snapshot: "sources/wiki/pages/b26b39d89e566451.json",
          capturedAt: "2026-09-27T03:32:06.583Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B7%AB%E5%A5%B3",
          snapshot: "sources/wiki/pages/b26b39d89e566451.json",
          capturedAt: "2026-09-27T03:32:06.583Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B7%AB%E5%A5%B3",
          snapshot: "sources/wiki/pages/b26b39d89e566451.json",
          capturedAt: "2026-09-27T03:32:06.583Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B7%AB%E5%A5%B3",
          snapshot: "sources/wiki/pages/b26b39d89e566451.json",
          capturedAt: "2026-09-27T03:32:06.583Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%B7%AB%E5%A5%B3",
          snapshot: "sources/wiki/pages/b26b39d89e566451.json",
          capturedAt: "2026-09-27T03:32:06.583Z"
        }
      }
    },
    {
      id: "29ba9a9c7f2a5de1",
      name: "转校生",
      kind: "characters",
      module: null,
      source: "facts/data/characters/29ba9a9c7f2a5de1.json",
      sha256: "99b46a0b6a943cf9ba5b978aa64ed66da8f306b0c711d951400ed37b5c26c491",
      fields: {
        角色名: "转校生",
        初始区域: "学校",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "学生",
          "少女"
        ],
        特性: "劇本製作時，指定該角色在每輪輪迴第幾天登場。该角色不会在轮回准备时配置上场，在指定天数的回合开始阶段将该角色配置上场。",
        友好能力: [
          {
            text: "（友好2）將同一區域另外1名角色身上的1枚密謀指示物替換為友好指示物。",
            threshold: 2,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BD%89%E6%A0%A1%E7%94%9F",
          snapshot: "sources/wiki/pages/be9147d16e036352.json",
          capturedAt: "2026-09-27T03:38:00.124Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BD%89%E6%A0%A1%E7%94%9F",
          snapshot: "sources/wiki/pages/be9147d16e036352.json",
          capturedAt: "2026-09-27T03:38:00.124Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BD%89%E6%A0%A1%E7%94%9F",
          snapshot: "sources/wiki/pages/be9147d16e036352.json",
          capturedAt: "2026-09-27T03:38:00.124Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BD%89%E6%A0%A1%E7%94%9F",
          snapshot: "sources/wiki/pages/be9147d16e036352.json",
          capturedAt: "2026-09-27T03:38:00.124Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BD%89%E6%A0%A1%E7%94%9F",
          snapshot: "sources/wiki/pages/be9147d16e036352.json",
          capturedAt: "2026-09-27T03:38:00.124Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BD%89%E6%A0%A1%E7%94%9F",
          snapshot: "sources/wiki/pages/be9147d16e036352.json",
          capturedAt: "2026-09-27T03:38:00.124Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%BD%89%E6%A0%A1%E7%94%9F",
          snapshot: "sources/wiki/pages/be9147d16e036352.json",
          capturedAt: "2026-09-27T03:38:00.124Z"
        }
      }
    },
    {
      id: "beafedec55cfc735",
      name: "黑猫",
      kind: "characters",
      module: null,
      source: "facts/data/characters/beafedec55cfc735.json",
      sha256: "d27836693831c185da4587a20461ba77d3205449508429c842b065215a81c111",
      fields: {
        角色名: "黑猫",
        初始区域: "神社",
        禁行区域: "无",
        不安限度: "0",
        属性: [
          "动物"
        ],
        特性: "每輪輪迴開始時，往神社放置1枚密謀指示物。\n\n該角色為當事人的事件，其效果變為「沒有任何現象」。"
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%BB%91%E8%B2%93",
          snapshot: "sources/wiki/pages/c3f1e424d056212b.json",
          capturedAt: "2026-09-27T03:38:39.996Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%BB%91%E8%B2%93",
          snapshot: "sources/wiki/pages/c3f1e424d056212b.json",
          capturedAt: "2026-09-27T03:38:39.996Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%BB%91%E8%B2%93",
          snapshot: "sources/wiki/pages/c3f1e424d056212b.json",
          capturedAt: "2026-09-27T03:38:39.996Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%BB%91%E8%B2%93",
          snapshot: "sources/wiki/pages/c3f1e424d056212b.json",
          capturedAt: "2026-09-27T03:38:39.996Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%BB%91%E8%B2%93",
          snapshot: "sources/wiki/pages/c3f1e424d056212b.json",
          capturedAt: "2026-09-27T03:38:39.996Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%BB%91%E8%B2%93",
          snapshot: "sources/wiki/pages/c3f1e424d056212b.json",
          capturedAt: "2026-09-27T03:38:39.996Z"
        }
      }
    },
    {
      id: "cf69a54ae9e2cbde",
      name: "异界人",
      kind: "characters",
      module: null,
      source: "facts/data/characters/cf69a54ae9e2cbde.json",
      sha256: "2847d111e6896aaf94640260365b6fb6fbe19dfd16d83c287a3429bd4c399e95",
      fields: {
        角色名: "异界人",
        初始区域: "神社",
        禁行区域: "医院",
        不安限度: "2",
        属性: [
          "学生",
          "少女"
        ],
        友好能力: [
          {
            text: "（友好4 1L1）使同一區域另外1名角色死亡。",
            threshold: 4,
            limitText: "1L1",
            oncePerLoop: true
          },
          {
            text: "（友好5 1L1）復活同一區域任意1具屍體。",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%95%B0%E7%95%8C%E4%BA%BA",
          snapshot: "sources/wiki/pages/c795fbe776bfb03e.json",
          capturedAt: "2026-09-27T03:33:55.718Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%95%B0%E7%95%8C%E4%BA%BA",
          snapshot: "sources/wiki/pages/c795fbe776bfb03e.json",
          capturedAt: "2026-09-27T03:33:55.718Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%95%B0%E7%95%8C%E4%BA%BA",
          snapshot: "sources/wiki/pages/c795fbe776bfb03e.json",
          capturedAt: "2026-09-27T03:33:55.718Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%95%B0%E7%95%8C%E4%BA%BA",
          snapshot: "sources/wiki/pages/c795fbe776bfb03e.json",
          capturedAt: "2026-09-27T03:33:55.718Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%95%B0%E7%95%8C%E4%BA%BA",
          snapshot: "sources/wiki/pages/c795fbe776bfb03e.json",
          capturedAt: "2026-09-27T03:33:55.718Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%95%B0%E7%95%8C%E4%BA%BA",
          snapshot: "sources/wiki/pages/c795fbe776bfb03e.json",
          capturedAt: "2026-09-27T03:33:55.718Z"
        }
      }
    },
    {
      id: "a43b6f1d6f19cac0",
      name: "医生",
      kind: "characters",
      module: null,
      source: "facts/data/characters/a43b6f1d6f19cac0.json",
      sha256: "c7f12938984c5cbcdee67a4ace53e547ae89c8ac34f3b50eb7171578bfbea861",
      fields: {
        角色名: "医生",
        初始区域: "医院",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "成人",
          "男性"
        ],
        友好能力: [
          {
            text: "（友好2）放置/移除同一區域另外1名角色身上的1枚不安指示物。如果本角色的身份帶有無視友好的特性，並且身上已经放置了2枚或以上的友好指示物，則劇作家可以在劇作家能力階段使用該能力。",
            threshold: 2,
            limitText: ""
          },
          {
            text: "（友好3）本輪輪迴中，住院患者不再擁有禁行區域，可以移動至醫院之外。",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%86%AB%E7%94%9F",
          snapshot: "sources/wiki/pages/cea34a866abb4b3b.json",
          capturedAt: "2026-09-27T03:38:02.938Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%86%AB%E7%94%9F",
          snapshot: "sources/wiki/pages/cea34a866abb4b3b.json",
          capturedAt: "2026-09-27T03:38:02.938Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%86%AB%E7%94%9F",
          snapshot: "sources/wiki/pages/cea34a866abb4b3b.json",
          capturedAt: "2026-09-27T03:38:02.938Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%86%AB%E7%94%9F",
          snapshot: "sources/wiki/pages/cea34a866abb4b3b.json",
          capturedAt: "2026-09-27T03:38:02.938Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%86%AB%E7%94%9F",
          snapshot: "sources/wiki/pages/cea34a866abb4b3b.json",
          capturedAt: "2026-09-27T03:38:02.938Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E9%86%AB%E7%94%9F",
          snapshot: "sources/wiki/pages/cea34a866abb4b3b.json",
          capturedAt: "2026-09-27T03:38:02.938Z"
        }
      }
    },
    {
      id: "f497855359fe9b6e",
      name: "Haunted Stage Again",
      kind: "modules",
      module: "HSA",
      source: "facts/data/modules/f497855359fe9b6e.json",
      sha256: "c18c6463d6fd0e1af4d182a61e87976a39b604e77b7329da89370cbc56161281",
      fields: {
        special: "Haunted Stage Again 的特殊规则如下\n  牺牲者\n  放置在版图上的[密谋]视作身份为平民的尸体\n  群众事件\n  群众事件属于一种事件特性。\n  群众事件的当事人并非1名角色，而是指定了1块版图，所指定的版图中所有群众即为事件的当事人（例：「诅咒活化」当事人被指定为「学校群众」）\n  当版图中有着等于或超过事件规定的尸体数量时，事件就会发生\n  （版图上的[密谋]也视作尸体）\n  诅咒牌\n  诅咒牌使用Ex牌来表示，有位于版图上（地缚灵）和位于角色卡上（附身）两种状态。如果诅咒牌位于角色卡牌上，则将其叠放在对应卡牌来表示。\n  在每回合的回合结束阶段，所有诅咒牌必须分别依照所处状态决定效果并同时进行处理（该处理优先于其余所有处理）。\n  诅咒牌位于版图上\n  选择同区域的1名角色，将诅咒牌堆叠在那名角色身上。\n  诅咒牌位于卡牌上\n  无论当前卡牌的生死状态，尝试杀害带有诅咒牌的卡牌。\n  随后，无论该卡牌在处理后是否依然生存，均将诅咒牌取下，放置于该卡牌所在的版图上。"
      },
      provenance: {
        special: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "051fae99eb631f36",
      name: "高贵的血族",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/051fae99eb631f36.json",
      sha256: "4c502dc92e885f763e01d15392c89caeed2a78408696f2da196c2f23f334fe5a",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          吸血鬼: "①"
        },
        effect: "【强制：剧本制作时】吸血鬼与关键人物必须互为异性"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "2747b8874d11f53e",
      name: "月夜凶兽",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/2747b8874d11f53e.json",
      sha256: "7b4402084fa02d024d06a0a0e25259752cd3304a5c869edb3fa01b41ff97fe8c",
      fields: {
        ruleType: "Y",
        identityCounts: {
          狼人: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "bb09380573cf9f20",
      name: "雾中夜惊梦",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/bb09380573cf9f20.json",
      sha256: "f014cbfff83c7dc3d44cece695b8082ddf131c987f5b7272c2e0312ebbab186e",
      fields: {
        ruleType: "Y",
        identityCounts: {
          梦魇: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "3c9c6487b3400eca",
      name: "古墓活尸",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/3c9c6487b3400eca.json",
      sha256: "d11f8a2324ae3c97f9aaf41f2119af2fad20dc3184af4cb5916ac4a9c8bc2d80",
      fields: {
        ruleType: "Y",
        identityCounts: {},
        effect: "【强制：常驻】平民、胆小鬼和纸老虎的尸体身份变为丧尸"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "abcb39b33989d430",
      name: "被诅咒的土地",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/abcb39b33989d430.json",
      sha256: "26cd0ff4b239ed5c51ba8139410f83512043fe9b3494526c70d5ac886c2434c5",
      fields: {
        ruleType: "Y",
        identityCounts: {
          鬼魂: "①",
          纸老虎: "①"
        },
        effect: "【任意能力：轮回开始时】往鬼魂的初始区域对应的版图上放置1张诅咒牌\n【任意能力：回合结束阶段】本回合结束阶段结算诅咒牌时，1张或以上位于版图上的诅咒牌没有目标角色可以放置→主人公死亡"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "e4ddf95a3f9c20a0",
      name: "心慌派对",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/e4ddf95a3f9c20a0.json",
      sha256: "0ec56f5728a25d8dff22df6c6e08db8b2553caed80d7afe33205d5a39cc3f0b8",
      fields: {
        ruleType: "X",
        identityCounts: {
          鬼魂: "①",
          杀人狂: "①",
          求爱者: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "45321bcc4f69180f",
      name: "恋爱风景线",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/45321bcc4f69180f.json",
      sha256: "d7676044b8ea052cb9511bf8c68cd971ee364c4e1fa5109c8d94bf9114ed72a3",
      fields: {
        ruleType: "X",
        identityCounts: {
          求爱者: "①",
          心上人: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "bff7b9c362398fb9",
      name: "魔女遗咒",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/bff7b9c362398fb9.json",
      sha256: "af8f9e2a66c6d960ba9aad95e426b33545eeefba2d2b9c9f3f70330314807ac1",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①",
          魔女: "①"
        },
        effect: "【任意能力：轮回开始时】往魔女的初始区域对应的版图上放置1张诅咒牌"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "1c5b907b67675a2b",
      name: "少女大危机",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/1c5b907b67675a2b.json",
      sha256: "6c8d396410838d3c5f3b69eb400eba00575b3bcfc61d97b9896f461b6e608619",
      fields: {
        ruleType: "X",
        identityCounts: {
          关键人物: "①"
        },
        effect: "【强制：剧本制作时】关键人物必须有少女属性"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "c54e42173d3b25d1",
      name: "怪物们的阴谋",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/c54e42173d3b25d1.json",
      sha256: "2b564680e3a5ef2fc053583d52591f85343ebbeb2758dfa1317b5836d150d97f",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【任意能力：剧作家能力阶段】往拥有无视友好身份特性的角色所在版图放置1枚[密谋]（每日限1次，每轮限2次）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "5f97a666e019e613",
      name: "恐慌与妄想",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/5f97a666e019e613.json",
      sha256: "c21bdac9ae5f3ed6b81def9207760a7bd6673ff9381677307763ad600b86dc23",
      fields: {
        ruleType: "X",
        identityCounts: {
          杀人狂: "①",
          胆小鬼: "①",
          魔女: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "be0e4a29dde10659",
      name: "不听劝的人",
      kind: "rules",
      module: "HSA",
      source: "facts/data/rules/be0e4a29dde10659.json",
      sha256: "b650df33efaace814353d7b34114792cafae374afa2da21d02fad81829ee63c8",
      fields: {
        ruleType: "X",
        identityCounts: {
          纸老虎: "①",
          传谣人: "①",
          胆小鬼: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "ccf044bc55274c1b",
      name: "关键人物",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/ccf044bc55274c1b.json",
      sha256: "7fd01e8953c832d0f3b71804b784dcfd8787441531469c9d204bbbb64fe418ce",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "995352e45ad86fd5",
      name: "吸血鬼",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/995352e45ad86fd5.json",
      sha256: "00a6fd4d04baa72ebd444a93d0ebfb4f66c327346a96ed826f22412ae040bd4a",
      fields: {
        max: "",
        traits: "无视友好\n\n不死",
        abilities: [
          "【任意能力：回合结束阶段】同一区域1名关键人物身上有2枚或以上[密谋]→那名关键人物死亡",
          "【任意能力：回合结束阶段】该角色的初始区域有2具或以上的尸体→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "dc51de509aec2603",
      name: "狼人",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/dc51de509aec2603.json",
      sha256: "0fe35c220411d3268dca2228c2fa29ebf0f9709e335f17733184172d73d2e352",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：回合结束阶段】本回合曾发生过[疯狂之夜]事件→主人公死亡",
          "【强制：常驻】剧作家不可以往该角色身上设置任何行动卡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "9156abc37041e638",
      name: "梦魇",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/9156abc37041e638.json",
      sha256: "5296cefd54264964b69484ec8e5f7402d52affe9a3798f0fd3f6a972cf12a1ae",
      fields: {
        max: "",
        traits: "无视友好\n\n不死",
        abilities: [
          "【任意能力：回合结束阶段】与该角色位于同一区域的1名角色死亡",
          "【任意能力：回合结束阶段】所有尸体上放置的[密谋]总数为3枚或以上→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "42b203e3dcdebbaa",
      name: "鬼魂",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/42b203e3dcdebbaa.json",
      sha256: "32c34957fd7c24e4c80d771ac5f7b15dfdb623209d1b06c3a7a52f68ce240914",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【强制：剧作家能力阶段】如果该卡牌为死亡状态→往位于同一区域或该卡牌初始区域的1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "717c05dfb419f3c2",
      name: "纸老虎",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/717c05dfb419f3c2.json",
      sha256: "812f94e5d110ca5c212ca9148f404e82b5a637e1a8868bb1e940f449b762ad4c",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【强制：常驻】该角色身上有2枚或以上的[不安]→该角色失去不死的身份特性，获得必定无视友好的身份特性"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "120bfedd8751fe87",
      name: "传谣人",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/120bfedd8751fe87.json",
      sha256: "c262bf2d2c9d2d1986199a8f8d6c1205a08329d7816a319ad52409a17a34c559",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "19f7c8c961d88672",
      name: "杀人狂",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/19f7c8c961d88672.json",
      sha256: "3d9fdffe1578efcf1aa2ef6615d71c0b875d56c98e624ef411f79053d24e66f3",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "ee34aaaaeaf2dfd7",
      name: "胆小鬼",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/ee34aaaaeaf2dfd7.json",
      sha256: "c5d2dd60e199df985a21d37be384ef8f5e3d4fcb24d84b84d8deaf82e1544fdb",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：剧作家能力阶段】该角色身上有2枚或以上的[不安]→选择1块相邻版图，将该角色移动至那块版图"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "5394a332fa2a9911",
      name: "魔女",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/5394a332fa2a9911.json",
      sha256: "7b99b4f030cb537e0320926f4705bbc525e2d4458230cab61e3b8bfe1e65c6b0",
      fields: {
        max: "",
        traits: "必定无视友好"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "f9298ae5b7b7a0bb",
      name: "求爱者",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/f9298ae5b7b7a0bb.json",
      sha256: "7c30974a507080ed3dbf2b343eab05f21e97703e17ec9c68ebf5f6dd4ba39958",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：心上人死亡时】往该角色身上放置6枚[不安]",
          "【任意能力：回合结束阶段】该角色身上有1枚或以上[密谋]且有3枚或以上[不安]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "11fe8ae6866fc77e",
      name: "心上人",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/11fe8ae6866fc77e.json",
      sha256: "d56fb87f6674ffda28a2d1027e37d6fae87839972e79858c826f19fb8c2a9493",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：求爱者死亡时】往该角色身上放置6枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "8178e701be778aba",
      name: "丧尸",
      kind: "identities",
      module: "HSA",
      source: "facts/data/identities/8178e701be778aba.json",
      sha256: "bb3ad91c517fa9171974dbe3eda60a88e7d2139994f2acca9316fc668eb86040",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】选择1块丧尸数量大于非丧尸的角色数量，且至少有1名角色存活的版图→使该版图中的1名角色死亡（所有丧尸合计，每日限1次）",
          "【任意能力：回合结束阶段】将1具身份为丧尸的尸体移动至相邻版图（所有丧尸合计，每日限1次）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "4ad09fcaf450629b",
      name: "亵渎杀人",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/4ad09fcaf450629b.json",
      sha256: "a8c9b541e9bb1d7d230dec7416453aa4d4fffbf604462916ae4ba45093a39a81",
      fields: {
        effect: "与当事人位于同一区域的另外1名角色死亡，或往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "a34d1082256d96ac",
      name: "不安扩散",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/a34d1082256d96ac.json",
      sha256: "bb2df15939a7989bae21bdd6958cc246df87aabca930468a0c5b3f31864c0590",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "9349b96b18beff2b",
      name: "失踪",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/9349b96b18beff2b.json",
      sha256: "28748a283813d53eeb7f660c41688a5fa11c9d0ca43887038d332df35489efd2",
      fields: {
        effect: "将当事人移动至任意版图，随后，往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "ec0c9ce4aba8a133",
      name: "邪气污染",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/ec0c9ce4aba8a133.json",
      sha256: "29cf9fefec303d892daf19adb4d19869b3ed1fbb3acd1c787acdfef68534d624",
      fields: {
        effect: "往神社放置2枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "e67f4b5c421dc040",
      name: "送葬",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/e67f4b5c421dc040.json",
      sha256: "0d91b163070c8dd78db5ca78d5f101ee73abb6d641b3c0f9d381f2c93b1cede7",
      fields: {
        effect: "<当事人不安限度-1>队长选择1名角色，那名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "5e9461d7ed91a550",
      name: "言灵诅咒",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/5e9461d7ed91a550.json",
      sha256: "0117379f19af23734783a0982f254ddd5482c93b9606679744be7a45f7eee0db",
      fields: {
        effect: "往当事人身上放置1张Ex牌"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "89c442d63a7fd821",
      name: "孤守",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/89c442d63a7fd821.json",
      sha256: "3a7a4b84da8ed5f924181efd3693b11bb7363e3d3f75846c7cca203ac2299afc",
      fields: {
        effect: "将与当事人位于同一区域的其它所有角色分别移动至其它任意版图"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "0fda148ecc724379",
      name: "疯狂之夜",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/0fda148ecc724379.json",
      sha256: "a805268e94d85a415bac02234ee6889c2489cd95d1fcfba9d95b29a9291aaf5a",
      fields: {
        effect: "<群众事件><必要尸体数0>该事件发生时，游戏中有6具或以上的丧尸→本回合的回合结束阶段时，主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "cb784c537b628fd7",
      name: "诅咒活化",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/cb784c537b628fd7.json",
      sha256: "001cc3405b713903c8bb810c0870cebdc5c15663d736cd6c10da7ee9e1d8c525",
      fields: {
        effect: "<群众事件><必要尸体数1>往当事人所在版图放置Ex牌"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "b9a0ea7913498549",
      name: "污秽溢出",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/b9a0ea7913498549.json",
      sha256: "3e7201b1f914e28c0c233af2fd9712ef7f0e56e3a0bccca23f80b131ecf48345",
      fields: {
        effect: "<群众事件><必要尸体数2>往任意1名角色身上放置2枚[不安]，随后往任意1块版图上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "f951bcfe712e6c71",
      name: "死者默示录",
      kind: "incidents",
      module: "HSA",
      source: "facts/data/incidents/f951bcfe712e6c71.json",
      sha256: "b1004baf37a108e9997eb1b6dbb67f1cb5970286fdd35077b6afb24462a58a0d",
      fields: {
        effect: "<群众事件><必要尸体数2>使当事人所在版图中的所有角色死亡                                                                            \n之后，如果当事人所在版图有5具或以上的尸体，则主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Haunted_Stage_Again",
          snapshot: "sources/wiki/pages/da682a376d9880ab.json",
          capturedAt: "2026-09-27T03:29:42.114Z"
        }
      }
    },
    {
      id: "b824293e4a0ce969",
      name: "模仿犯",
      kind: "characters",
      module: null,
      source: "facts/data/characters/b824293e4a0ce969.json",
      sha256: "9a5983fb2957e42adba3ef126b0fb69952a81ff92b90b2f9d7bf481489c4bfe3",
      fields: {
        角色名: "模仿犯",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "2",
        属性: [
          "学生",
          "少年"
        ],
        特性: "剧本制作时，该角色不参与剧本所选规则的身份分配，但不直接视作平民，而是选择剧本中的另外1名角色、将那名角色的身份额外分配给该角色（此时，无视模组规定的剧本身份上限）",
        友好能力: [
          {
            text: "（友好3）必須在第2輪輪迴或之後才可以使用。公開场上与该角色身份相同的所有角色名。即使帶有無視友好特性，也不能拒絕使用該能力。",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%A8%A1%E4%BB%BF%E7%8A%AF",
          snapshot: "sources/wiki/pages/db932f1e0b7931b7.json",
          capturedAt: "2026-09-27T03:33:09.237Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%A8%A1%E4%BB%BF%E7%8A%AF",
          snapshot: "sources/wiki/pages/db932f1e0b7931b7.json",
          capturedAt: "2026-09-27T03:33:09.237Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%A8%A1%E4%BB%BF%E7%8A%AF",
          snapshot: "sources/wiki/pages/db932f1e0b7931b7.json",
          capturedAt: "2026-09-27T03:33:09.237Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%A8%A1%E4%BB%BF%E7%8A%AF",
          snapshot: "sources/wiki/pages/db932f1e0b7931b7.json",
          capturedAt: "2026-09-27T03:33:09.237Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%A8%A1%E4%BB%BF%E7%8A%AF",
          snapshot: "sources/wiki/pages/db932f1e0b7931b7.json",
          capturedAt: "2026-09-27T03:33:09.237Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%A8%A1%E4%BB%BF%E7%8A%AF",
          snapshot: "sources/wiki/pages/db932f1e0b7931b7.json",
          capturedAt: "2026-09-27T03:33:09.237Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E6%A8%A1%E4%BB%BF%E7%8A%AF",
          snapshot: "sources/wiki/pages/db932f1e0b7931b7.json",
          capturedAt: "2026-09-27T03:33:09.237Z"
        }
      }
    },
    {
      id: "e590494969ec7284",
      name: "职员",
      kind: "characters",
      module: null,
      source: "facts/data/characters/e590494969ec7284.json",
      sha256: "4b5a48809dd91e2edd98504fb5d4231b08076bab085f2327b7ab383626edd58a",
      fields: {
        角色名: "职员",
        初始区域: "都市",
        禁行区域: "学校",
        不安限度: "2",
        属性: [
          "男性",
          "成人"
        ],
        友好能力: [
          {
            text: "（友好3）公開該角色的身份。",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%81%B7%E5%93%A1",
          snapshot: "sources/wiki/pages/de633317ee358d2c.json",
          capturedAt: "2026-09-27T03:34:07.891Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%81%B7%E5%93%A1",
          snapshot: "sources/wiki/pages/de633317ee358d2c.json",
          capturedAt: "2026-09-27T03:34:07.891Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%81%B7%E5%93%A1",
          snapshot: "sources/wiki/pages/de633317ee358d2c.json",
          capturedAt: "2026-09-27T03:34:07.891Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%81%B7%E5%93%A1",
          snapshot: "sources/wiki/pages/de633317ee358d2c.json",
          capturedAt: "2026-09-27T03:34:07.891Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%81%B7%E5%93%A1",
          snapshot: "sources/wiki/pages/de633317ee358d2c.json",
          capturedAt: "2026-09-27T03:34:07.891Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%81%B7%E5%93%A1",
          snapshot: "sources/wiki/pages/de633317ee358d2c.json",
          capturedAt: "2026-09-27T03:34:07.891Z"
        }
      }
    },
    {
      id: "96847c4f07faea8f",
      name: "仙人",
      kind: "characters",
      module: null,
      source: "facts/data/characters/96847c4f07faea8f.json",
      sha256: "584d0db1a1968c0af6bddfddcc25463c7ac5f003846d89485f07315a0602c088",
      fields: {
        角色名: "仙人",
        初始区域: "神社/医院（由剧本规定）",
        禁行区域: "无",
        不安限度: "X(见特性)",
        属性: [
          "成人",
          "男性"
        ],
        特性: "X為劇本規定的數值。在事件判定之外需要參照該角色的不安限度時，該角色的不安限度視為0。\n\n結算該角色擔任當事人的事件時，該角色可以視為位於本來所在位置順時針相鄰的版圖。",
        友好能力: [
          {
            text: "（友好5 1L1）將該角色移動至任意版圖或遠方。隨後，復活同一區域任意1具屍體，並在那張卡牌上放置X枚友好指示物。",
            threshold: 5,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BB%99%E4%BA%BA",
          snapshot: "sources/wiki/pages/eaaeb6a171192df1.json",
          capturedAt: "2026-09-27T03:30:24.630Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BB%99%E4%BA%BA",
          snapshot: "sources/wiki/pages/eaaeb6a171192df1.json",
          capturedAt: "2026-09-27T03:30:24.630Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BB%99%E4%BA%BA",
          snapshot: "sources/wiki/pages/eaaeb6a171192df1.json",
          capturedAt: "2026-09-27T03:30:24.630Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BB%99%E4%BA%BA",
          snapshot: "sources/wiki/pages/eaaeb6a171192df1.json",
          capturedAt: "2026-09-27T03:30:24.630Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BB%99%E4%BA%BA",
          snapshot: "sources/wiki/pages/eaaeb6a171192df1.json",
          capturedAt: "2026-09-27T03:30:24.630Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BB%99%E4%BA%BA",
          snapshot: "sources/wiki/pages/eaaeb6a171192df1.json",
          capturedAt: "2026-09-27T03:30:24.630Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E4%BB%99%E4%BA%BA",
          snapshot: "sources/wiki/pages/eaaeb6a171192df1.json",
          capturedAt: "2026-09-27T03:30:24.630Z"
        }
      }
    },
    {
      id: "b86d7b604593e663",
      name: "神灵",
      kind: "characters",
      module: null,
      source: "facts/data/characters/b86d7b604593e663.json",
      sha256: "60cadf09f8bef63f901387e00d9cea8f3af1727a21a102c077187a35a59d890c",
      fields: {
        角色名: "神灵",
        初始区域: "神社",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "男性",
          "女性"
        ],
        特性: "劇本製作時，指定該角色在第几轮轮回登場。在所指定的輪迴之前，該角色不会在轮回准备时配置上场。",
        友好能力: [
          {
            text: "（友好3 1L1）公開1個事件的當事人。",
            threshold: 3,
            limitText: "1L1",
            oncePerLoop: true
          },
          {
            text: "（友好5）移除同一區域任意1名角色身上，或者该角色所在版图上的1枚密謀指示物。",
            threshold: 5,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%A5%9E%E9%9D%88",
          snapshot: "sources/wiki/pages/eb2f04c87cbab5eb.json",
          capturedAt: "2026-09-27T03:33:58.846Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%A5%9E%E9%9D%88",
          snapshot: "sources/wiki/pages/eb2f04c87cbab5eb.json",
          capturedAt: "2026-09-27T03:33:58.846Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%A5%9E%E9%9D%88",
          snapshot: "sources/wiki/pages/eb2f04c87cbab5eb.json",
          capturedAt: "2026-09-27T03:33:58.846Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%A5%9E%E9%9D%88",
          snapshot: "sources/wiki/pages/eb2f04c87cbab5eb.json",
          capturedAt: "2026-09-27T03:33:58.846Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%A5%9E%E9%9D%88",
          snapshot: "sources/wiki/pages/eb2f04c87cbab5eb.json",
          capturedAt: "2026-09-27T03:33:58.846Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%A5%9E%E9%9D%88",
          snapshot: "sources/wiki/pages/eb2f04c87cbab5eb.json",
          capturedAt: "2026-09-27T03:33:58.846Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E7%A5%9E%E9%9D%88",
          snapshot: "sources/wiki/pages/eb2f04c87cbab5eb.json",
          capturedAt: "2026-09-27T03:33:58.846Z"
        }
      }
    },
    {
      id: "65616fb9bc763887",
      name: "临时工？",
      kind: "characters",
      module: null,
      source: "facts/data/characters/65616fb9bc763887.json",
      sha256: "dcf97868f6ee7f7c9111d717aac5945d95d610387b9bbca0243d9b0b265e9c9e",
      fields: {
        角色名: "临时工？\n\n【特殊】该角色不能在剧本制作时使用",
        初始区域: "都市",
        禁行区域: "无",
        不安限度: "3",
        属性: [
          "少女"
        ],
        特性: "该角色的身份以及事件当事人的配置与临时工的配置一致。",
        友好能力: [
          {
            text: "（友好3 1L1）公开该角色的身份，并选择同一区域的1名角色放置2枚友好指示物",
            threshold: 3,
            limitText: "1L1",
            oncePerLoop: true
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5%EF%BC%9F",
          snapshot: "sources/wiki/pages/edb4e01e31d65cb0.json",
          capturedAt: "2026-09-27T03:34:14.135Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5%EF%BC%9F",
          snapshot: "sources/wiki/pages/edb4e01e31d65cb0.json",
          capturedAt: "2026-09-27T03:34:14.135Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5%EF%BC%9F",
          snapshot: "sources/wiki/pages/edb4e01e31d65cb0.json",
          capturedAt: "2026-09-27T03:34:14.135Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5%EF%BC%9F",
          snapshot: "sources/wiki/pages/edb4e01e31d65cb0.json",
          capturedAt: "2026-09-27T03:34:14.135Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5%EF%BC%9F",
          snapshot: "sources/wiki/pages/edb4e01e31d65cb0.json",
          capturedAt: "2026-09-27T03:34:14.135Z"
        },
        特性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5%EF%BC%9F",
          snapshot: "sources/wiki/pages/edb4e01e31d65cb0.json",
          capturedAt: "2026-09-27T03:34:14.135Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E8%87%A8%E6%99%82%E5%B7%A5%EF%BC%9F",
          snapshot: "sources/wiki/pages/edb4e01e31d65cb0.json",
          capturedAt: "2026-09-27T03:34:14.135Z"
        }
      }
    },
    {
      id: "cc1ae91a23ef53af",
      name: "大小姐",
      kind: "characters",
      module: null,
      source: "facts/data/characters/cc1ae91a23ef53af.json",
      sha256: "53cf3caab396831e1a1d80335ab90a428426e20c77229c9df324670847a4d1f7",
      fields: {
        角色名: "大小姐",
        初始区域: "学校",
        禁行区域: "无",
        不安限度: "1",
        属性: [
          "学生",
          "少女"
        ],
        友好能力: [
          {
            text: "（友好3）必须位于学校或都市才可以使用，往同一区域任意1名角色身上放置1枚友好指示物",
            threshold: 3,
            limitText: ""
          }
        ]
      },
      provenance: {
        角色名: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E5%B0%8F%E5%A7%90",
          snapshot: "sources/wiki/pages/fba9ca06b8ed3e0b.json",
          capturedAt: "2026-09-27T03:31:42.355Z"
        },
        初始区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E5%B0%8F%E5%A7%90",
          snapshot: "sources/wiki/pages/fba9ca06b8ed3e0b.json",
          capturedAt: "2026-09-27T03:31:42.355Z"
        },
        禁行区域: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E5%B0%8F%E5%A7%90",
          snapshot: "sources/wiki/pages/fba9ca06b8ed3e0b.json",
          capturedAt: "2026-09-27T03:31:42.355Z"
        },
        不安限度: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E5%B0%8F%E5%A7%90",
          snapshot: "sources/wiki/pages/fba9ca06b8ed3e0b.json",
          capturedAt: "2026-09-27T03:31:42.355Z"
        },
        属性: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E5%B0%8F%E5%A7%90",
          snapshot: "sources/wiki/pages/fba9ca06b8ed3e0b.json",
          capturedAt: "2026-09-27T03:31:42.355Z"
        },
        友好能力: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%A4%A7%E5%B0%8F%E5%A7%90",
          snapshot: "sources/wiki/pages/fba9ca06b8ed3e0b.json",
          capturedAt: "2026-09-27T03:31:42.355Z"
        }
      }
    },
    {
      id: "4a58c0b98260d133",
      name: "Basic Tragedy X Plus",
      kind: "modules",
      module: "BTX+",
      source: "facts/data/modules/4a58c0b98260d133.json",
      sha256: "bbc8a813eeeb47073e2850c752ade73c36eea5ff7a39bc721a590e21876328d5",
      fields: {
        special: "+规则\n\n在十周年之前的模组中追加新的规则，事件和身份，加入这种规则的模组后面会带有+，目前可以采用+规则的模组有FS/BTX/MZ/MC/HSA/WM\n\n在原有的模组中追加一条新的规则X作为可选项\n\n超越世界线	传谣人1	【强制：轮回开始时】偶数轮轮回开始时，剧作家获得[绝望+1]，最终轮轮回开始时，主人公获得[希望+1]\n\n在原有的事件列表中加入2个事件可选项\n\n希望之光	<通过友好指示物判定是否发生>队长选择1名角色，那名角色放置1枚[希望]\n绝望之暗	往任意1名角色身上放置1枚[绝望]\n\n在所有身份分配完毕后，选择1名身份为平民的角色，将其身份变为因果残片，在最终决战时，那名角色被猜测为平民也算作正确\n\n因果残片			【强制：轮回开始时】若该角色上轮轮回结束时处于死亡状态→剧作家获得[绝望+1]\n【强制：轮回开始时】若该角色上轮轮回结束时存活并且身上有2枚或以上的[友好]，主人公获得[希望+1]\n希望指示物\n\n是一种指示物，拥有3种效果\n\n由于任何原因需要计算友好指示物的数量时，也计入该指示物数量\n\n由于任何原因需要计算密谋指示物的数量时，每有1枚该指示物就让计算结果-1（最终结果不能变为负数）\n\n带有该指示物的角色失去无视友好的特性\n\n绝望指示物\n\n是一种指示物，拥有3种效果\n\n由于任何原因需要计算不安指示物的数量时，也计入该指示物数量\n\n由于任何原因需要计算密谋指示物的数量时，也计入该指示物数量\n\n带有该指示物的角色获得必定无视友好特性"
      },
      provenance: {
        special: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%8D%81%E5%91%A8%E5%B9%B4%E8%A7%84%E5%88%99",
          snapshot: "sources/wiki/pages/64edfee587f8aad7.json"
        }
      }
    },
    {
      id: "da7d1a7118b09ed0",
      name: "谋杀计划",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/da7d1a7118b09ed0.json",
      sha256: "bb6321845a8cfbc0de29d4245adeff2ea7cb75f71d95bd7e16ba58dbe189ab87",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①",
          杀手: "①",
          主谋: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "4fc1ee2ae6e0bc6e",
      name: "被封印的邪灵",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/4fc1ee2ae6e0bc6e.json",
      sha256: "17f6259eaae25ca9819c933173722dbd6b1e54137e7e12bb558a287e84fca1d1",
      fields: {
        ruleType: "Y",
        identityCounts: {
          主谋: "①",
          邪教徒: "①"
        },
        effect: "【失败条件：轮回结束时】神社有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "e038ac0d23455068",
      name: "和我签订契约吧！",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/e038ac0d23455068.json",
      sha256: "8fd46ca362b85bae6204639c3a05d33b461e15d5015533af4c7bb805d06adbcb",
      fields: {
        ruleType: "Y",
        identityCounts: {
          关键人物: "①"
        },
        effect: "【强制：剧本制作时】关键人物必须有少女属性\n【失败条件：轮回结束时】关键人物有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "e4a0cd0aa63564f7",
      name: "改变未来",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/e4a0cd0aa63564f7.json",
      sha256: "5bd1e3fb4836412bd389aebce1960a2128e7d512b05ce9b52722ad5b7956230f",
      fields: {
        ruleType: "Y",
        identityCounts: {
          邪教徒: "①",
          时间旅者: "①"
        },
        effect: "【失败条件：轮回结束时】本轮轮回中引发过蝴蝶效应事件"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "a391d5cc115fc6d0",
      name: "巨大定时炸弹X",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/a391d5cc115fc6d0.json",
      sha256: "dcc8a75a0b300a6fa28f633fc6cd3d5ad965673b9b63261e8d9a89f65dfb0d1e",
      fields: {
        ruleType: "Y",
        identityCounts: {
          魔女: "①"
        },
        effect: "【失败条件：轮回结束时】魔女的初始区域有2枚或以上[密谋]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "90440298bbfe3e21",
      name: "好友圈",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/90440298bbfe3e21.json",
      sha256: "8ffe72a031b4df87db1b39fb574c7a97686e73156dcb5b51d85250efbb189e08",
      fields: {
        ruleType: "X",
        identityCounts: {
          亲友: "②",
          传谣人: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "80bdcbdda04cf9e2",
      name: "恋爱风景线",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/80bdcbdda04cf9e2.json",
      sha256: "b32d3eb1831e67b40168f642f86389fa3b7dfba7a587a2ccd85ec52ed82030a0",
      fields: {
        ruleType: "X",
        identityCounts: {
          心上人: "①",
          求爱者: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "daa43e78c1a95227",
      name: "潜伏的杀人狂",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/daa43e78c1a95227.json",
      sha256: "c79160f2826a50a18cc9fa91853fe38bd25b4ad14e0ca5545686f144e379fef6",
      fields: {
        ruleType: "X",
        identityCounts: {
          亲友: "①",
          杀人狂: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "4a49fba00763a8a2",
      name: "流言四起",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/4a49fba00763a8a2.json",
      sha256: "e149585e9954d55e5e7173a7234d7cb8b63a5406f31f07ddcc4f0066bf96c390",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【任意能力：剧作家能力阶段】往任意1块版图上放置1枚[密谋]（每轮限1次）"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "de77c1ff90d2fa65",
      name: "妄想扩大病毒",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/de77c1ff90d2fa65.json",
      sha256: "07f6fd411bdb76675d57217ff170373c2363c7602c5279c46f57c93074a932f7",
      fields: {
        ruleType: "X",
        identityCounts: {
          传谣人: "①"
        },
        effect: "【强制：常驻】某1名平民角色有3枚或以上[不安]时，那名平民身份变为杀人狂"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "adf6481d28708fc1",
      name: "因果线",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/adf6481d28708fc1.json",
      sha256: "4d55854ba495dbbf8bdeef2127e0accc3e47b6d7960fe4307b2380871e5ae3fa",
      fields: {
        ruleType: "X",
        identityCounts: {},
        effect: "【强制：轮回开始时】上轮轮回结束时所有带有[友好]的角色，全部放置2枚[不安]"
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "d5c393471abeb236",
      name: "未知因子Χ",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/d5c393471abeb236.json",
      sha256: "58e5153476f7543f8b963a6d0025f3f097b131fd05c946f684eaaf3694d822c1",
      fields: {
        ruleType: "X",
        identityCounts: {
          不安定因子: "①"
        },
        effect: ""
      },
      provenance: {
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        identityCounts: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "b21541202f90487d",
      name: "关键人物",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/b21541202f90487d.json",
      sha256: "58b07535be9687a8aedacf9f6cbf1da3d91e0d67aae11bafdf73cb1bd82bcbaa",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：该角色死亡时】主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "3d7bcae187f83e7a",
      name: "杀手",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/3d7bcae187f83e7a.json",
      sha256: "53af246041bdbc50e4253fbca9c6b6d52fad1e7e1278ab48e8689698578d53e3",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：回合结束阶段】同一区域1名关键人物身上有2枚或以上[密谋]→那名关键人物死亡",
          "【任意能力：回合结束阶段】该角色身上有4枚或以上[密谋]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "10087deae6274724",
      name: "主谋",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/10087deae6274724.json",
      sha256: "293e269a52c13c9ace54196ddda93c4cf487a7267890fc38d0a2669e5d5d3556",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域任意一名角色身上，或该角色所在的版图上放置1枚[密谋]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "95eb49fdfbe8cfab",
      name: "邪教徒",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/95eb49fdfbe8cfab.json",
      sha256: "81d598d078e4868b38293cdd76d8d1f05ae1667d02080b777bcb9ff6d0e4a4a4",
      fields: {
        max: "",
        traits: "必定无视友好",
        abilities: [
          "【任意能力：行动结算阶段】可以无效化同一区域中任意角色身上和该角色所在版图上放置的禁止密谋"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "cf7c2938ddfb7cff",
      name: "魔女",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/cf7c2938ddfb7cff.json",
      sha256: "7c61561cc3302532da7a47c55d4dd1569487a54321835aa9a25217896917d50e",
      fields: {
        max: "",
        traits: "必定无视友好"
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "774ead0e5d138a56",
      name: "时间旅者",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/774ead0e5d138a56.json",
      sha256: "3a26cce1a37f922cdcecd71a3e6c77458b8b6d826394c5e7978911bd85d94fac",
      fields: {
        max: "",
        traits: "不死",
        abilities: [
          "【强制：行动结算阶段】无视该角色身上放置的禁止友好",
          "【任意能力：最终日的回合结束阶段】该角色身上的[友好]为2枚或以下→主人公失败，当前轮回立即结束"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "23e5b9bdb2ad9a73",
      name: "亲友",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/23e5b9bdb2ad9a73.json",
      sha256: "1a0e0a954889b77aebe12dbc751cec9698a6f74e6099100a5072dd3b151900fb",
      fields: {
        max: "②",
        traits: "",
        abilities: [
          "【失败条件：轮回结束时】该卡牌为死亡状态，此时，需要告知主人公该卡牌的身份",
          "【强制：轮回开始时】该角色身份曾被公开→往该角色身上放置1枚[友好]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "c8545438a1288946",
      name: "心上人",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/c8545438a1288946.json",
      sha256: "4e764272ee71ad6d6cdc5161b90c85af62dfd2fd885a758d77aea6ed291a1f57",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：求爱者死亡时】往该角色身上放置6枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "dc1f1c12d7f47358",
      name: "求爱者",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/dc1f1c12d7f47358.json",
      sha256: "e71c957a196feac85aa0aa4924ceb72c21dd799c4d265ab6fbe1f30b88ffda98",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：心上人死亡时】往该角色身上放置6枚[不安]",
          "【任意能力：回合结束阶段】该角色身上有1枚或以上[密谋]且有3枚或以上[不安]→主人公死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "6e1b95b7f3a349e5",
      name: "杀人狂",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/6e1b95b7f3a349e5.json",
      sha256: "d7d6c9403d143416062cb4338268ba130749fa103aaa7fd8d0d2f242387874a5",
      fields: {
        max: "",
        traits: "",
        abilities: [
          "【强制：回合结束阶段】仅有1名角色与该角色位于同一区域→那名角色死亡"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "ab1a47c1d35dd210",
      name: "不安定因子",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/ab1a47c1d35dd210.json",
      sha256: "577dceda2d70769af3fda62e1983de0e23f016e6738a12d38065cdf384208ef0",
      fields: {
        max: "",
        traits: "无视友好",
        abilities: [
          "【强制：常驻】学校有2枚或以上[密谋]→该角色获得传谣人的能力（身份依然为[不安定因子]）",
          "【强制：常驻】都市有2枚或以上[密谋]→该角色获得关键人物的能力（身份依然为[不安定因子]）"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "34e4215b6c09cfc2",
      name: "传谣人",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/34e4215b6c09cfc2.json",
      sha256: "8c846eb63036b623f02fd7f0483d6dbe9f2c325b19233c46f7c99145b626f0b0",
      fields: {
        max: "①",
        traits: "",
        abilities: [
          "【任意能力：剧作家能力阶段】往同一区域中任意1名角色身上放置1枚[不安]"
        ]
      },
      provenance: {
        max: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        traits: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        },
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "d07826342d95e217",
      name: "不安扩散",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/d07826342d95e217.json",
      sha256: "55ac5a7c5a7e73c6d5cbca8f4dac0b2178418d981edf411c17335232f86056cd",
      fields: {
        effect: "往任意1名角色身上放置2枚[不安]，随后往另外1名角色身上放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "3456cf85502d79f2",
      name: "谋杀",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/3456cf85502d79f2.json",
      sha256: "6ab1c4027df508984ca8ee52c4255ace9fd8f6b1cbe0b5669c38b62f31f4e26e",
      fields: {
        effect: "与当事人位于同一区域的另外1名角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "6a57765b6eaeaa35",
      name: "邪气污染",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/6a57765b6eaeaa35.json",
      sha256: "cc7170b49e87e56b7171a33840f16ca58317a69a715c3d12539d003e018501f5",
      fields: {
        effect: "往神社放置2枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "dec2d2c1dd0b0810",
      name: "医院事故",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/dec2d2c1dd0b0810.json",
      sha256: "c0059e43bf4efba2b2f82f680067aefa452c450639758a581ae45e6969286d32",
      fields: {
        effect: "医院有1枚或以上[密谋]→位于医院的所有角色死亡\n医院有2枚或以上[密谋]→主人公死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "1c068a5c658eeec9",
      name: "自杀",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/1c068a5c658eeec9.json",
      sha256: "72667917ea770ab1cee529d460934c7d26c294da959876b19ba7929940c670a6",
      fields: {
        effect: "当事人死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "3d8c50280bfaa76a",
      name: "散播",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/3d8c50280bfaa76a.json",
      sha256: "2054e54383fd9370b195eb3c36d8d2c79d089c545286d638511e783c5c5c2566",
      fields: {
        effect: "从任意1名角色身上移除2枚[友好]，随后往另外1名角色身上放置2枚[友好]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "50f106f8cf855673",
      name: "蝴蝶效应",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/50f106f8cf855673.json",
      sha256: "57d564d95e0492557480f6fd5c38ff0c6680cddb0dcde17fd9caefa5eaf67495",
      fields: {
        effect: "选择与当事人位于同一区域的任意1名角色，往该角色身上放置1枚[友好]、[不安]或[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "821d092bfff09c7a",
      name: "失踪",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/821d092bfff09c7a.json",
      sha256: "98e2e4f0b74fe4592563b005efd16f50c6d1293d5584bd8aff4cef021032858c",
      fields: {
        effect: "将当事人移动至任意版图，随后，往当事人所在版图放置1枚[密谋]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "091df516f4a24856",
      name: "远距离杀人",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/091df516f4a24856.json",
      sha256: "cc97a6acf437b0881076a4641c5f64e30710d05e8d54dfcacefa7d56a8fc58ee",
      fields: {
        effect: "任意1名身上有2枚或以上[密谋]的角色死亡"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/Basic_Tragedy_X",
          snapshot: "sources/wiki/pages/1095c9f923c9c10c.json",
          capturedAt: "2026-09-27T03:28:29.736Z"
        }
      }
    },
    {
      id: "f0c01c3f2c727c84",
      name: "超越世界线",
      kind: "rules",
      module: "BTX+",
      source: "facts/data/rules/f0c01c3f2c727c84.json",
      sha256: "1f6112eb5e83a083be6add9c5f00d08146f91260c15f63ee50a9178c57c1b869",
      fields: {
        effect: "【强制：轮回开始时】偶数轮轮回开始时，剧作家获得[绝望+1]，最终轮轮回开始时，主人公获得[希望+1]",
        ruleType: "X",
        identityConfigurationText: "传谣人1"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%8D%81%E5%91%A8%E5%B9%B4%E8%A7%84%E5%88%99",
          snapshot: "sources/wiki/pages/64edfee587f8aad7.json"
        },
        ruleType: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%8D%81%E5%91%A8%E5%B9%B4%E8%A7%84%E5%88%99",
          snapshot: "sources/wiki/pages/64edfee587f8aad7.json"
        },
        identityConfigurationText: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%8D%81%E5%91%A8%E5%B9%B4%E8%A7%84%E5%88%99",
          snapshot: "sources/wiki/pages/64edfee587f8aad7.json"
        }
      }
    },
    {
      id: "2f7aa848dae6c6b5",
      name: "希望之光",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/2f7aa848dae6c6b5.json",
      sha256: "5c077cb025d52b7779631711e46b953c415dfd6df602a2977c8e0289e267bceb",
      fields: {
        effect: "<通过友好指示物判定是否发生>队长选择1名角色，那名角色放置1枚[希望]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%8D%81%E5%91%A8%E5%B9%B4%E8%A7%84%E5%88%99",
          snapshot: "sources/wiki/pages/64edfee587f8aad7.json"
        }
      }
    },
    {
      id: "9221c1d440afd0a9",
      name: "绝望之暗",
      kind: "incidents",
      module: "BTX+",
      source: "facts/data/incidents/9221c1d440afd0a9.json",
      sha256: "ad1bd6166d6ed670126d989572dc91ffdd920945af6e77ce270e74e26df58343",
      fields: {
        effect: "往任意1名角色身上放置1枚[绝望]"
      },
      provenance: {
        effect: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%8D%81%E5%91%A8%E5%B9%B4%E8%A7%84%E5%88%99",
          snapshot: "sources/wiki/pages/64edfee587f8aad7.json"
        }
      }
    },
    {
      id: "4b7f3ee2d44d796b",
      name: "因果残片",
      kind: "identities",
      module: "BTX+",
      source: "facts/data/identities/4b7f3ee2d44d796b.json",
      sha256: "9d3394f14752bcb5aea67f4a77d6cab2328fd1520edcadb172cdd35b32c37758",
      fields: {
        abilities: [
          "【强制：轮回开始时】若该角色上轮轮回结束时处于死亡状态→剧作家获得[绝望+1]",
          "【强制：轮回开始时】若该角色上轮轮回结束时存活并且身上有2枚或以上的[友好]，主人公获得[希望+1]"
        ]
      },
      provenance: {
        abilities: {
          provider: "wiki",
          url: "https://tragedyrooper.fandom.com/zh/wiki/%E5%8D%81%E5%91%A8%E5%B9%B4%E8%A7%84%E5%88%99",
          snapshot: "sources/wiki/pages/64edfee587f8aad7.json"
        }
      }
    }
  ]
};

// packages/content/src/foundation-decisions.json
var foundation_decisions_default = {
  schemaVersion: 1,
  date: "2026-11-08",
  authority: "project-user-decision",
  originalReply: "Q1 可以，多人则出现两个死亡请求在从者身上  Q2 A Q3A",
  clarification: "两项替代＋一项自身，合计三项",
  implementationStatus: "definitions-only-not-executed",
  decisions: [
    {
      id: "Q1",
      caseId: "R02",
      title: "同批多人替代死亡",
      status: "confirmed",
      summary: "从者可以同时替多名合格角色承受死亡请求。替代请求与自身直接请求分别计数，不合并。",
      semantics: {
        eligibilitySnapshot: "batch-entry",
        multipleProtectedTargets: true,
        requestCollection: "multiset",
        oneReplacementRequestPerProtectedDeathRequest: true,
        retainDirectRequests: true,
        commitActualDeaths: "after-all-requests-resolved",
        actualDeathTransitionsPerLivingCharacterPerBatch: 1
      },
      example: {
        servantDirectRequests: 1,
        replacementRequests: 2,
        totalRequests: 3,
        guardCancelledRequests: 1,
        unblockedRequests: 2,
        actualServantDeaths: 1,
        protectedCharactersSurvive: true
      },
      sources: ["character.servant", "faq.substitute-guard", "faq.immortal-guard", "faq.substitute-immortal"]
    },
    {
      id: "Q2",
      caseId: "R03",
      title: "轮回立即结束的收尾边界",
      status: "confirmed",
      summary: "先记录轮回结束要求，完成当前已成立的同时效果及其已到时点的强制后续；未开始的随后步骤和新的任意能力不再开始。来源全部文本完成才产生完成通知。",
      semantics: {
        endRequest: "latch-when-raised",
        settleEstablishedBatch: true,
        drainDueMandatoryFollowups: true,
        startUnstartedThenStep: false,
        startNewOptionalAbility: false,
        sourceCompletion: "all-source-text-finished-without-interruption",
        completionFollowups: "inside-current-step-cleanup",
        scope: "loop-end-not-game-victory"
      },
      sources: ["general.interrupt", "general.completion", "faq.fool-hospital", "faq.fool-horrific"]
    },
    {
      id: "Q3",
      caseId: "R04",
      title: "跨轮快照边界",
      status: "confirmed",
      summary: "上轮全部结束处理完成后、清盘复原前保存快照；本轮恢复普通状态后，按当前登场情况执行跨轮效果。",
      semantics: {
        previousLoopSnapshot: "after-loop-end-processing-before-reset",
        includeLoopEndChanges: true,
        nextLoopOrder: ["normal-reset-and-placement", "loop-start-effects"],
        causalLineEligibility: "previous-effective-goodwill-and-current-presence-with-explicit-exceptions",
        firstLoopPreviousSnapshot: null
      },
      sources: ["btx.causal", "conflict.causal-scope", "faq.causal-transfer", "faq.causal-parttimer", "faq.causal-dead", "faq.causal-removed", "faq.causal-hope"]
    }
  ]
};

// packages/content/src/official/programs.ts
var eq = (a, b) => ({ cmp: "eq", left: a, right: b });
var ge = (a, b) => ({ cmp: "ge", left: a, right: b });
var le = (a, b) => ({ cmp: "le", left: a, right: b });
var field = (field2, target = "$it") => ({ field: field2, target });
var count = (counter, target = "$self") => ({
  counter,
  target
});
var all = (...conditions) => ({ all: conditions });
var other = { cmp: "ne", left: { ref: "$it" }, right: { ref: "$self" } };
var together = eq(field("area"), field("area", "$self"));
var alive = (where) => ({ kind: "alive", where });
var co = (more = true) => alive(all(together, more));
var another = (more = true) => co(all(other, more));
var add = (target, counter, amount) => ({ op: "counter", target, counter, amount });
var when = (condition, ...effects) => ({ op: "when", condition, effects });
var each = (selector, ...effects) => ({ op: "each", selector, effects });
var choice = (options2, effects, key = "target", actor) => ({ choices: [{ key, options: options2, actor }], effects });
var simple = (...effects) => ({ effects });
var stepAbility = (id, timing, steps, extra = {}) => ({ id, source: "", timing, steps, ...extra });
var optional = (id, steps, extra = {}) => stepAbility(id, "mastermind-abilities", steps, extra);
var mandatory = (id, timing, effects, extra = {}) => stepAbility(id, timing, [simple(...effects)], { mandatory: true, ...extra });
var good = (id, threshold, steps, extra = {}) => stepAbility(id, "protagonist-abilities", steps, { threshold, ...extra });
var kill = { op: "kill", target: "$target" };
var pd = { op: "protagonist-death" };
var fail = { op: "fail" };
var reveal = { op: "reveal-identity", target: "$target" };
var student = { attribute: "学生", target: "$it" };
var upset = ge(count("paranoia", "$it"), { field: "paranoiaLimit", target: "$it" });
function identityPrograms(name) {
  switch (name) {
    case "平民":
    case "魔女":
    case "暴徒":
    case "永生者":
    case "不安定因子":
    case "无面者":
    case "因果残片":
      return [];
    case "关键人物":
      return [mandatory("key-death", "death", [fail])];
    case "传谣人":
      return [optional("gossip", [choice(co(), [add("$target", "paranoia", 1)])])];
    case "主谋":
      return [
        optional("brain", [
          choice({ kind: "alive-or-boards", where: eq(field("area"), field("area", "$self")) }, [
            add("$target", "intrigue", 1)
          ])
        ])
      ];
    case "邪教徒":
      return [
        stepAbility("cultist", "card-resolution", [
          simple({ op: "flag", target: "$self", key: "cultist" })
        ])
      ];
    case "杀手":
      return [
        stepAbility("killer-character", "day-end", [
          choice(co(all(eq(field("identity"), "关键人物"), ge(count("intrigue", "$it"), 2))), [
            kill
          ])
        ]),
        stepAbility("killer-protagonists", "day-end", [simple(pd)], {
          condition: ge(count("intrigue"), 4)
        })
      ];
    case "杀人狂":
      return [
        mandatory("serial-killer", "day-end", [each(another(), { op: "kill", target: "$it" })], {
          condition: eq({ count: another() }, 1)
        })
      ];
    case "亲友":
      return [
        mandatory("friend-dead", "loop-end", [{ op: "reveal-identity", target: "$self" }, fail], {
          condition: eq(field("status", "$self"), "dead")
        })
      ];
    case "心上人":
      return [];
    case "求爱者":
      return [
        stepAbility("lover-kill", "day-end", [simple(pd)], {
          condition: all(ge(count("intrigue"), 1), ge(count("paranoia"), 3))
        })
      ];
    case "时间旅者":
      return [
        stepAbility("time-traveler", "day-end", [simple(fail)], {
          condition: all(eq({ game: "day" }, { game: "days" }), le(count("goodwill"), 2))
        })
      ];
    case "强迫症":
    case "预言家":
    case "侦探":
    case "双胞胎":
      return [];
    case "忍者":
      return [
        stepAbility("ninja-kill", "day-end", [choice(co(ge(count("intrigue", "$it"), 2)), [kill])])
      ];
    case "吸血鬼":
      return [
        identityPrograms("杀手")[0],
        stepAbility("vampire-corpses", "day-end", [simple(pd)], {
          condition: ge(
            { count: { kind: "dead", where: eq(field("area"), { ref: "$self.initialArea" }) } },
            2
          )
        })
      ];
    case "狼人":
      return [
        stepAbility("werewolf", "day-end", [simple(pd)], {
          condition: { flag: "mad-night-today" }
        })
      ];
    case "梦魇":
      return [
        stepAbility("nightmare-kill", "day-end", [choice(co(), [kill])]),
        stepAbility("nightmare-corpses", "day-end", [simple(pd)], {
          condition: ge({ sum: { kind: "dead" }, value: count("intrigue", "$it") }, 3)
        })
      ];
    case "纸老虎":
    case "丧尸":
      return [];
    case "鬼魂":
      return [
        stepAbility(
          "ghost",
          "mastermind-abilities",
          [
            choice(alive({ any: [together, eq(field("area"), { ref: "$self.initialArea" })] }), [
              add("$target", "paranoia", 1)
            ])
          ],
          { mandatory: true, condition: eq(field("status", "$self"), "dead") }
        )
      ];
    case "提线木偶":
      return [
        mandatory(
          "puppet-completed",
          "goodwill-completed",
          [{ op: "kill", target: "$self" }, { op: "world-move" }],
          { condition: ge({ field: "kinds", target: "$self" }, 2) }
        )
      ];
    case "叙述者":
      return [
        optional(
          "narrator-transfer",
          [
            {
              choices: [
                { key: "from", options: another() },
                {
                  key: "to",
                  options: another({ cmp: "ne", left: { ref: "$it" }, right: { ref: "$from" } })
                },
                {
                  key: "counter",
                  options: ["goodwill", "paranoia", "intrigue", "guard", "hope", "despair"]
                }
              ],
              effects: [{ op: "transfer", from: "$from", to: "$to", counter: "$counter" }]
            }
          ],
          { condition: ge({ game: "ex" }, 1) }
        )
      ];
    case "童谣":
      return [
        optional(
          "fairytale-counter",
          [
            {
              choices: [
                { key: "target", options: co() },
                { key: "counter", options: ["goodwill", "paranoia"] }
              ],
              effects: [{ op: "counter", target: "$target", counter: "$counter", amount: 1 }]
            }
          ],
          { loopLimit: 1 }
        ),
        stepAbility("fairytale-kill", "day-end", [simple(pd)], {
          condition: ge({ field: "kinds", target: "$self" }, 4)
        })
      ];
    case "次元旅者":
      return [
        stepAbility("dimension-traveler", "day-end", [simple(pd)], {
          condition: all(
            eq({ game: "day" }, { game: "days" }),
            le({ field: "kinds", target: "$self" }, 2)
          )
        })
      ];
    case "魔笛手":
      return [
        stepAbility("piper-kill", "day-end", [choice(co(), [kill])], {
          mandatory: true,
          loopLimit: 1,
          condition: ge({ game: "ex" }, 2)
        }),
        stepAbility("piper-intrigue", "day-end", [
          choice({ kind: "dead", where: together }, [add("$target", "intrigue", 1)]),
          simple(when(ge({ sum: { kind: "dead" }, value: count("intrigue", "$it") }, 3), pd))
        ])
      ];
    case "布道者":
      return [
        optional("evangelist-goodwill", [choice(co(), [add("$target", "goodwill", 1)])]),
        stepAbility(
          "evangelist-death",
          "death",
          [
            choice(co(), [add("$target", "despair", 1)]),
            {
              choices: [{ key: "move", options: ["yes", "no"] }],
              effects: [when(eq({ ref: "$move" }, "yes"), { op: "world-move" })]
            }
          ],
          { mandatory: true }
        )
      ];
    case "爱丽丝":
      return [
        mandatory("alice-dead", "loop-end", [fail], {
          condition: eq(field("status", "$self"), "dead")
        }),
        mandatory(
          "alice-goodwill",
          "goodwill-completed",
          [each(another(), add("$it", "hope", 1))],
          { loopLimit: 1, condition: ge({ game: "ex" }, 1) }
        )
      ];
    case "监视者":
    case "怪杰":
      return [];
    case "密钥":
      return [
        mandatory("key-reveal-death", "death", [{ op: "reveal-identity", target: "$self" }]),
        mandatory("key-reveal-goodwill", "goodwill-completed", [
          { op: "reveal-identity", target: "$self" }
        ])
      ];
    case "网络名流":
      return [
        mandatory("celebrity-death", "death", [
          each(
            alive(
              all(
                other,
                eq(
                  { field: "initialArea", target: "$it" },
                  { field: "initialArea", target: "$self" }
                )
              )
            ),
            add("$it", "paranoia", 1)
          )
        ]),
        mandatory(
          "celebrity-goodwill",
          "goodwill-completed",
          [
            each(
              alive(
                all(
                  other,
                  eq(
                    { field: "initialArea", target: "$it" },
                    { field: "initialArea", target: "$self" }
                  )
                )
              ),
              add("$it", "goodwill", 1),
              add("$it", "paranoia", 1)
            )
          ],
          { loopLimit: 1 }
        )
      ];
    case "魔术师":
      return [
        optional(
          "magician-move",
          [
            {
              choices: [
                { key: "target", options: co(ge(count("paranoia", "$it"), 1)) },
                { key: "area", options: ["$adjacent-target"] }
              ],
              effects: [{ op: "move", target: "$target", area: "$area" }]
            }
          ],
          { loopLimit: 1, sharedKey: "magicians" }
        ),
        mandatory("magician-death", "death", [
          { op: "clear", target: "$self", counter: "paranoia" }
        ])
      ];
    case "愚者":
      return [
        mandatory("fool-completion", "incident-completed", [
          { op: "clear", target: "$self", counter: "paranoia" }
        ])
      ];
    case "偏执狂":
      return [
        optional("paranoiac", [
          choice(
            ["intrigue", "paranoia"],
            [{ op: "counter", target: "$self", counter: "$counter", amount: 1 }],
            "counter"
          )
        ])
      ];
    case "心理医生":
      return [
        stepAbility(
          "therapist",
          "mastermind-abilities",
          [choice(another(), [add("$target", "paranoia", -1)])],
          { mandatory: true, condition: ge({ game: "ex" }, 1) }
        )
      ];
    case "投毒者":
      return [
        stepAbility("poisoner-character", "day-end", [choice(co(), [kill])], {
          mandatory: true,
          loopLimit: 1,
          condition: ge({ game: "ex" }, 2)
        }),
        mandatory("poisoner-protagonists", "day-end", [pd], { condition: ge({ game: "ex" }, 4) })
      ];
    case "深潜者":
      return [
        ...identityPrograms("主谋"),
        mandatory("deep-one-death", "death", [
          { op: "reveal-identity", target: "$self" },
          { op: "ex", amount: 1 }
        ])
      ];
    case "祭品":
      return [
        stepAbility(
          "sacrifice",
          "day-end",
          [simple(each(alive(), { op: "kill", target: "$it" }), pd)],
          { condition: all(ge(count("intrigue"), 2), ge(count("paranoia"), 2)) }
        )
      ];
    case "目击者":
      return [
        mandatory(
          "witness",
          "day-end",
          [
            { op: "kill", target: "$self" },
            { op: "ex", amount: 1 }
          ],
          { condition: ge(count("paranoia"), 4) }
        )
      ];
    case "巫师":
      return [
        mandatory("wizard-dead", "loop-end", [fail], {
          condition: eq(field("status", "$self"), "dead")
        }),
        stepAbility(
          "wizard-goodwill",
          "goodwill-completed",
          [
            simple({ op: "reveal-identity", target: "$self" }),
            {
              choices: [{ key: "increase", options: ["yes", "no"], actor: "captain" }],
              effects: [when(eq({ ref: "$increase" }, "yes"), { op: "ex", amount: 1 })]
            }
          ],
          { mandatory: true }
        )
      ];
    default:
      return null;
  }
}
function plotPrograms(name) {
  const loss = (condition) => [mandatory("loss", "loop-end", [fail], { condition })];
  switch (name) {
    case "谋杀计划":
    case "开膛者的魔影":
    case "最黑暗的剧本":
    case "好友圈":
    case "恋爱风景线":
    case "潜伏的杀人狂":
    case "未知因子Χ":
    case "妄想扩大病毒":
    case "因果线":
    case "爱与恨的螺旋":
    case "魔女的茶会":
    case "魔爪渐进":
    case "心无灵犀":
    case "灭亡讴歌":
    case "我是名侦探":
    case "愚者之舞":
    case "绝对意志":
    case "双子的诡计":
    case "士的宁毒液":
    case "抗争者":
    case "见证恐惧":
    case "伊斯之伟大种族":
    case "深渊之都的私语":
    case "无貌之神":
      return [];
    case "流言四起":
      return [
        optional("rumor-intrigue", [choice({ kind: "boards" }, [add("$target", "intrigue", 1)])], {
          loopLimit: 1
        })
      ];
    case "复仇的火种":
      return [
        mandatory("loss", "loop-end", [
          each(
            { kind: "cards", where: eq(field("identity"), "主谋") },
            when(ge({ counter: "intrigue", target: "$it.initialArea" }, 2), fail)
          )
        ])
      ];
    case "巨大定时炸弹X":
    case "巨大定时炸弹Y":
    case "巨大定时炸弹Z":
      return [
        mandatory("loss", "loop-end", [
          each(
            { kind: "cards", where: eq(field("identity"), "魔女") },
            when(ge({ counter: "intrigue", target: "$it.initialArea" }, 2), fail)
          )
        ])
      ];
    case "守护此地":
      return loss(ge(count("intrigue", "school"), 2));
    case "被封印的邪灵":
      return loss(ge(count("intrigue", "shrine"), 2));
    case "和我签订契约吧！":
      return loss(
        ge(
          { count: alive(all(eq(field("identity"), "关键人物"), ge(count("intrigue", "$it"), 2))) },
          1
        )
      );
    case "改变未来":
      return loss({ incidentOccurred: "蝴蝶效应" });
    case "死亡真人秀":
      return loss(le({ count: alive() }, 6));
    case "事件交织的罗网":
      return loss(ge({ game: "ex" }, 3));
    case "命悬一线的计划":
      return loss(le({ game: "ex" }, 1));
    case "黑暗学园":
      return loss(ge(count("intrigue", "school"), { op: "subtract", args: [{ game: "loop" }, 1] }));
    case "外神合唱曲":
      return loss(ge({ count: alive(ge(count("intrigue", "$it"), 1)) }, 5));
    case "达贡的福音书":
      return loss(ge(count("intrigue", "shrine"), { game: "ex" }));
    case "染血的仪式":
      return loss(ge({ count: { kind: "dead" } }, { game: "ex" }));
    case "黄衣之王":
      return loss({ flag: "ex-increased" });
    case "因果之绊":
    case "诸神之骰":
    case "隔离病房惊魂记":
    case "疯狂的真相":
    case "超越世界线":
      return [];
    case "绝密报告":
      return loss({ flag: "classified-revealed" });
    case "男子汉的战争":
      return loss(
        ge(
          {
            count: {
              kind: "cards",
              where: all(eq(field("identity"), "忍者"), ge(count("intrigue", "$it"), 2))
            }
          },
          1
        )
      );
    case "X异因子":
      return [
        optional(
          "factor-intrigue",
          [
            choice(alive(eq(field("identity"), "不安定因子")), [
              add("$target.area", "intrigue", 1)
            ])
          ],
          { loopLimit: 1 }
        )
      ];
    case "火药的味道":
      return loss(ge({ sum: alive(), value: count("paranoia", "$it") }, 12));
    case "高贵的血族":
    case "月夜凶兽":
    case "雾中夜惊梦":
    case "古墓活尸":
    case "心慌派对":
    case "少女大危机":
    case "恐慌与妄想":
    case "不听劝的人":
      return [];
    case "魔女遗咒":
      return [
        stepAbility("witch-curse", "loop-start", [
          choice({ kind: "cards", where: eq(field("identity"), "魔女") }, [
            { op: "curse", target: "$target.initialArea" }
          ])
        ])
      ];
    case "被诅咒的土地":
      return [
        stepAbility("ghost-curse", "loop-start", [
          choice({ kind: "cards", where: eq(field("identity"), "鬼魂") }, [
            { op: "curse", target: "$target.initialArea" }
          ])
        ]),
        stepAbility("curse-no-target", "day-end", [simple(pd)], {
          condition: { flag: "curse-no-target" }
        })
      ];
    case "怪物们的阴谋":
      return [
        optional(
          "monsters-intrigue",
          [choice(["$ignore-goodwill-areas"], [add("$target", "intrigue", 1)])],
          { loopLimit: 2 }
        )
      ];
    case "童话里的杀人鬼":
    case "化身博士":
    case "恶魔吹着笛子来":
    case "傀儡之线":
    case "爱丽丝梦游仙境":
    case "空想扩大病毒":
      return [];
    case "闭锁的未来":
      return loss(eq({ game: "world" }, 0));
    case "鹅妈妈神秘故事":
      return loss(ge({ count: { kind: "dead" } }, { op: "min", args: [{ game: "loop" }, 3] }));
    case "次元融合计划":
      return loss({ any: [{ incidentOccurred: "遗言" }, { incidentOccurred: "遗失物" }] });
    case "虚幻世界":
      return loss(
        ge(
          {
            count: {
              kind: "cards",
              where: all(
                { flag: "y-obsessive", target: "$it" },
                { any: [eq(field("status"), "alive"), eq(field("status"), "dead")] },
                ge({ op: "add", args: [count("intrigue", "$it"), { game: "ex" }] }, 3)
              )
            }
          },
          1
        )
      );
    case "难以言喻的怪物":
      return [
        stepAbility("monster", "day-end", [simple(pd)], { condition: ge({ game: "ex" }, 3) })
      ];
    case "最终计划":
    case "真正的怪物":
    case "神话收集者":
    case "我才是名侦探":
    case "SNS恐慌":
    case "捏造的秘密":
      return [];
    case "封印的终末":
      return [
        stepAbility("sealed-end", "day-end", [simple(pd)], {
          condition: ge(count("intrigue", "shrine"), 2)
        })
      ];
    case "叛逆的世界":
      return loss(
        ge(
          { count: alive(all(eq(field("identity"), "关键人物"), ge(count("intrigue", "$it"), 2))) },
          1
        )
      );
    case "恶魔的剧本":
      return [
        ...loss({ any: [{ incidentOccurred: "遗言" }, { incidentOccurred: "代行者" }] }),
        stepAbility("devil-watcher", "day-end", [simple(pd)], {
          condition: all(
            eq({ game: "day" }, { game: "days" }),
            ge({ count: alive(all(eq(field("identity"), "监视者"), le(field("rawTotal"), 1))) }, 1)
          )
        })
      ];
    default:
      return null;
  }
}
function incidentProgram(name) {
  const deathIn = (board2, protagonists) => simple(
    when(
      ge(count("intrigue", board2), 1),
      each(alive(eq(field("area"), board2)), { op: "kill", target: "$it" })
    ),
    ...protagonists ? [when(ge(count("intrigue", board2), 2), pd)] : []
  );
  switch (name) {
    case "医院事故":
      return [deathIn("hospital", true)];
    case "恐怖袭击":
      return [deathIn("city", true)];
    case "暴乱":
      return [simple(...deathIn("city", false).effects, ...deathIn("school", false).effects)];
    case "谋杀":
    case "连续杀人":
    case "冲动杀人":
      return [choice(another(), [kill])];
    case "疯狂杀人":
      return [choice(co(), [kill])];
    case "自杀":
      return [simple({ op: "kill", target: "$self" })];
    case "邪气污染":
      return [simple(add("shrine", "intrigue", 2))];
    case "不安扩散":
      return [
        choice(alive(), [add("$target", "paranoia", 2)], "first"),
        choice(alive({ cmp: "ne", left: { ref: "$it" }, right: { ref: "$first" } }), [
          add("$target", "intrigue", 1)
        ])
      ].map((s, i) => i === 0 ? { ...s, effects: [add("$first", "paranoia", 2)] } : s);
    case "散播":
      return [
        choice(alive(), [add("$first", "goodwill", -2)], "first"),
        choice(alive({ cmp: "ne", left: { ref: "$it" }, right: { ref: "$first" } }), [
          add("$target", "goodwill", 2)
        ])
      ];
    case "失踪":
      return [
        choice({ kind: "boards" }, [{ op: "move", target: "$self", area: "$area" }], "area"),
        simple(add("$self.area", "intrigue", 1))
      ];
    case "远距离杀人":
      return [choice(alive(ge(count("intrigue", "$it"), 2)), [kill])];
    case "蝴蝶效应":
      return [
        {
          choices: [
            { key: "target", options: co() },
            { key: "counter", options: ["goodwill", "paranoia", "intrigue"] }
          ],
          effects: [{ op: "counter", target: "$target", counter: "$counter", amount: 1 }]
        }
      ];
    case "自白":
      return [simple({ op: "reveal-identity", target: "$self" })];
    case "前兆":
      return [choice(co(), [add("$target", "paranoia", 1)])];
    case "猎奇杀人":
      return [...incidentProgram("连续杀人"), ...incidentProgram("不安扩散")];
    case "破局":
      return [
        choice({ kind: "alive-or-boards" }, [add("$target", "intrigue", -2)], "target", "captain")
      ];
    case "阴谋活动":
      return [
        choice(
          ["连续杀人", "失踪"],
          [{ op: "invoke-incident", name: "$incident", culprit: "$self" }],
          "incident"
        )
      ];
    case "伪造事件":
      return [simple(when(ge(count("intrigue", "$self.initialArea"), 2), pd))];
    case "伪装自杀":
      return [simple({ op: "flag", target: "$self", key: "no-protagonist-cards" })];
    case "银色子弹":
      return [simple({ op: "flag", key: "end-after-incident" })];
    case "送葬":
      return [choice(alive(), [kill], "target", "captain")];
    case "集体自杀":
      return [simple(when(ge(count("intrigue"), 1), each(co(), { op: "kill", target: "$it" })))];
    case "发现":
      return [simple({ op: "ex", amount: 1 })];
    case "廷达罗斯之嗅":
      return [simple({ op: "flag", key: "hound" })];
    case "可疑信件":
      return [
        {
          choices: [
            { key: "target", options: co() },
            { key: "area", options: { kind: "boards" } }
          ],
          effects: [
            { op: "move", target: "$target", area: "$area" },
            {
              op: "schedule",
              onlyIfMoved: "$target",
              day: { op: "add", args: [{ game: "day" }, 1] },
              timing: "day-start",
              effects: [{ op: "flag", target: "$target", key: "immobile" }]
            }
          ]
        }
      ];
    case "封锁":
      return [
        simple(
          { op: "flag", key: "lockdown-area", value: "$self.area" },
          { op: "flag", key: "lockdown-day", value: "$day" }
        )
      ];
    case "亵渎杀人":
      return [
        choice(["murder", "intrigue"], [], "branch"),
        { ...choice(another(), [kill]), condition: eq({ ref: "$branch" }, "murder") },
        {
          effects: [add("$self.area", "intrigue", 1)],
          condition: eq({ ref: "$branch" }, "intrigue")
        }
      ];
    case "言灵诅咒":
      return [simple({ op: "curse", target: "$self" })];
    case "诅咒活化":
      return [simple({ op: "curse", target: "$self" })];
    case "污秽溢出":
      return [
        choice(alive(), [add("$target", "paranoia", 2)]),
        choice({ kind: "boards" }, [add("$target", "intrigue", 1)])
      ];
    case "死者默示录":
      return [
        simple(each(co(), { op: "kill", target: "$it" })),
        simple(when(ge({ count: { kind: "dead", where: together } }, 5), pd))
      ];
    case "疯狂之夜":
      return [
        simple(
          { op: "flag", key: "mad-night-today" },
          when(ge({ count: { kind: "dead", where: eq(field("identity"), "丧尸") } }, 6), {
            op: "schedule",
            day: { game: "day" },
            timing: "day-end",
            effects: [pd]
          })
        )
      ];
    case "次元转换":
      return [simple({ op: "world-move" })];
    case "次元歪曲":
      return [
        {
          choices: [
            { key: "worldMove", options: ["yes", "no"] },
            { key: "first", options: alive() }
          ],
          effects: [
            when(eq({ ref: "$worldMove" }, "yes"), { op: "world-move" }),
            add("$first", "paranoia", 2)
          ]
        },
        choice(alive({ cmp: "ne", left: { ref: "$it" }, right: { ref: "$first" } }), [
          add("$target", "goodwill", 2)
        ])
      ];
    case "次元断层":
      return [
        choice(
          ["yes", "no"],
          [when(eq({ ref: "$worldMove" }, "yes"), { op: "world-move" })],
          "worldMove"
        ),
        simple(when(ge({ field: "kinds", target: "$self" }, 3), pd))
      ];
    case "遗失物":
      return [
        choice(co(), [add("$target", "intrigue", 1)]),
        choice({ kind: "boards" }, [{ op: "move", target: "$self", area: "$area" }], "area")
      ];
    case "空想事件":
      return [
        choice(
          ["冲动杀人", "次元歪曲", "遗失物"],
          [{ op: "invoke-incident", name: "$incident", culprit: "$self" }],
          "incident"
        )
      ];
    case "遗言":
      return [
        simple(
          { op: "kill", target: "$self" },
          {
            op: "schedule",
            timing: "loop-start",
            day: 1,
            loop: { op: "add", args: [{ game: "loop" }, 1] },
            effects: [{ op: "grant", side: "protagonists", card: "hope+1" }]
          }
        )
      ];
    case "奇点":
      return [
        simple(
          when(all(eq({ game: "world" }, 0), eq({ ref: "$firstOccurrence" }, "yes")), pd),
          when(
            { not: all(eq({ game: "world" }, 0), eq({ ref: "$firstOccurrence" }, "yes")) },
            { op: "world-move" }
          ),
          when(all(eq({ game: "world" }, 1), ge(count("intrigue", "$self.initialArea"), 1)), pd)
        )
      ];
    case "骤变":
      return [
        simple(
          when(ge(count("intrigue", "$self.initialArea"), 2), pd),
          when(
            le(count("intrigue", "$self.initialArea"), 1),
            add("$self.initialArea", "intrigue", 2)
          )
        )
      ];
    case "代行者":
      return [
        {
          choices: [
            { key: "delegate", options: ["p0", "p1", "p2"], actor: "mastermind" },
            { key: "target", options: alive(), actor: "$delegate" }
          ],
          effects: [kill]
        }
      ];
    case "灭绝之火":
      return [
        simple(
          when(
            eq({ ref: "$firstOccurrence" }, "yes"),
            each(alive(), { op: "kill", target: "$it" }),
            pd
          )
        )
      ];
    case "孤守":
      return [];
    case "绝望之暗":
      return [choice(alive(), [add("$target", "despair", 1)])];
    case "希望之光":
    case "隙间的阳光":
      return [choice(alive(), [add("$target", "hope", 1)], "target", "captain")];
    default:
      return null;
  }
}
function characterPrograms(name) {
  switch (name) {
    case "UP主":
      return [
        good("streamer", 3, [
          choice(another(), [add("$target", "goodwill", 1), add("$target", "paranoia", -1)]),
          {
            choices: [
              { key: "transfer", options: ["yes", "no"] },
              {
                key: "newTarget",
                options: alive(
                  all(eq(field("area"), field("area", "$target")), {
                    cmp: "ne",
                    left: field("character"),
                    right: "UP主"
                  })
                )
              }
            ],
            effects: [
              when(
                all(
                  eq({ gameFlag: "streamer-target" }, { ref: "$target" }),
                  eq({ ref: "$transfer" }, "yes")
                ),
                { op: "flag", key: "streamer-target", value: "$newTarget" }
              )
            ]
          }
        ])
      ];
    case "御神木":
      return [
        stepAbility("sacred-tree", "protagonist-abilities", [
          {
            choices: [
              { key: "target", options: another() },
              {
                key: "counter",
                options: ["goodwill", "paranoia", "intrigue", "guard", "hope", "despair"]
              }
            ],
            effects: [{ op: "transfer", from: "$self", to: "$target", counter: "$counter" }]
          }
        ])
      ];
    case "妹妹":
      return [
        good("little-sister", 5, [
          {
            choices: [
              { key: "target", options: co({ attribute: "成人", target: "$it" }) },
              { key: "ability", options: ["$target-goodwill"] }
            ],
            effects: [{ op: "invoke-goodwill", target: "$target", ability: "$ability" }]
          }
        ])
      ];
    case "模仿犯":
      return [
        good("copycat-reveal", 3, [simple({ op: "same-identity", target: "$self" })], {
          condition: ge({ game: "loop" }, 2),
          cannotRefuse: true
        })
      ];
    case "学者":
      return [
        good("scholar-clear", 3, [
          simple({ op: "clear", target: "$self" }),
          {
            choices: [{ key: "direction", options: ["up", "down"] }],
            effects: [
              when(eq({ ref: "$direction" }, "up"), { op: "ex", amount: 1 }),
              when(eq({ ref: "$direction" }, "down"), { op: "ex", amount: -1 })
            ]
          }
        ])
      ];
    case "临时工？":
      return [
        good(
          "parttimer-reveal",
          3,
          [
            simple({ op: "reveal-identity", target: "$self" }),
            choice(co(), [add("$target", "goodwill", 2)])
          ],
          { loopLimit: 1 }
        )
      ];
    case "大人物":
      return [
        good(
          "boss-reveal",
          5,
          [choice(alive(all(other, eq(field("area"), { ref: "$territory" }))), [reveal])],
          { loopLimit: 1 }
        )
      ];
    case "情报商":
      return [
        good(
          "informant",
          5,
          [
            choice(["$all-x"], [], "excluded"),
            choice(
              ["$other-selected-x"],
              [{ op: "reveal-rule", rule: "$rule" }],
              "rule",
              "mastermind"
            )
          ],
          { loopLimit: 1 }
        )
      ];
    case "住院患者":
    case "黑猫":
    case "临时工":
      return [];
    case "男学生":
    case "女学生":
      return [good("student", 2, [choice(another(student), [add("$target", "paranoia", -1)])])];
    case "大小姐":
      return [
        good("rich-girl", 3, [choice(co(), [add("$target", "goodwill", 1)])], {
          condition: {
            any: [eq(field("area", "$self"), "school"), eq(field("area", "$self"), "city")]
          }
        })
      ];
    case "偶像":
      return [
        good("idol-paranoia", 3, [choice(another(), [add("$target", "paranoia", -1)])]),
        good("idol-goodwill", 4, [choice(another(), [add("$target", "goodwill", 1)])])
      ];
    case "媒体人":
      return [
        good("media-paranoia", 2, [choice(alive(other), [add("$target", "paranoia", 1)])]),
        good("media-intrigue", 2, [
          choice({ kind: "alive-or-boards", where: together }, [add("$target", "intrigue", 1)])
        ])
      ];
    case "军人":
      return [
        good("soldier-paranoia", 2, [choice(co(), [add("$target", "paranoia", 2)])], {
          loopLimit: 1
        }),
        good("soldier-protect", 5, [simple({ op: "protect-protagonists" })], { loopLimit: 1 })
      ];
    case "护士":
      return [
        good("nurse", 2, [choice(another(upset), [add("$target", "paranoia", -1)])], {
          cannotRefuse: true
        })
      ];
    case "职员":
      return [good("office-worker", 3, [simple({ op: "reveal-identity", target: "$self" })])];
    case "巫女":
      return [
        good("shrine-maiden-remove", 3, [simple(add("shrine", "intrigue", -1))], {
          condition: eq(field("area", "$self"), "shrine")
        }),
        good("shrine-maiden-reveal", 5, [choice(co(), [reveal])], { loopLimit: 1 })
      ];
    case "异界人":
      return [
        good("alien-kill", 4, [choice(another(), [kill])], { loopLimit: 1 }),
        good(
          "alien-revive",
          5,
          [choice({ kind: "dead", where: together }, [{ op: "revive", target: "$target" }])],
          { loopLimit: 1 }
        )
      ];
    case "从者":
      return [
        good(
          "servant",
          4,
          [
            choice(alive(other), [
              { op: "flag", target: "$self", key: "protect", value: "$target" }
            ])
          ],
          { loopLimit: 1 }
        )
      ];
    case "转校生":
      return [
        good("transfer-student", 2, [
          choice(another(), [
            { op: "replace", target: "$target", from: "intrigue", to: "goodwill" }
          ])
        ])
      ];
    case "教师":
      return [
        good("teacher-counter", 3, [
          {
            choices: [
              { key: "target", options: co(student) },
              { key: "direction", options: ["add", "remove"] }
            ],
            effects: [
              when(eq({ ref: "$direction" }, "add"), add("$target", "paranoia", 1)),
              when(eq({ ref: "$direction" }, "remove"), add("$target", "paranoia", -1))
            ]
          }
        ]),
        good("teacher-reveal", 4, [choice(co(student), [reveal])], { loopLimit: 1 })
      ];
    case "医生":
      return [
        good("doctor-counter", 2, [
          {
            choices: [
              { key: "target", options: another() },
              { key: "direction", options: ["add", "remove"] }
            ],
            effects: [
              when(eq({ ref: "$direction" }, "add"), add("$target", "paranoia", 1)),
              when(eq({ ref: "$direction" }, "remove"), add("$target", "paranoia", -1))
            ]
          }
        ]),
        good("doctor-release", 3, [
          simple(
            each(
              { kind: "cards", where: eq(field("character"), "住院患者") },
              { op: "flag", target: "$it", key: "free-movement" }
            )
          )
        ])
      ];
    case "小女孩":
      return [
        good("girl-release", 1, [simple({ op: "flag", target: "$self", key: "free-movement" })]),
        good(
          "girl-move",
          3,
          [choice(["$adjacent-self"], [{ op: "move", target: "$self", area: "$area" }], "area")],
          { loopLimit: 1 }
        )
      ];
    case "手下":
      return [good("henchman", 3, [simple({ op: "flag", target: "$self", key: "no-incidents" })])];
    case "局外人":
      return [
        good("outsider-reveal", 3, [simple({ op: "reveal-identity", target: "$self" })], {
          condition: ge({ game: "loop" }, 2),
          cannotRefuse: true
        })
      ];
    case "幻想":
      return [
        good(
          "illusion-move",
          3,
          [
            {
              choices: [
                { key: "target", options: co() },
                { key: "area", options: { kind: "boards" } }
              ],
              effects: [{ op: "move", target: "$target", area: "$area" }]
            }
          ],
          { loopLimit: 1 }
        ),
        good("illusion-remove", 4, [simple({ op: "remove", target: "$self" })])
      ];
    case "刑警":
      return [
        good(
          "detective-incident",
          4,
          [choice(["$occurred-days"], [{ op: "reveal-culprit", day: "$day" }], "day")],
          { loopLimit: 1 }
        ),
        good("detective-guard", 5, [choice(co(), [add("$target", "guard", 1)])], {
          loopLimit: 1,
          condition: eq(
            {
              count: {
                kind: "cards",
                where: ge({ counter: "guard", target: "$it", raw: true }, 1)
              }
            },
            0
          )
        })
      ];
    case "神灵":
      return [
        good(
          "divinity-incident",
          3,
          [choice(["$incident-days"], [{ op: "reveal-culprit", day: "$day" }], "day")],
          { loopLimit: 1 }
        ),
        good("divinity-intrigue", 5, [
          choice({ kind: "alive-or-boards", where: together }, [add("$target", "intrigue", -1)])
        ])
      ];
    case "教主":
      return [
        good("leader-goodwill", 3, [
          choice(alive(all(other, upset)), [add("$target", "goodwill", 1)])
        ]),
        good("leader-reveal", 4, [choice(another(upset), [reveal])], { loopLimit: 1 })
      ];
    case "班长":
      return [
        good("class-representative", 2, [
          choice(["$used-captain-cards"], [{ op: "recover-card", card: "$card" }], "card")
        ])
      ];
    case "AI":
      return [
        good(
          "ai",
          3,
          [
            choice(
              ["$public-incidents"],
              [{ op: "invoke-incident", name: "$incident", culprit: "$self" }],
              "incident"
            )
          ],
          { loopLimit: 1 }
        )
      ];
    case "鉴别员":
      return [
        good(
          "forensic-transfer",
          2,
          [
            {
              choices: [
                { key: "from", options: another() },
                {
                  key: "to",
                  options: another({ cmp: "ne", left: { ref: "$it" }, right: { ref: "$from" } })
                },
                {
                  key: "counter",
                  options: ["goodwill", "paranoia", "intrigue", "guard", "hope", "despair"]
                }
              ],
              effects: [{ op: "transfer", from: "$from", to: "$to", counter: "$counter" }]
            }
          ],
          { loopLimit: 1 }
        ),
        good("forensic-reveal", 5, [choice({ kind: "dead" }, [reveal])], { loopLimit: 1 })
      ];
    case "上位存在":
      return [
        good(
          "higher-being",
          3,
          [
            {
              choices: [
                { key: "target", options: co() },
                { key: "counter", options: ["hope", "despair"] }
              ],
              effects: [{ op: "counter", target: "$target", counter: "$counter", amount: 1 }]
            }
          ],
          { loopLimit: 1 }
        )
      ];
    default:
      return null;
  }
}

// packages/content/src/official/compile.ts
var entries = source_catalog_default.entries;
var areas = {
  医院: "hospital",
  神社: "shrine",
  都市: "city",
  学校: "school",
  远方: "far"
};
var decodeAreas = (text2) => Object.entries(areas).filter(([name]) => text2.includes(name)).map(([, area]) => area);
var stamp = (abilities2, source) => (abilities2 ?? []).map((a) => ({ ...a, source }));
function freeze(o) {
  if (o && typeof o === "object") {
    for (const v of Object.values(o)) freeze(v);
    Object.freeze(o);
  }
  return o;
}
var compiled = /* @__PURE__ */ new Map();
function compileOfficial(module, anniversary = false) {
  const key = `${module}:${anniversary}`;
  const cached = compiled.get(key);
  if (cached) return cached;
  const pack = {
    schema: 1,
    semanticVersion: "0.3.1",
    moduleAbilities: moduleAbilities[module] ?? [],
    digest: "",
    module,
    anniversary,
    characters: {},
    identities: {},
    plots: {},
    incidents: {}
  };
  const counts = { "①": 1, "②": 2, "③": 3 };
  for (const e of entries) {
    const f = e.fields;
    if (e.kind === "characters") {
      const programs = characterTraits[e.name]?.abilities ?? characterPrograms(e.name);
      pack.characters[e.name] = {
        ...characterTraits[e.name],
        name: e.name,
        source: e.source,
        initial: decodeAreas(String(f["初始区域"] ?? "")),
        forbidden: decodeAreas(String(f["禁行区域"] ?? "")),
        paranoia: Number(String(f["不安限度"] ?? "").normalize("NFKC")) || 0,
        attributes: f["属性"] ?? [],
        abilities: stamp(programs, e.source),
        supported: programs !== null
      };
      continue;
    }
    const overlay = anniversary && e.module === "BTX+" && (e.kind === "rules" && e.name === "超越世界线" || e.kind === "identities" && e.name === "因果残片" || e.kind === "incidents" && ["希望之光", "绝望之暗"].includes(e.name));
    if (e.module !== module && !overlay) continue;
    if (e.kind === "identities") {
      const programs = identityTraits[e.name]?.abilities ?? identityPrograms(e.name), traits2 = String(f.traits ?? "").replaceAll(/\s/g, "");
      pack.identities[e.name] = {
        ...identityTraits[e.name],
        name: e.name,
        source: e.source,
        max: counts[String(f.max)],
        ignore: traits2.includes("必定") ? "mandatory" : traits2.includes("无视友好") ? "optional" : void 0,
        puppet: traits2.includes("傀儡"),
        immortal: traits2.includes("不死"),
        abilities: stamp(programs, e.source),
        supported: programs !== null
      };
    }
    if (e.kind === "rules") {
      const programs = plotPrograms(e.name);
      const rawCounts = f.identityCounts ?? {};
      const front = Object.keys(rawCounts).find((n) => rawCounts[n] === "表");
      const reverse = Object.keys(rawCounts).find((n) => rawCounts[n] === "里");
      pack.plots[e.name] = {
        name: e.name,
        source: e.source,
        type: f.ruleType,
        identities: Object.fromEntries(
          Object.entries(rawCounts).filter(([, n]) => counts[n]).map(([name, n]) => [name, counts[n]])
        ),
        pair: front || reverse ? [front ?? "平民", reverse ?? "平民"] : void 0,
        abilities: stamp(programs, e.source),
        supported: programs !== null
      };
    }
    if (e.kind === "incidents") {
      const program = incidentProgram(e.name);
      pack.incidents[e.name] = {
        ...incidentTraits2[e.name],
        name: e.name,
        source: e.source,
        steps: program ?? [],
        supported: program !== null,
        thresholdOffset: ["前兆", "送葬", "冲动杀人"].includes(e.name) ? -1 : e.name === "猎奇杀人" ? 1 : 0,
        thresholdCounter: ["阴谋活动", "廷达罗斯之嗅", "空想事件"].includes(e.name) ? "intrigue" : e.name === "希望之光" ? "goodwill" : void 0,
        exGain: e.name === "银色子弹" ? 0 : e.name === "猎奇杀人" ? 2 : 1,
        crowdThreshold: { 疯狂之夜: 0, 诅咒活化: 1, 污秽溢出: 2, 死者默示录: 2 }[e.name]
      };
    }
  }
  pack.identities["平民"] = {
    name: "平民",
    source: "facts/sources/lunhui/tragedy_loop_game_rules(3)(1).md#6.4",
    supported: true,
    abilities: []
  };
  pack.digest = createHash("sha256").update(
    canonical({
      pack,
      sources: entries.filter(
        (e) => e.module === module || e.kind === "characters" || anniversary && e.module === "BTX+"
      ).map((e) => [e.source, e.sha256]),
      decisions: foundation_decisions_default.decisions.map((d) => ({
        id: d.id,
        status: d.status,
        semantics: d.semantics
      }))
    })
  ).digest("hex");
  const result = freeze(pack);
  compiled.set(key, result);
  return result;
}
export {
  EnumeratedKnowledge,
  LiveKnowledge,
  compileOfficial
};
